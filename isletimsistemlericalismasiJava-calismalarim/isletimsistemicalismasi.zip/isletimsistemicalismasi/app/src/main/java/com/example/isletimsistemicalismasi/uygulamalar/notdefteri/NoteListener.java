package com.example.isletimsistemicalismasi.uygulamalar.notdefteri;

import com.example.isletimsistemicalismasi.uygulamalar.notdefteri.model.Not;

public interface NoteListener {
    void NoteClick(Not not);
}
