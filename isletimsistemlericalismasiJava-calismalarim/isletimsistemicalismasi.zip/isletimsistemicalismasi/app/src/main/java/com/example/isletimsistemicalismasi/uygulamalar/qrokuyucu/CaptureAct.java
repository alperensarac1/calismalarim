package com.example.isletimsistemicalismasi.uygulamalar.qrokuyucu;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureAct extends CaptureActivity {
}
