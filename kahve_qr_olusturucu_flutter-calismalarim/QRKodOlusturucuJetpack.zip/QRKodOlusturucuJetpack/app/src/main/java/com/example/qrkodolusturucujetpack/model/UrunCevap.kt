package com.example.qrkodolusturucujetpack.model

data class UrunCevap(
    val kahve_urun: List<Urun>
)
