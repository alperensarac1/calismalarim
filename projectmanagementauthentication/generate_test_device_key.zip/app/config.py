from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)


# =========================================================
# PROJE KLASÖRLERİ
# =========================================================


# Bu dosya:
#
# Projectmanagementauthenticator/app/config.py
#
# konumunda bulunduğu için iki üst klasör proje köküdür.
BASE_DIR = Path(
    __file__,
).resolve().parent.parent


# SQLite veritabanı ve ileride üretilecek diğer kalıcı
# dosyalar bu klasör altında tutulacaktır.
DATA_DIR = BASE_DIR / "data"


# Klasör mevcut değilse uygulama başlarken otomatik
# olarak oluşturulur.
DATA_DIR.mkdir(
    parents=True,
    exist_ok=True,
)


# =========================================================
# UYGULAMA AYARLARI
# =========================================================


class Settings(BaseSettings):
    """
    Authenticator servisinin merkezi ayarlarını
    temsil eder.

    Ayarlar şu öncelik sırasıyla okunur:

    1. İşletim sistemi ortam değişkenleri
    2. Proje kökündeki .env dosyası
    3. Bu sınıfta tanımlanan varsayılan değerler

    Böylece kaynak kodu değiştirmeden farklı ayarlar
    kullanılabilir.
    """

    # =====================================================
    # TEMEL UYGULAMA BİLGİLERİ
    # =====================================================

    app_name: str = (
        "Platform Independent Authenticator Service"
    )

    app_version: str = "1.0.0"

    debug: bool = True

    # 0.0.0.0 kullanıldığında servis yalnızca localhost
    # üzerinden değil, aynı ağdaki cihazlardan da
    # erişilebilir olur.
    host: str = "0.0.0.0"

    port: int = Field(
        default=8090,
        ge=1,
        le=65535,
    )

    # =====================================================
    # VERİTABANI AYARLARI
    # =====================================================

    # SQLite veritabanı proje içerisindeki data
    # klasöründe tutulur.
    database_url: str = (
        f"sqlite:///{DATA_DIR / 'authenticator.db'}"
    )

    # =====================================================
    # JWT VE GÜVENLİK AYARLARI
    # =====================================================

    # JWT ve servis tokenlarının imzalanmasında
    # kullanılır.
    secret_key: str = Field(
        default=(
            "CHANGE-THIS-DEVELOPMENT-SECRET-KEY"
        ),
        min_length=32,
    )

    jwt_algorithm: str = "HS256"

    # Genel access token ömrü.
    access_token_expire_minutes: int = Field(
        default=30,
        ge=1,
    )

    # Mobil Authenticator cihazına verilen cihaz
    # tokenının geçerlilik süresi.
    device_token_expire_days: int = Field(
        default=365,
        ge=1,
    )

    # Ana backend veya güvenilir servislerin ileride
    # Authenticator API'sine servisler arası erişiminde
    # kullanılabilecek anahtardır.
    service_api_key: str = Field(
        default=(
            "CHANGE-THIS-SERVICE-API-KEY"
        ),
        min_length=24,
    )

    # =====================================================
    # CHALLENGE AYARLARI
    # =====================================================

    # Bir doğrulama challenge'ının saniye cinsinden
    # geçerlilik süresidir.
    challenge_expire_seconds: int = Field(
        default=120,
        ge=30,
        le=900,
    )

    # Kullanıcının tek kullanımlık kodu en fazla kaç
    # kez yanlış girebileceğini belirler.
    challenge_max_attempts: int = Field(
        default=5,
        ge=1,
        le=20,
    )

    # Hobi/test amacıyla kullanılan sabit doğrulama kodu.
    #
    # Bu kod girildiğinde challenge, telefonda üretilen
    # gerçek koddan bağımsız olarak geçerli kabul edilir.
    test_challenge_code: str = Field(
        default="987456",
        min_length=6,
        max_length=12,
        pattern=r"^[0-9]+$",
    )

    # -----------------------------------------------------
    # DEMO MODU
    # -----------------------------------------------------

    # True olduğunda kullanıcının kayıtlı veya çevrimiçi
    # bir Authenticator cihazı bulunmasa bile challenge
    # oluşturulmasına izin verilir.
    #
    # Bu seçenek özellikle yeni kullanıcılarla sistemi
    # hızlıca göstermek için kullanılır.
    #
    # Demo akışı:
    #
    # 1. Kullanıcı React uygulamasından giriş yapar.
    # 2. Mobil cihaz olmasa da pending challenge oluşur.
    # 3. React doğrudan kod giriş ekranını gösterir.
    # 4. Kullanıcı TEST_CHALLENGE_CODE değerini girer.
    # 5. Doğrulama başarılı kabul edilir.
    #
    # Gerçek üretim ortamında bunun false yapılması
    # önerilir.
    allow_challenge_without_device: bool = True

    # Authenticator veritabanında henüz kayıtlı olmayan
    # fakat geçerli bir .NET access tokenına sahip
    # kullanıcıların otomatik olarak ExternalUser
    # tablosuna eklenmesine izin verir.
    #
    # Böylece yeni kullanıcı mobil cihaz kaydetmeden de
    # demo challenge akışını deneyebilir.
    auto_create_external_user: bool = True

    # =====================================================
    # FRONTEND VE CORS AYARLARI
    # =====================================================

    # React uygulamasının adresidir.
    frontend_origin: str = (
        "http://localhost:5173"
    )

    # =====================================================
    # MEVCUT .NET BACKEND AYARLARI
    # =====================================================

    # Python Authenticator ve .NET backend aynı
    # bilgisayarda çalıştığı için servisler arası
    # iletişimde localhost kullanılır.
    main_backend_base_url: str = (
        "http://127.0.0.1:8080"
    )

    # Gelen backend access tokenıyla aktif kullanıcı
    # bilgisini doğrulayacağımız endpoint.
    main_backend_current_user_path: str = (
        "/api/Auth/me"
    )

    # Backend HTTP isteğinin saniye cinsinden maksimum
    # bekleme süresidir.
    main_backend_timeout_seconds: float = Field(
        default=10.0,
        gt=0,
        le=60,
    )

    # True olduğunda cihaz kaydı ve kullanıcıya bağlı
    # challenge oluşturma işlemleri öncesinde mevcut
    # backend access tokenı doğrulanır.
    verify_backend_access_token: bool = True

    # =====================================================
    # REVERSE GEOCODING AYARLARI
    # =====================================================

    # True olduğunda mobil cihazdan gelen GPS
    # koordinatları şehir, ilçe, bölge ve ülke
    # bilgisine dönüştürülmeye çalışılır.
    reverse_geocoding_enabled: bool = True

    # Nominatim servisine gönderilecek tanımlayıcı
    # User-Agent bilgisidir.
    reverse_geocoding_user_agent: str = Field(
        default=(
            "projectmanagement-authenticator/1.0"
        ),
        min_length=3,
        max_length=200,
    )

    # Reverse geocoding isteğinin saniye cinsinden
    # maksimum bekleme süresidir.
    reverse_geocoding_timeout_seconds: float = Field(
        default=8.0,
        gt=0,
        le=60,
    )

    # Aynı veya çok yakın koordinatlar için gereksiz
    # dış servis çağrısını azaltan bellek içi cache
    # kapasitesidir.
    reverse_geocoding_cache_size: int = Field(
        default=500,
        ge=1,
        le=10000,
    )

    # =====================================================
    # PYDANTIC SETTINGS YAPILANDIRMASI
    # =====================================================

    model_config = SettingsConfigDict(
        # .env dosyası proje kökünden okunur.
        env_file=BASE_DIR / ".env",

        env_file_encoding="utf-8",

        case_sensitive=False,

        extra="ignore",
    )


# =========================================================
# AYAR NESNESİ
# =========================================================


@lru_cache
def get_settings() -> Settings:
    """
    Settings nesnesini uygulama süresince yalnızca
    bir kez oluşturur.

    lru_cache sayesinde her servis veya dependency
    çağrısında .env dosyası yeniden okunmaz.
    """

    return Settings()