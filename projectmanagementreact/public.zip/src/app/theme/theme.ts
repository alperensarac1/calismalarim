import { createTheme } from '@mui/material/styles';

export const appTheme = createTheme({
    palette: {
        mode: 'light',

        primary: {
            main: '#2563EB',
            light: '#60A5FA',
            dark: '#1D4ED8',
            contrastText: '#FFFFFF',
        },

        secondary: {
            main: '#7C3AED',
            light: '#A78BFA',
            dark: '#5B21B6',
            contrastText: '#FFFFFF',
        },

        background: {
            default: '#F4F7FB',
            paper: '#FFFFFF',
        },

        text: {
            primary: '#111827',
            secondary: '#6B7280',
        },

        success: {
            main: '#16A34A',
        },

        warning: {
            main: '#D97706',
        },

        error: {
            main: '#DC2626',
        },

        info: {
            main: '#0284C7',
        },
    },

    typography: {
        fontFamily: '"Roboto", "Arial", sans-serif',

        h1: {
            fontWeight: 700,
        },

        h2: {
            fontWeight: 700,
        },

        h3: {
            fontWeight: 700,
        },

        h4: {
            fontWeight: 700,
        },

        h5: {
            fontWeight: 600,
        },

        h6: {
            fontWeight: 600,
        },

        button: {
            fontWeight: 600,
            textTransform: 'none',
        },
    },

    shape: {
        borderRadius: 10,
    },

    components: {
        MuiButton: {
            defaultProps: {
                disableElevation: true,
            },

            styleOverrides: {
                root: {
                    minHeight: 40,
                    borderRadius: 8,
                    paddingLeft: 18,
                    paddingRight: 18,
                },
            },
        },

        MuiTextField: {
            defaultProps: {
                fullWidth: true,
                size: 'small',
            },
        },

        MuiCard: {
            styleOverrides: {
                root: {
                    borderRadius: 14,
                    boxShadow: '0 8px 24px rgba(15, 23, 42, 0.06)',
                },
            },
        },

        MuiPaper: {
            styleOverrides: {
                root: {
                    backgroundImage: 'none',
                },
            },
        },
    },
});