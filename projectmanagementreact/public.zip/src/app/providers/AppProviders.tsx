import type { PropsWithChildren } from 'react';

import { CssBaseline, ThemeProvider } from '@mui/material';
import { QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';

import { env } from '../../config/env';
import { queryClient } from '../../lib/react-query/queryClient';
import { appTheme } from '../theme/theme';


export function AppProviders({
                                 children,
                             }: PropsWithChildren) {
    return (
        <QueryClientProvider client={queryClient}>
            <ThemeProvider theme={appTheme}>
                <CssBaseline />
                {children}
                {env.isDevelopment &&
                    env.enableReactQueryDevtools && (
                        <ReactQueryDevtools
                            initialIsOpen={false}
                            buttonPosition="bottom-right"
                        />
                    )}
            </ThemeProvider>
        </QueryClientProvider>
    );
}