import { useState } from 'react';

import AccountCircleRoundedIcon from '@mui/icons-material/AccountCircleRounded';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
import MenuRoundedIcon from '@mui/icons-material/MenuRounded';

import {
    AppBar,
    Avatar,
    Box,
    IconButton,
    ListItemIcon,
    Menu,
    MenuItem,
    Toolbar,
    Tooltip,
    Typography,
} from '@mui/material';

import { useNavigate } from 'react-router-dom';

import { useAuthStore } from '../../features/auth/store/authStore';
import { drawerWidth } from './DashboardSidebar';

interface DashboardHeaderProps {
    onMenuClick: () => void;
}

export function DashboardHeader({
                                    onMenuClick,
                                }: DashboardHeaderProps) {
    const navigate = useNavigate();

    const user = useAuthStore((state) => state.user);
    const logout = useAuthStore((state) => state.logout);

    const [menuAnchorElement, setMenuAnchorElement] =
        useState<HTMLElement | null>(null);

    const isMenuOpen = Boolean(menuAnchorElement);

    const handleUserMenuOpen = (
        event: React.MouseEvent<HTMLElement>,
    ): void => {
        setMenuAnchorElement(event.currentTarget);
    };

    const handleUserMenuClose = (): void => {
        setMenuAnchorElement(null);
    };

    const handleLogout = async (): Promise<void> => {
        handleUserMenuClose();

        await logout();

        navigate('/login', {
            replace: true,
        });
    };

    const userInitials = user
        ? `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`
            .toUpperCase()
        : '?';

    return (
        <AppBar
            position="fixed"
            elevation={0}
            sx={{
                width: {
                    sm: `calc(100% - ${drawerWidth}px)`,
                },
                ml: {
                    sm: `${drawerWidth}px`,
                },
                bgcolor: 'background.paper',
                color: 'text.primary',
                borderBottom: '1px solid',
                borderColor: 'divider',
            }}
        >
            <Toolbar
                sx={{
                    minHeight: 72,
                }}
            >
                <IconButton
                    edge="start"
                    onClick={onMenuClick}
                    aria-label="Menüyü aç"
                    sx={{
                        mr: 2,
                        display: {
                            sm: 'none',
                        },
                    }}
                >
                    <MenuRoundedIcon />
                </IconButton>

                <Box
                    sx={{
                        flexGrow: 1,
                    }}
                >
                    <Typography
                        variant="h6"
                        sx={{
                            fontWeight: 600,
                        }}
                    >
                        Yönetim Paneli
                    </Typography>

                    <Typography
                        variant="caption"
                        color="text.secondary"
                    >
                        Proje ve görev süreçlerini yönetin
                    </Typography>
                </Box>

                <Tooltip title="Kullanıcı menüsü">
                    <IconButton
                        onClick={handleUserMenuOpen}
                        size="small"
                        aria-controls={
                            isMenuOpen ? 'user-menu' : undefined
                        }
                        aria-haspopup="true"
                        aria-expanded={
                            isMenuOpen ? 'true' : undefined
                        }
                    >
                        <Avatar
                            sx={{
                                width: 40,
                                height: 40,
                                bgcolor: 'primary.main',
                                fontSize: 15,
                                fontWeight: 700,
                            }}
                        >
                            {userInitials}
                        </Avatar>
                    </IconButton>
                </Tooltip>

                <Menu
                    id="user-menu"
                    anchorEl={menuAnchorElement}
                    open={isMenuOpen}
                    onClose={handleUserMenuClose}
                    onClick={handleUserMenuClose}
                    transformOrigin={{
                        horizontal: 'right',
                        vertical: 'top',
                    }}
                    anchorOrigin={{
                        horizontal: 'right',
                        vertical: 'bottom',
                    }}
                    slotProps={{
                        paper: {
                            sx: {
                                mt: 1,
                                minWidth: 240,
                            },
                        },
                    }}
                >
                    <Box
                        sx={{
                            px: 2,
                            py: 1.5,
                        }}
                    >
                        <Typography
                            variant="subtitle2"
                            sx={{
                                fontWeight: 600,
                            }}
                        >
                            {user?.fullName ?? 'Kullanıcı'}
                        </Typography>

                        <Typography
                            variant="body2"
                            color="text.secondary"
                        >
                            {user?.email ?? '-'}
                        </Typography>

                        <Typography
                            variant="caption"
                            color="primary"
                        >
                            {user?.role ?? '-'}
                        </Typography>
                    </Box>

                    <MenuItem disabled>
                        <ListItemIcon>
                            <AccountCircleRoundedIcon fontSize="small" />
                        </ListItemIcon>

                        Profil
                    </MenuItem>

                    <MenuItem onClick={handleLogout}>
                        <ListItemIcon>
                            <LogoutRoundedIcon fontSize="small" />
                        </ListItemIcon>

                        Çıkış yap
                    </MenuItem>
                </Menu>
            </Toolbar>
        </AppBar>
    );
}