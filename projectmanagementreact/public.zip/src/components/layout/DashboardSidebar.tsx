import {
    Box,
    Divider,
    Drawer,
    List,
    ListItemButton,
    ListItemIcon,
    ListItemText,
    Toolbar,
    Typography,
} from '@mui/material';

import {
    useLocation,
    useNavigate,
} from 'react-router-dom';

import { env } from '../../config/env';
import { useAuthStore } from '../../features/auth/store/authStore';
import { getNavigationItemsByRole } from './navigationItems';


export const drawerWidth = 260;


/*
 * =========================================================
 * COMPONENT PROPS
 * =========================================================
 */


interface DashboardSidebarProps {
    mobileOpen: boolean;

    onMobileClose: () => void;
}


/*
 * =========================================================
 * SIDEBAR COMPONENT
 * =========================================================
 */


export function DashboardSidebar({
                                     mobileOpen,
                                     onMobileClose,
                                 }: DashboardSidebarProps) {
    const navigate = useNavigate();

    const location = useLocation();


    /*
     * Aktif kullanıcı bilgisi Zustand auth store
     * içerisinden alınır.
     */
    const user = useAuthStore(
        (state) => state.user,
    );


    /*
     * Kullanıcının rolüne göre görüntüleyebileceği
     * menü öğeleri oluşturulur.
     */
    const navigationItems =
        getNavigationItemsByRole(
            user?.role,
        );


    /**
     * Seçilen sayfaya yönlendirir.
     *
     * Mobil görünümde yönlendirme sonrasında drawer
     * otomatik olarak kapatılır.
     */
    function handleNavigate(
        path: string,
    ): void {
        navigate(
            path,
        );

        onMobileClose();
    }


    /*
     * Hem mobil hem masaüstü Drawer içerisinde aynı
     * içerik kullanılır.
     */
    const drawerContent = (
        <Box
            sx={{
                height: '100%',

                display: 'flex',

                flexDirection: 'column',
            }}
        >
            {/*
             * =================================================
             * UYGULAMA BAŞLIĞI
             * =================================================
             */}

            <Toolbar
                sx={{
                    minHeight: 72,

                    px: 3,
                }}
            >
                <Box>
                    <Typography
                        variant="h6"
                        sx={{
                            fontWeight: 700,

                            lineHeight: 1.2,
                        }}
                    >
                        Project Management
                    </Typography>

                    <Typography
                        variant="caption"
                        color="text.secondary"
                    >
                        Yönetim paneli
                    </Typography>
                </Box>
            </Toolbar>

            <Divider />


            {/*
             * =================================================
             * NAVİGASYON LİSTESİ
             * =================================================
             */}

            <List
                sx={{
                    px: 2,

                    py: 2,
                }}
            >
                {navigationItems.map(
                    (item) => {
                        const Icon =
                            item.icon;


                        /*
                         * Hem tam route eşleşmesinde hem de
                         * detay sayfalarında ilgili menü
                         * öğesini aktif gösterir.
                         *
                         * Örnek:
                         *
                         * /projects
                         * /projects/12
                         */
                        const isActive =
                            location.pathname ===
                            item.path ||
                            location.pathname.startsWith(
                                `${item.path}/`,
                            );


                        return (
                            <ListItemButton
                                key={item.path}
                                selected={isActive}
                                onClick={() => {
                                    handleNavigate(
                                        item.path,
                                    );
                                }}
                                sx={{
                                    minHeight: 48,

                                    mb: 0.5,

                                    borderRadius: 2,

                                    '&.Mui-selected': {
                                        bgcolor:
                                            'primary.main',

                                        color:
                                            'primary.contrastText',

                                        '&:hover': {
                                            bgcolor:
                                                'primary.dark',
                                        },

                                        '& .MuiListItemIcon-root':
                                            {
                                                color:
                                                    'primary.contrastText',
                                            },
                                    },
                                }}
                            >
                                <ListItemIcon
                                    sx={{
                                        minWidth: 40,

                                        color: isActive
                                            ? 'primary.contrastText'
                                            : 'text.secondary',
                                    }}
                                >
                                    <Icon />
                                </ListItemIcon>

                                <ListItemText
                                    primary={
                                        item.label
                                    }
                                />
                            </ListItemButton>
                        );
                    },
                )}
            </List>


            {/*
             * =================================================
             * API BAĞLANTI BİLGİSİ
             * =================================================
             */}

            <Box
                sx={{
                    mt: 'auto',

                    p: 2,
                }}
            >
                <Box
                    sx={{
                        p: 2,

                        borderRadius: 2,

                        bgcolor: 'grey.100',
                    }}
                >
                    <Typography
                        variant="caption"
                        color="text.secondary"
                    >
                        Ana API bağlantısı
                    </Typography>

                    <Typography
                        variant="body2"
                        sx={{
                            mt: 0.5,

                            fontWeight: 500,

                            wordBreak: 'break-word',
                        }}
                    >
                        {env.apiBaseUrl}
                    </Typography>

                    <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{
                            display: 'block',

                            mt: 1.5,
                        }}
                    >
                        Authenticator API
                    </Typography>

                    <Typography
                        variant="body2"
                        sx={{
                            mt: 0.5,

                            fontWeight: 500,

                            wordBreak: 'break-word',
                        }}
                    >
                        {env.authenticatorApiBaseUrl}
                    </Typography>
                </Box>
            </Box>
        </Box>
    );


    return (
        <Box
            component="nav"
            aria-label="Ana navigasyon"
            sx={{
                width: {
                    sm: drawerWidth,
                },

                flexShrink: {
                    sm: 0,
                },
            }}
        >
            {/*
             * =================================================
             * MOBİL DRAWER
             * =================================================
             */}

            <Drawer
                variant="temporary"
                open={mobileOpen}
                onClose={onMobileClose}
                ModalProps={{
                    keepMounted: true,
                }}
                sx={{
                    display: {
                        xs: 'block',

                        sm: 'none',
                    },

                    '& .MuiDrawer-paper': {
                        width: drawerWidth,

                        boxSizing: 'border-box',
                    },
                }}
            >
                {drawerContent}
            </Drawer>


            {/*
             * =================================================
             * MASAÜSTÜ DRAWER
             * =================================================
             */}

            <Drawer
                variant="permanent"
                open
                sx={{
                    display: {
                        xs: 'none',

                        sm: 'block',
                    },

                    '& .MuiDrawer-paper': {
                        width: drawerWidth,

                        boxSizing: 'border-box',

                        borderRight:
                            '1px solid',

                        borderColor:
                            'divider',
                    },
                }}
            >
                {drawerContent}
            </Drawer>
        </Box>
    );
}