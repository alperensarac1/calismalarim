import { useEffect } from 'react';

import {
    Alert,
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControl,
    FormHelperText,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    TextField,
} from '@mui/material';

import {
    Controller,
    useForm,
    useWatch,
} from 'react-hook-form';

import { zodResolver } from '@hookform/resolvers/zod';

import { normalizeApiError } from '../../../services/apiClient';

import { ProjectAutocomplete } from '../../projects/components/ProjectAutocomplete';

import {
    ProjectMemberAutocomplete,
    type ProjectMemberOption,
} from '../../projects/components/ProjectMemberAutocomplete';

import type {
    Project,
} from '../../projects/types/project.types';

import { useCreateTask } from '../hooks/useCreateTask';
import { useUpdateTask } from '../hooks/useUpdateTask';

import {
    taskSchema,
    type TaskFormValues,
} from '../schemas/taskSchema';

import type {
    CreateTaskRequest,
    ProjectTask,
    UpdateTaskRequest,
} from '../types/task.types';

import {
    taskDateInputToIso,
    toTaskDateInputValue,
} from '../utils/taskFormatters';

interface TaskFormDialogProps {
    open: boolean;

    /*
     * task verildiğinde dialog düzenleme,
     * verilmediğinde oluşturma modunda çalışır.
     */
    task?: ProjectTask | null;

    /*
     * Proje detay sayfasından görev oluşturulurken
     * proje otomatik seçilebilir.
     */
    defaultProjectId?: number;
    defaultProject?: Project | null;

    onClose: () => void;
}

export function TaskFormDialog({
                                   open,
                                   task = null,
                                   defaultProjectId = 0,
                                   defaultProject = null,
                                   onClose,
                               }: TaskFormDialogProps) {
    const createMutation =
        useCreateTask();

    const updateMutation =
        useUpdateTask();

    const isEditMode =
        task !== null;

    const isProjectLocked =
        defaultProjectId > 0 ||
        defaultProject !== null;

    const {
        control,
        handleSubmit,
        reset,
        setValue,

        formState: {
            errors,
            isSubmitting,
        },
    } = useForm<TaskFormValues>({
        resolver: zodResolver(
            taskSchema,
        ),

        defaultValues: {
            projectId: defaultProjectId,
            title: '',
            description: '',
            assignedToUserId: 0,
            status: 'Todo',
            priority: 'Low',
            dueDate: '',
            estimatedHours: 0,
        },
    });

    const selectedProjectId =
        useWatch({
            control,
            name: 'projectId',
        });

    useEffect(() => {
        if (!open) {
            return;
        }

        if (task) {
            reset({
                projectId: task.projectId,

                title: task.title,

                description:
                    task.description ?? '',

                assignedToUserId:
                    task.assignedToUserId ?? 0,

                status: task.status,

                priority: task.priority,

                dueDate:
                    toTaskDateInputValue(
                        task.dueDate,
                    ),

                estimatedHours:
                task.estimatedHours,
            });

            return;
        }

        const initialProjectId =
            defaultProject?.id ??
            defaultProjectId;

        reset({
            projectId:
            initialProjectId,

            title: '',

            description: '',

            assignedToUserId: 0,

            status: 'Todo',

            priority: 'Low',

            dueDate: '',

            estimatedHours: 0,
        });

    }, [
        open,
        task,
        reset,
        defaultProjectId,
        defaultProject,
    ]);

    const mutationError =
        createMutation.error ??
        updateMutation.error;

    const normalizedError =
        mutationError
            ? normalizeApiError(
                mutationError,
            )
            : null;

    const isPending =
        createMutation.isPending ||
        updateMutation.isPending ||
        isSubmitting;

    /*
     * Düzenleme ekranında seçili projenin adının
     * Autocomplete içinde gösterilmesini sağlar.
     *
     * Project modelinde zorunlu olup görev response'unda
     * bulunmayan alanlar yalnızca gösterim amacıyla doldurulur.
     */
    const initialProject:
        | Project
        | null = task
        ? {
            id: task.projectId,

            name: task.projectName,

            description: null,

            startDate: null,
            endDate: null,

            status: 'Active',

            ownerId: 0,
            ownerFullName:
                'Proje sahibi',
            ownerEmail: '',

            isArchived: false,
            archivedAt: null,

            memberCount: 0,
            taskCount: 0,

            createdAt: task.createdAt,

            updatedAt:
                task.updatedAt ??
                task.createdAt,
        }
        : defaultProject;

    /*
     * Düzenleme sırasında mevcut atanmış kullanıcı henüz
     * proje üyesi sorgusunda bulunmadığında seçili değeri gösterir.
     */
    const initialAssignedMember:
        | ProjectMemberOption
        | null =
        task?.assignedToUserId &&
        task.assignedToUserFullName
            ? {
                userId:
                task.assignedToUserId,

                fullName:
                task.assignedToUserFullName,

                email: '',

                systemRole:
                    'TeamMember',

                projectRole:
                    'Member',

                isActive: true,

                isProjectOwner: false,
            }
            : null;

    const handleDialogClose =
        (): void => {
            if (isPending) {
                return;
            }

            createMutation.reset();
            updateMutation.reset();

            onClose();
        };

    const handleSave = async (
        values: TaskFormValues,
    ): Promise<void> => {
        /*
         * Swagger request modelinde assignedToUserId sayı olarak
         * tanımlandığı için atanmamış durumda null yerine 0 gönderiyoruz.
         */
        const commonRequest = {
            title:
                values.title.trim(),

            description:
                values.description.trim(),

            assignedToUserId:
                values.assignedToUserId > 0
                    ? values.assignedToUserId
                    : 0,

            status:
            values.status,

            priority:
            values.priority,

            dueDate:
                taskDateInputToIso(
                    values.dueDate,
                ),

            estimatedHours:
            values.estimatedHours,
        };

        try {
            if (task) {
                const request:
                    UpdateTaskRequest = {
                    ...commonRequest,
                };

                await updateMutation.mutateAsync({
                    taskId: task.id,
                    request,
                });
            } else {
                const request:
                    CreateTaskRequest = {
                    projectId:
                    values.projectId,

                    ...commonRequest,
                };

                await createMutation.mutateAsync(
                    request,
                );
            }

            handleDialogClose();
        } catch {
            /*
             * API hatası dialog içindeki Alert üzerinden gösterilir.
             */
        }
    };

    return (
        <Dialog
            open={open}
            onClose={handleDialogClose}
            fullWidth
            maxWidth="sm"
        >
            <DialogTitle>
                {isEditMode
                    ? 'Görevi düzenle'
                    : 'Yeni görev oluştur'}
            </DialogTitle>

            <DialogContent dividers>
                <Stack spacing={2.5}>
                    {normalizedError && (
                        <Alert severity="error">
                            {normalizedError.message}
                        </Alert>
                    )}

                    <Controller
                        name="projectId"
                        control={control}
                        render={({ field }) => (
                            <ProjectAutocomplete
                                value={field.value}
                                onChange={(nextProjectId) => {
                                    /*
                                     * Proje değiştiğinde önceki projeden kalan
                                     * kullanıcı atamasını temizliyoruz.
                                     */
                                    field.onChange(nextProjectId);

                                    setValue(
                                        'assignedToUserId',
                                        0,
                                        {
                                            shouldDirty: true,
                                            shouldValidate: true,
                                        },
                                    );
                                }}
                                disabled={
                                    isPending ||
                                    isEditMode ||
                                    isProjectLocked
                                }
                                error={Boolean(
                                    errors.projectId,
                                )}
                                helperText={
                                    errors.projectId
                                        ?.message ??
                                    (isEditMode
                                        ? 'Görev düzenlenirken proje değiştirilemez.'
                                        : isProjectLocked
                                            ? 'Görev bu proje için oluşturulacaktır.'
                                            : 'Görevin bağlı olduğu projeyi seçiniz.')
                                }
                                initialProject={
                                    initialProject
                                }
                            />
                        )}
                    />

                    <Controller
                        name="title"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Görev başlığı"
                                autoFocus
                                disabled={isPending}
                                error={Boolean(
                                    errors.title,
                                )}
                                helperText={
                                    errors.title?.message
                                }
                            />
                        )}
                    />

                    <Controller
                        name="description"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Açıklama"
                                multiline
                                minRows={4}
                                disabled={isPending}
                                error={Boolean(
                                    errors.description,
                                )}
                                helperText={
                                    errors.description
                                        ?.message
                                }
                            />
                        )}
                    />

                    {/*
           * Artık tüm sistem kullanıcıları yerine yalnızca
           * seçilen projenin aktif üyeleri listelenir.
           */}
                    <Controller
                        name="assignedToUserId"
                        control={control}
                        render={({ field }) => (
                            <ProjectMemberAutocomplete
                                projectId={
                                    selectedProjectId
                                }
                                value={field.value}
                                onChange={
                                    field.onChange
                                }
                                disabled={
                                    isPending ||
                                    selectedProjectId <= 0
                                }
                                error={Boolean(
                                    errors.assignedToUserId,
                                )}
                                helperText={
                                    errors.assignedToUserId
                                        ?.message ??
                                    (selectedProjectId <= 0
                                        ? 'Önce proje seçiniz.'
                                        : 'Görevin atanacağı proje üyesini seçiniz. Alanı boş bırakırsanız görev atanmaz.')
                                }
                                initialMember={
                                    initialAssignedMember
                                }
                            />
                        )}
                    />

                    <Stack
                        direction={{
                            xs: 'column',
                            sm: 'row',
                        }}
                        spacing={2}
                    >
                        <Controller
                            name="status"
                            control={control}
                            render={({ field }) => (
                                <FormControl
                                    fullWidth
                                    size="small"
                                    error={Boolean(
                                        errors.status,
                                    )}
                                >
                                    <InputLabel id="task-form-status-label">
                                        Durum
                                    </InputLabel>

                                    <Select
                                        {...field}
                                        labelId="task-form-status-label"
                                        label="Durum"
                                        disabled={isPending}
                                    >
                                        <MenuItem value="Todo">
                                            Yapılacak
                                        </MenuItem>

                                        <MenuItem value="InProgress">
                                            Devam ediyor
                                        </MenuItem>

                                        <MenuItem value="InReview">
                                            İncelemede
                                        </MenuItem>

                                        <MenuItem value="Done">
                                            Tamamlandı
                                        </MenuItem>
                                    </Select>

                                    {errors.status
                                        ?.message && (
                                        <FormHelperText>
                                            {
                                                errors.status
                                                    .message
                                            }
                                        </FormHelperText>
                                    )}
                                </FormControl>
                            )}
                        />

                        <Controller
                            name="priority"
                            control={control}
                            render={({ field }) => (
                                <FormControl
                                    fullWidth
                                    size="small"
                                    error={Boolean(
                                        errors.priority,
                                    )}
                                >
                                    <InputLabel id="task-form-priority-label">
                                        Öncelik
                                    </InputLabel>

                                    <Select
                                        {...field}
                                        labelId="task-form-priority-label"
                                        label="Öncelik"
                                        disabled={isPending}
                                    >
                                        <MenuItem value="Low">
                                            Düşük
                                        </MenuItem>

                                        <MenuItem value="Medium">
                                            Orta
                                        </MenuItem>

                                        <MenuItem value="High">
                                            Yüksek
                                        </MenuItem>

                                        <MenuItem value="Critical">
                                            Kritik
                                        </MenuItem>
                                    </Select>

                                    {errors.priority
                                        ?.message && (
                                        <FormHelperText>
                                            {
                                                errors.priority
                                                    .message
                                            }
                                        </FormHelperText>
                                    )}
                                </FormControl>
                            )}
                        />
                    </Stack>

                    <Stack
                        direction={{
                            xs: 'column',
                            sm: 'row',
                        }}
                        spacing={2}
                    >
                        <Controller
                            name="dueDate"
                            control={control}
                            render={({ field }) => (
                                <TextField
                                    {...field}
                                    fullWidth
                                    label="Teslim tarihi"
                                    type="date"
                                    disabled={isPending}
                                    error={Boolean(
                                        errors.dueDate,
                                    )}
                                    helperText={
                                        errors.dueDate
                                            ?.message
                                    }
                                    slotProps={{
                                        inputLabel: {
                                            shrink: true,
                                        },
                                    }}
                                />
                            )}
                        />

                        <Controller
                            name="estimatedHours"
                            control={control}
                            render={({
                                         field: {
                                             onChange,
                                             value,
                                             ...field
                                         },
                                     }) => (
                                <TextField
                                    {...field}
                                    fullWidth
                                    value={value}
                                    label="Tahmini süre"
                                    type="number"
                                    disabled={isPending}
                                    error={Boolean(
                                        errors.estimatedHours,
                                    )}
                                    helperText={
                                        errors.estimatedHours
                                            ?.message
                                    }
                                    onChange={(event) => {
                                        const nextValue =
                                            event.target.value;

                                        onChange(
                                            nextValue === ''
                                                ? 0
                                                : Number(
                                                    nextValue,
                                                ),
                                        );
                                    }}
                                    slotProps={{
                                        htmlInput: {
                                            min: 0,
                                            step: 0.5,
                                        },
                                    }}
                                />
                            )}
                        />
                    </Stack>
                </Stack>
            </DialogContent>

            <DialogActions
                sx={{
                    px: 3,
                    py: 2,
                }}
            >
                <Button
                    onClick={
                        handleDialogClose
                    }
                    disabled={isPending}
                >
                    İptal
                </Button>

                <Button
                    variant="contained"
                    disabled={isPending}
                    onClick={handleSubmit(
                        handleSave,
                    )}
                    startIcon={
                        isPending ? (
                            <CircularProgress
                                size={18}
                                color="inherit"
                            />
                        ) : undefined
                    }
                >
                    {isEditMode
                        ? 'Değişiklikleri kaydet'
                        : 'Görevi oluştur'}
                </Button>
            </DialogActions>
        </Dialog>
    );
}