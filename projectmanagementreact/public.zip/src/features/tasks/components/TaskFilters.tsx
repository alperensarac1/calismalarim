import ClearRoundedIcon from '@mui/icons-material/ClearRounded';
import FilterAltRoundedIcon from '@mui/icons-material/FilterAltRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';

import {
    Box,
    Button,
    FormControl,
    InputAdornment,
    InputLabel,
    MenuItem,
    Paper,
    Select,
    Stack,
    TextField,
    Typography,
} from '@mui/material';

import {
    useEffect,
    useState,
} from 'react';

import { ProjectAutocomplete } from '../../projects/components/ProjectAutocomplete';

import {
    ProjectMemberAutocomplete,
} from '../../projects/components/ProjectMemberAutocomplete';

import type {
    TaskPriority,
    TaskStatus,
} from '../types/task.types';

/*
 * Geciken görev filtresinin UI modeli.
 */
export type TaskOverdueFilter =
    | 'all'
    | 'overdue'
    | 'notOverdue';

export interface TaskFilterValues {
    search: string;
    projectId: number;
    assignedToUserId: number;
    status: TaskStatus | '';
    priority: TaskPriority | '';
    overdue: TaskOverdueFilter;
}

interface TaskFiltersProps {
    value: TaskFilterValues;

    onChange: (
        nextValue: TaskFilterValues,
    ) => void;

    onClear: () => void;
}

interface TaskSearchFieldProps {
    initialValue: string;

    onSearchChange: (
        search: string,
    ) => void;
}

/*
 * Arama alanını ayrı bir bileşene ayırıyoruz.
 *
 * TaskFilters içinde key={value.search} ile kullanıldığı için,
 * URL geri/ileri işlemlerinde veya filtreler temizlendiğinde
 * bu bileşen yeniden oluşturulur ve başlangıç değeri güncellenir.
 *
 * Böylece useEffect içinde senkron setState çağırmaya gerek kalmaz.
 */
function TaskSearchField({
                             initialValue,
                             onSearchChange,
                         }: TaskSearchFieldProps) {
    const [
        searchText,
        setSearchText,
    ] = useState(initialValue);

    /*
     * Arama için 400 ms debounce uygulanır.
     *
     * Effect içinde React state'i güncellenmez;
     * yalnızca dışarıdaki filtre state'i zamanlayıcı
     * tamamlandığında bilgilendirilir.
     */
    useEffect(() => {
        const normalizedSearch =
            searchText.trim();

        if (
            normalizedSearch ===
            initialValue
        ) {
            return;
        }

        const timeoutId =
            window.setTimeout(() => {
                onSearchChange(
                    normalizedSearch,
                );
            }, 400);

        return () => {
            window.clearTimeout(
                timeoutId,
            );
        };
    }, [
        searchText,
        initialValue,
        onSearchChange,
    ]);

    return (
        <TextField
            value={searchText}
            label="Görev ara"
            placeholder="Başlık veya açıklama..."
            onChange={(event) => {
                setSearchText(
                    event.target.value,
                );
            }}
            slotProps={{
                input: {
                    startAdornment: (
                        <InputAdornment position="start">
                            <SearchRoundedIcon />
                        </InputAdornment>
                    ),
                },
            }}
        />
    );
}

export function TaskFilters({
                                value,
                                onChange,
                                onClear,
                            }: TaskFiltersProps) {
    const hasActiveFilters =
        value.search.length > 0 ||
        value.projectId > 0 ||
        value.assignedToUserId > 0 ||
        value.status !== '' ||
        value.priority !== '' ||
        value.overdue !== 'all';

    return (
        <Paper
            elevation={0}
            sx={{
                p: 2.5,
                border: '1px solid',
                borderColor: 'divider',
            }}
        >
            <Stack spacing={2.5}>
                <Stack
                    direction="row"
                    spacing={1}
                    sx={{
                        alignItems: 'center',
                    }}
                >
                    <FilterAltRoundedIcon
                        color="action"
                    />

                    <Typography variant="h6">
                        Görev filtreleri
                    </Typography>
                </Stack>

                <Box
                    sx={{
                        display: 'grid',

                        gridTemplateColumns: {
                            xs: '1fr',
                            md: 'repeat(2, minmax(0, 1fr))',
                            xl: 'repeat(3, minmax(0, 1fr))',
                        },

                        gap: 2,
                    }}
                >
                    <TaskSearchField
                        /*
                         * URL'deki arama değeri değiştiğinde alt bileşen
                         * yeniden oluşturulur ve input değeri eşitlenir.
                         */
                        key={value.search}
                        initialValue={value.search}
                        onSearchChange={(search) => {
                            onChange({
                                ...value,
                                search,
                            });
                        }}
                    />

                    <ProjectAutocomplete
                        value={value.projectId}
                        onChange={(projectId) => {
                            /*
                             * Proje değiştiğinde önceki projeye ait
                             * kullanıcı filtresini temizliyoruz.
                             */
                            onChange({
                                ...value,
                                projectId,
                                assignedToUserId: 0,
                            });
                        }}
                        helperText="Görevlerin bağlı olduğu projeyi seçiniz."
                    />

                    <ProjectMemberAutocomplete
                        projectId={
                            value.projectId
                        }
                        value={
                            value.assignedToUserId
                        }
                        onChange={(
                            assignedToUserId,
                        ) => {
                            onChange({
                                ...value,
                                assignedToUserId,
                            });
                        }}
                        disabled={
                            value.projectId <= 0
                        }
                        helperText={
                            value.projectId > 0
                                ? 'Atanan proje üyesine göre filtreleyin.'
                                : 'Kullanıcı seçmek için önce proje seçiniz.'
                        }
                    />

                    <FormControl fullWidth>
                        <InputLabel id="task-filter-status-label">
                            Durum
                        </InputLabel>

                        <Select
                            labelId="task-filter-status-label"
                            label="Durum"
                            value={value.status}
                            onChange={(event) => {
                                onChange({
                                    ...value,

                                    status:
                                        event.target
                                            .value as
                                            | TaskStatus
                                            | '',
                                });
                            }}
                        >
                            <MenuItem value="">
                                Tüm durumlar
                            </MenuItem>

                            <MenuItem value="Todo">
                                Yapılacak
                            </MenuItem>

                            <MenuItem value="InProgress">
                                Devam ediyor
                            </MenuItem>

                            <MenuItem value="InReview">
                                İncelemede
                            </MenuItem>

                            <MenuItem value="Done">
                                Tamamlandı
                            </MenuItem>
                        </Select>
                    </FormControl>

                    <FormControl fullWidth>
                        <InputLabel id="task-filter-priority-label">
                            Öncelik
                        </InputLabel>

                        <Select
                            labelId="task-filter-priority-label"
                            label="Öncelik"
                            value={value.priority}
                            onChange={(event) => {
                                onChange({
                                    ...value,

                                    priority:
                                        event.target
                                            .value as
                                            | TaskPriority
                                            | '',
                                });
                            }}
                        >
                            <MenuItem value="">
                                Tüm öncelikler
                            </MenuItem>

                            <MenuItem value="Low">
                                Düşük
                            </MenuItem>

                            <MenuItem value="Medium">
                                Orta
                            </MenuItem>

                            <MenuItem value="High">
                                Yüksek
                            </MenuItem>

                            <MenuItem value="Critical">
                                Kritik
                            </MenuItem>
                        </Select>
                    </FormControl>

                    <FormControl fullWidth>
                        <InputLabel id="task-filter-overdue-label">
                            Teslim durumu
                        </InputLabel>

                        <Select
                            labelId="task-filter-overdue-label"
                            label="Teslim durumu"
                            value={value.overdue}
                            onChange={(event) => {
                                onChange({
                                    ...value,

                                    overdue:
                                        event.target
                                            .value as TaskOverdueFilter,
                                });
                            }}
                        >
                            <MenuItem value="all">
                                Tüm görevler
                            </MenuItem>

                            <MenuItem value="overdue">
                                Yalnızca gecikenler
                            </MenuItem>

                            <MenuItem value="notOverdue">
                                Gecikmemiş görevler
                            </MenuItem>
                        </Select>
                    </FormControl>
                </Box>

                <Stack
                    direction="row"
                    spacing={1}
                    sx={{
                        justifyContent:
                            'flex-end',
                    }}
                >
                    <Button
                        variant="outlined"
                        startIcon={
                            <ClearRoundedIcon />
                        }
                        disabled={
                            !hasActiveFilters
                        }
                        onClick={onClear}
                    >
                        Filtreleri temizle
                    </Button>
                </Stack>
            </Stack>
        </Paper>
    );
}
