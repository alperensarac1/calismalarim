import { useEffect } from 'react';

import LockOutlinedIcon from '@mui/icons-material/LockOutlined';

import {
    Alert,
    Avatar,
    Box,
    Button,
    CircularProgress,
    Container,
    Paper,
    Stack,
    TextField,
    Typography,
} from '@mui/material';

import {
    zodResolver,
} from '@hookform/resolvers/zod';

import {
    Controller,
    useForm,
} from 'react-hook-form';

import {
    useLocation,
    useNavigate,
} from 'react-router-dom';

import { env } from '../../../config/env';

import {
    loginSchema,
    type LoginFormValues,
} from '../schemas/loginSchema';

import {
    useAuthStore,
} from '../store/authStore';


/*
 * =========================================================
 * ROUTE STATE MODELİ
 * =========================================================
 */


/**
 * Kullanıcı korumalı bir sayfaya erişmeye çalışırken
 * login sayfasına gönderilmişse, giriş sonrasında
 * hangi sayfaya dönüleceğini temsil eder.
 */
interface LoginLocationState {
    from?: {
        pathname?: string;
    };
}


/*
 * =========================================================
 * LOGIN SAYFASI
 * =========================================================
 */


/**
 * Kullanıcının e-posta ve şifresiyle giriş yaptığı
 * sayfadır.
 *
 * Yeni giriş akışı:
 *
 * 1. Kullanıcı e-posta ve şifresini girer.
 * 2. .NET backend bilgileri doğrular.
 * 3. Access token geçici olarak saklanır.
 * 4. Kullanıcı Authenticator doğrulama sayfasına gider.
 * 5. Mobil cihazdaki 6 haneli kod veya 987456 girilir.
 * 6. Doğrulama tamamlanınca hedef sayfa açılır.
 */
export function LoginPage() {
    const navigate =
        useNavigate();

    const location =
        useLocation();


    /*
     * =====================================================
     * AUTH STORE
     * =====================================================
     */


    const isLoggingIn =
        useAuthStore(
            (state) => state.isLoggingIn,
        );

    const isAuthenticated =
        useAuthStore(
            (state) => state.isAuthenticated,
        );

    const isAwaitingAuthenticatorVerification =
        useAuthStore(
            (state) =>
                state
                    .isAwaitingAuthenticatorVerification,
        );

    const errorMessage =
        useAuthStore(
            (state) => state.errorMessage,
        );

    const login =
        useAuthStore(
            (state) => state.login,
        );

    const clearError =
        useAuthStore(
            (state) => state.clearError,
        );


    /*
     * =====================================================
     * FORM
     * =====================================================
     */


    const {
        control,
        handleSubmit,
        formState: {
            errors,
            isSubmitting,
        },
    } = useForm<LoginFormValues>({
        resolver:
            zodResolver(
                loginSchema,
            ),

        defaultValues: {
            email: '',
            password: '',
        },

        mode: 'onBlur',
    });


    /*
     * Sayfadan çıkıldığında eski hata mesajını temizler.
     */
    useEffect(
        () => {
            return () => {
                clearError();
            };
        },
        [
            clearError,
        ],
    );


    /*
     * Kullanıcı zaten tam giriş yapmışsa login
     * sayfasında kalmamalıdır.
     */
    useEffect(
        () => {
            if (isAuthenticated) {
                navigate(
                    '/dashboard',
                    {
                        replace: true,
                    },
                );
            }
        },
        [
            isAuthenticated,
            navigate,
        ],
    );


    /*
     * Kullanıcı şifre aşamasını tamamlamış ancak
     * Authenticator doğrulaması bekliyorsa doğrulama
     * sayfasına gönderilir.
     *
     * Bu kontrol sayfa yenilendiğinde de çalışır.
     */
    useEffect(
        () => {
            if (
                !isAuthenticated &&
                isAwaitingAuthenticatorVerification
            ) {
                navigate(
                    '/authenticator-verification',
                    {
                        replace: true,
                    },
                );
            }
        },
        [
            isAuthenticated,
            isAwaitingAuthenticatorVerification,
            navigate,
        ],
    );


    /*
     * =====================================================
     * LOGIN İŞLEMİ
     * =====================================================
     */


    /**
     * E-posta ve şifreyle giriş işlemini başlatır.
     *
     * Giriş başarılı olduğunda kullanıcı artık doğrudan
     * dashboard'a gönderilmez. Önce Authenticator
     * doğrulama ekranına gider.
     */
    async function handleLogin(
        values: LoginFormValues,
    ): Promise<void> {
        const isSuccessful =
            await login({
                email:
                values.email,

                password:
                values.password,
            });

        if (!isSuccessful) {
            return;
        }


        /*
         * Kullanıcı korumalı bir sayfadan login
         * ekranına geldiyse Authenticator doğrulaması
         * tamamlandıktan sonra o sayfaya döner.
         */
        const locationState =
            location.state as
                | LoginLocationState
                | null;

        const targetPath =
            locationState?.from?.pathname ??
            '/dashboard';


        /*
         * Şifre doğrulaması tamamlandı.
         *
         * Artık Python servisinde challenge
         * oluşturulacak Authenticator sayfasına
         * yönlendiriyoruz.
         */
        navigate(
            '/authenticator-verification',
            {
                replace: true,

                state: {
                    targetPath,
                },
            },
        );
    }


    /*
     * Form gönderilirken alanları ve butonu pasif
     * hâle getiriyoruz.
     */
    const isFormBusy =
        isLoggingIn ||
        isSubmitting;


    /*
     * =====================================================
     * JSX
     * =====================================================
     */


    return (
        <Box
            component="main"
            sx={{
                minHeight: '100vh',

                display: 'flex',

                alignItems: 'center',

                py: 4,

                background:
                    'linear-gradient(135deg, ' +
                    '#EFF6FF 0%, #F5F3FF 100%)',
            }}
        >
            <Container
                maxWidth="sm"
            >
                <Paper
                    elevation={0}
                    sx={{
                        p: {
                            xs: 3,
                            sm: 5,
                        },

                        border:
                            '1px solid',

                        borderColor:
                            'divider',
                    }}
                >
                    <Stack
                        spacing={3}
                    >
                        {/*
                         * =====================================
                         * BAŞLIK
                         * =====================================
                         */}

                        <Stack
                            spacing={2}
                            sx={{
                                alignItems:
                                    'center',

                                textAlign:
                                    'center',
                            }}
                        >
                            <Avatar
                                sx={{
                                    width: 56,

                                    height: 56,

                                    bgcolor:
                                        'primary.main',
                                }}
                            >
                                <LockOutlinedIcon />
                            </Avatar>

                            <Box>
                                <Typography
                                    component="h1"
                                    variant="h4"
                                >
                                    Giriş yap
                                </Typography>

                                <Typography
                                    color="text.secondary"
                                    sx={{
                                        mt: 1,
                                    }}
                                >
                                    {env.appName}
                                </Typography>
                            </Box>
                        </Stack>


                        {/*
                         * =====================================
                         * HATA MESAJI
                         * =====================================
                         */}

                        {errorMessage && (
                            <Alert
                                severity="error"
                            >
                                {errorMessage}
                            </Alert>
                        )}


                        {/*
                         * =====================================
                         * LOGIN FORMU
                         * =====================================
                         */}

                        <Box
                            component="form"
                            noValidate
                            onSubmit={handleSubmit(
                                handleLogin,
                            )}
                        >
                            <Stack
                                spacing={2.5}
                            >
                                <Controller
                                    name="email"
                                    control={control}
                                    render={({
                                                 field,
                                             }) => (
                                        <TextField
                                            {...field}
                                            label="E-posta"
                                            type="email"
                                            autoComplete="email"
                                            autoFocus
                                            disabled={
                                                isFormBusy
                                            }
                                            error={Boolean(
                                                errors.email,
                                            )}
                                            helperText={
                                                errors.email
                                                    ?.message
                                            }
                                            fullWidth
                                        />
                                    )}
                                />

                                <Controller
                                    name="password"
                                    control={control}
                                    render={({
                                                 field,
                                             }) => (
                                        <TextField
                                            {...field}
                                            label="Şifre"
                                            type="password"
                                            autoComplete="current-password"
                                            disabled={
                                                isFormBusy
                                            }
                                            error={Boolean(
                                                errors.password,
                                            )}
                                            helperText={
                                                errors.password
                                                    ?.message
                                            }
                                            fullWidth
                                        />
                                    )}
                                />

                                <Button
                                    type="submit"
                                    variant="contained"
                                    size="large"
                                    disabled={
                                        isFormBusy
                                    }
                                    sx={{
                                        minHeight: 46,
                                    }}
                                >
                                    {isFormBusy ? (
                                        <CircularProgress
                                            size={24}
                                            color="inherit"
                                        />
                                    ) : (
                                        'Giriş yap'
                                    )}
                                </Button>
                            </Stack>
                        </Box>


                        {/*
                         * =====================================
                         * BİLGİ MESAJLARI
                         * =====================================
                         */}

                        <Alert
                            severity="info"
                        >
                            Giriş sonrasında mobil
                            Authenticator doğrulaması
                            istenecektir.
                        </Alert>

                        <Alert
                            severity="info"
                            variant="outlined"
                        >
                            Test hesabı:{' '}
                            <strong>
                                admin@projectmanagement.local
                            </strong>
                        </Alert>
                    </Stack>
                </Paper>
            </Container>
        </Box>
    );
}