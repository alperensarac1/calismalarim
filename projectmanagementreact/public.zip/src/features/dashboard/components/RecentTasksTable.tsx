import AssignmentOutlinedIcon from '@mui/icons-material/AssignmentOutlined';
import OpenInNewRoundedIcon from '@mui/icons-material/OpenInNewRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';

import {
    Alert,
    Box,
    Button,
    Chip,
    CircularProgress,
    IconButton,
    Paper,
    Skeleton,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Tooltip,
    Typography,
} from '@mui/material';

import type {
    ChipProps,
} from '@mui/material';

import { useNavigate } from 'react-router-dom';

import type {
    DashboardRecentTask,
    DashboardTaskPriority,
    DashboardTaskStatus,
} from '../types/dashboard.types';


interface RecentTasksTableProps {
    tasks: DashboardRecentTask[];
    isLoading: boolean;
    isFetching: boolean;
    isError: boolean;
    errorMessage?: string;
    onRefresh: () => void;
}


function getTaskStatusLabel(
    status: DashboardTaskStatus,
): string {
    const labels: Record<
        DashboardTaskStatus,
        string
    > = {
        Todo: 'Yapılacak',
        InProgress: 'Devam ediyor',
        InReview: 'İncelemede',
        Done: 'Tamamlandı',
    };

    return labels[status];
}


function getTaskStatusColor(
    status: DashboardTaskStatus,
): ChipProps['color'] {
    const colors: Record<
        DashboardTaskStatus,
        ChipProps['color']
    > = {
        Todo: 'default',
        InProgress: 'info',
        InReview: 'warning',
        Done: 'success',
    };

    return colors[status];
}


function getTaskPriorityLabel(
    priority: DashboardTaskPriority,
): string {
    const labels: Record<
        DashboardTaskPriority,
        string
    > = {
        Low: 'Düşük',
        Medium: 'Orta',
        High: 'Yüksek',
        Critical: 'Kritik',
    };

    return labels[priority];
}


function getTaskPriorityColor(
    priority: DashboardTaskPriority,
): ChipProps['color'] {
    const colors: Record<
        DashboardTaskPriority,
        ChipProps['color']
    > = {
        Low: 'default',
        Medium: 'info',
        High: 'warning',
        Critical: 'error',
    };

    return colors[priority];
}


function formatTaskDate(
    value: string | null,
): string {
    if (!value) {
        return 'Tarih belirtilmedi';
    }

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return 'Geçersiz tarih';
    }

    return new Intl.DateTimeFormat('tr-TR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
    }).format(date);
}

function RecentTasksTableSkeleton() {
    return (
        <TableBody>
            {Array.from({ length: 5 }).map(
                (_, index) => (
                    <TableRow key={index}>
                        <TableCell>
                            <Skeleton width="80%" />
                            <Skeleton width="45%" />
                        </TableCell>

                        <TableCell>
                            <Skeleton width={110} />
                        </TableCell>

                        <TableCell>
                            <Skeleton
                                variant="rounded"
                                width={90}
                                height={26}
                            />
                        </TableCell>

                        <TableCell>
                            <Skeleton
                                variant="rounded"
                                width={70}
                                height={26}
                            />
                        </TableCell>

                        <TableCell>
                            <Skeleton width={120} />
                        </TableCell>

                        <TableCell>
                            <Skeleton width={90} />
                        </TableCell>

                        <TableCell align="right">
                            <Skeleton
                                variant="circular"
                                width={32}
                                height={32}
                                sx={{
                                    ml: 'auto',
                                }}
                            />
                        </TableCell>
                    </TableRow>
                ),
            )}
        </TableBody>
    );
}

export function RecentTasksTable({
                                     tasks,
                                     isLoading,
                                     isFetching,
                                     isError,
                                     errorMessage,
                                     onRefresh,
                                 }: RecentTasksTableProps) {
    const navigate = useNavigate();

    const handleOpenTask = (
        taskId: number,
    ): void => {
        navigate(`/tasks/${taskId}`);
    };

    const handleOpenAllTasks = (): void => {
        navigate('/tasks');
    };

    return (
        <Paper
            elevation={0}
            sx={{
                overflow: 'hidden',
                border: '1px solid',
                borderColor: 'divider',
            }}
        >
            <Stack
                direction={{
                    xs: 'column',
                    sm: 'row',
                }}
                spacing={2}
                sx={{
                    p: 3,
                    alignItems: {
                        xs: 'stretch',
                        sm: 'center',
                    },
                    justifyContent: 'space-between',
                    borderBottom: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Box>
                    <Typography variant="h6">
                        Son görevler
                    </Typography>

                    <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{
                            mt: 0.5,
                        }}
                    >
                        Güncellenen veya oluşturulan son görevler.
                    </Typography>
                </Box>

                <Stack
                    direction="row"
                    spacing={1}
                >
                    <Tooltip title="Görevleri yenile">
            <span>
              <IconButton
                  onClick={onRefresh}
                  disabled={isFetching}
                  aria-label="Son görevleri yenile"
              >
                {isFetching ? (
                    <CircularProgress
                        size={22}
                        color="inherit"
                    />
                ) : (
                    <RefreshRoundedIcon />
                )}
              </IconButton>
            </span>
                    </Tooltip>

                    <Button
                        variant="outlined"
                        onClick={handleOpenAllTasks}
                    >
                        Tüm görevler
                    </Button>
                </Stack>
            </Stack>

            {isError && (
                <Alert
                    severity="error"
                    action={
                        <Button
                            color="inherit"
                            size="small"
                            onClick={onRefresh}
                        >
                            Tekrar dene
                        </Button>
                    }
                    sx={{
                        borderRadius: 0,
                    }}
                >
                    {errorMessage ??
                        'Son görevler alınamadı.'}
                </Alert>
            )}

            <TableContainer>
                <Table
                    sx={{
                        minWidth: 900,
                    }}
                    aria-label="Son görevler tablosu"
                >
                    <TableHead>
                        <TableRow>
                            <TableCell>Görev</TableCell>
                            <TableCell>Proje</TableCell>
                            <TableCell>Durum</TableCell>
                            <TableCell>Öncelik</TableCell>
                            <TableCell>Atanan kişi</TableCell>
                            <TableCell>Son tarih</TableCell>
                            <TableCell align="right">
                                İşlem
                            </TableCell>
                        </TableRow>
                    </TableHead>

                    {isLoading ? (
                        <RecentTasksTableSkeleton />
                    ) : (
                        <TableBody>
                            {tasks.length === 0 ? (
                                <TableRow>
                                    <TableCell
                                        colSpan={7}
                                        sx={{
                                            py: 7,
                                        }}
                                    >
                                        <Stack
                                            spacing={2}
                                            sx={{
                                                alignItems: 'center',
                                                textAlign: 'center',
                                            }}
                                        >
                                            <AssignmentOutlinedIcon
                                                sx={{
                                                    fontSize: 54,
                                                    color: 'text.secondary',
                                                }}
                                            />

                                            <Box>
                                                <Typography variant="h6">
                                                    Görev bulunamadı
                                                </Typography>

                                                <Typography
                                                    variant="body2"
                                                    color="text.secondary"
                                                    sx={{
                                                        mt: 0.5,
                                                    }}
                                                >
                                                    Dashboard üzerinde gösterilecek
                                                    yakın tarihli bir görev bulunmuyor.
                                                </Typography>
                                            </Box>
                                        </Stack>
                                    </TableCell>
                                </TableRow>
                            ) : (
                                tasks.map((task) => (
                                    <TableRow
                                        key={task.id}
                                        hover
                                        sx={{
                                            cursor: 'pointer',
                                        }}
                                        onClick={() =>
                                            handleOpenTask(task.id)
                                        }
                                    >
                                        <TableCell>
                                            <Typography
                                                variant="body2"
                                                sx={{
                                                    maxWidth: 260,
                                                    overflow: 'hidden',
                                                    textOverflow: 'ellipsis',
                                                    whiteSpace: 'nowrap',
                                                    fontWeight: 600,
                                                }}
                                            >
                                                {task.title}
                                            </Typography>

                                            <Typography
                                                variant="caption"
                                                color="text.secondary"
                                            >
                                                Görev #{task.id}
                                            </Typography>
                                        </TableCell>

                                        <TableCell>
                                            <Typography
                                                variant="body2"
                                                sx={{
                                                    maxWidth: 180,
                                                    overflow: 'hidden',
                                                    textOverflow: 'ellipsis',
                                                    whiteSpace: 'nowrap',
                                                }}
                                            >
                                                {task.projectName}
                                            </Typography>
                                        </TableCell>

                                        <TableCell>
                                            <Chip
                                                label={getTaskStatusLabel(
                                                    task.status,
                                                )}
                                                color={getTaskStatusColor(
                                                    task.status,
                                                )}
                                                size="small"
                                                variant="outlined"
                                            />
                                        </TableCell>

                                        <TableCell>
                                            <Chip
                                                label={getTaskPriorityLabel(
                                                    task.priority,
                                                )}
                                                color={getTaskPriorityColor(
                                                    task.priority,
                                                )}
                                                size="small"
                                            />
                                        </TableCell>

                                        <TableCell>
                                            <Typography variant="body2">
                                                {task.assignedToUserFullName ??
                                                    'Atanmamış'}
                                            </Typography>
                                        </TableCell>

                                        <TableCell>
                                            <Stack
                                                spacing={0.5}
                                                sx={{
                                                    alignItems: 'flex-start',
                                                }}
                                            >
                                                <Typography
                                                    variant="body2"
                                                    color={
                                                        task.isOverdue
                                                            ? 'error.main'
                                                            : 'text.primary'
                                                    }
                                                    sx={{
                                                        fontWeight: task.isOverdue
                                                            ? 600
                                                            : 400,
                                                    }}
                                                >
                                                    {formatTaskDate(
                                                        task.dueDate,
                                                    )}
                                                </Typography>

                                                {task.isOverdue && (
                                                    <Chip
                                                        label="Gecikmiş"
                                                        color="error"
                                                        size="small"
                                                        variant="outlined"
                                                    />
                                                )}
                                            </Stack>
                                        </TableCell>

                                        <TableCell align="right">
                                            <Tooltip title="Görevi görüntüle">
                                                <IconButton
                                                    size="small"
                                                    onClick={(event) => {
                                                        event.stopPropagation();

                                                        handleOpenTask(task.id);
                                                    }}
                                                >
                                                    <OpenInNewRoundedIcon
                                                        fontSize="small"
                                                    />
                                                </IconButton>
                                            </Tooltip>
                                        </TableCell>
                                    </TableRow>
                                ))
                            )}
                        </TableBody>
                    )}
                </Table>
            </TableContainer>
        </Paper>
    );
}