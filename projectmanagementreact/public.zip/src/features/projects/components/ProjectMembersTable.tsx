import AddRoundedIcon from '@mui/icons-material/AddRounded';
import EditRoundedIcon from '@mui/icons-material/EditRounded';
import GroupsOutlinedIcon from '@mui/icons-material/GroupsOutlined';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import PersonRemoveRoundedIcon from '@mui/icons-material/PersonRemoveRounded';

import {
    Avatar,
    Box,
    Button,
    Chip,
    IconButton,
    Menu,
    MenuItem,
    Paper,
    Skeleton,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Tooltip,
    Typography,
} from '@mui/material';

import {
    useState,
    type MouseEvent,
} from 'react';

import type { ProjectMember } from '../types/project.types';

import {
    formatProjectMemberDate,
    getProjectMemberRoleColor,
    getProjectMemberRoleLabel,
} from '../utils/projectMemberFormatters';

interface ProjectMembersTableProps {
    members: ProjectMember[];
    isLoading: boolean;
    canManageMembers: boolean;

    onAddMember: () => void;

    onEditMemberRole: (
        member: ProjectMember,
    ) => void;

    onRemoveMember: (
        member: ProjectMember,
    ) => void;
}

interface MemberMenuState {
    anchorElement: HTMLElement;
    member: ProjectMember;
}

function MembersTableSkeleton({
                                  canManageMembers,
                              }: {
    canManageMembers: boolean;
}) {
    return (
        <TableBody>
            {Array.from({
                length: 4,
            }).map((_, index) => (
                <TableRow key={index}>
                    <TableCell>
                        <Stack
                            direction="row"
                            spacing={1.5}
                            sx={{
                                alignItems: 'center',
                            }}
                        >
                            <Skeleton
                                variant="circular"
                                width={40}
                                height={40}
                            />

                            <Box>
                                <Skeleton width={140} />
                                <Skeleton width={190} />
                            </Box>
                        </Stack>
                    </TableCell>

                    <TableCell>
                        <Skeleton width={100} />
                    </TableCell>

                    <TableCell>
                        <Skeleton width={100} />
                    </TableCell>

                    <TableCell>
                        <Skeleton width={100} />
                    </TableCell>

                    <TableCell>
                        <Skeleton width={70} />
                    </TableCell>

                    {canManageMembers && (
                        <TableCell align="right">
                            <Skeleton
                                variant="circular"
                                width={32}
                                height={32}
                                sx={{
                                    ml: 'auto',
                                }}
                            />
                        </TableCell>
                    )}
                </TableRow>
            ))}
        </TableBody>
    );
}

export function ProjectMembersTable({
                                        members,
                                        isLoading,
                                        canManageMembers,
                                        onAddMember,
                                        onEditMemberRole,
                                        onRemoveMember,
                                    }: ProjectMembersTableProps) {
    const [
        menuState,
        setMenuState,
    ] = useState<MemberMenuState | null>(
        null,
    );

    const handleMenuOpen = (
        event: MouseEvent<HTMLElement>,
        member: ProjectMember,
    ): void => {
        event.stopPropagation();

        setMenuState({
            anchorElement: event.currentTarget,
            member,
        });
    };

    const handleMenuClose = (): void => {
        setMenuState(null);
    };

    const handleEditRole = (): void => {
        if (!menuState) {
            return;
        }

        const member = menuState.member;

        handleMenuClose();
        onEditMemberRole(member);
    };

    const handleRemove = (): void => {
        if (!menuState) {
            return;
        }

        const member = menuState.member;

        handleMenuClose();
        onRemoveMember(member);
    };

    return (
        <Paper
            elevation={0}
            sx={{
                overflow: 'hidden',
                border: '1px solid',
                borderColor: 'divider',
            }}
        >
            <Stack
                direction={{
                    xs: 'column',
                    sm: 'row',
                }}
                spacing={2}
                sx={{
                    px: 3,
                    py: 2.5,
                    alignItems: {
                        xs: 'stretch',
                        sm: 'center',
                    },
                    justifyContent: 'space-between',
                    borderBottom: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Box>
                    <Typography variant="h6">
                        Proje üyeleri
                    </Typography>

                    <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{
                            mt: 0.5,
                        }}
                    >
                        Projeye erişimi bulunan kullanıcılar
                        ve proje içindeki rolleri.
                    </Typography>
                </Box>

                {canManageMembers && (
                    <Button
                        variant="contained"
                        startIcon={<AddRoundedIcon />}
                        onClick={onAddMember}
                    >
                        Üye ekle
                    </Button>
                )}
            </Stack>

            <TableContainer>
                <Table
                    sx={{
                        minWidth: 850,
                    }}
                >
                    <TableHead>
                        <TableRow>
                            <TableCell>Kullanıcı</TableCell>
                            <TableCell>Sistem rolü</TableCell>
                            <TableCell>Proje rolü</TableCell>
                            <TableCell>Katılım tarihi</TableCell>
                            <TableCell>Durum</TableCell>

                            {canManageMembers && (
                                <TableCell align="right">
                                    İşlem
                                </TableCell>
                            )}
                        </TableRow>
                    </TableHead>

                    {isLoading ? (
                        <MembersTableSkeleton
                            canManageMembers={
                                canManageMembers
                            }
                        />
                    ) : (
                        <TableBody>
                            {members.length === 0 ? (
                                <TableRow>
                                    <TableCell
                                        colSpan={
                                            canManageMembers
                                                ? 6
                                                : 5
                                        }
                                        sx={{
                                            py: 7,
                                        }}
                                    >
                                        <Stack
                                            spacing={2}
                                            sx={{
                                                alignItems: 'center',
                                                textAlign: 'center',
                                            }}
                                        >
                                            <GroupsOutlinedIcon
                                                sx={{
                                                    fontSize: 54,
                                                    color: 'text.secondary',
                                                }}
                                            />

                                            <Typography variant="h6">
                                                Proje üyesi bulunamadı
                                            </Typography>
                                        </Stack>
                                    </TableCell>
                                </TableRow>
                            ) : (
                                members.map((member) => {
                                    const initials =
                                        `${member.firstName.charAt(0)}${member.lastName.charAt(0)}`
                                            .toUpperCase();

                                    return (
                                        <TableRow
                                            key={member.id}
                                            hover
                                        >
                                            <TableCell>
                                                <Stack
                                                    direction="row"
                                                    spacing={1.5}
                                                    sx={{
                                                        alignItems: 'center',
                                                    }}
                                                >
                                                    <Avatar
                                                        sx={{
                                                            width: 40,
                                                            height: 40,
                                                            bgcolor:
                                                                member.isActive
                                                                    ? 'primary.main'
                                                                    : 'grey.500',
                                                        }}
                                                    >
                                                        {initials}
                                                    </Avatar>

                                                    <Box>
                                                        <Stack
                                                            direction="row"
                                                            spacing={1}
                                                            useFlexGap
                                                            sx={{
                                                                alignItems: 'center',
                                                                flexWrap: 'wrap',
                                                            }}
                                                        >
                                                            <Typography
                                                                variant="body2"
                                                                sx={{
                                                                    fontWeight: 600,
                                                                }}
                                                            >
                                                                {member.fullName}
                                                            </Typography>

                                                            {member.isProjectOwner && (
                                                                <Chip
                                                                    label="Proje sahibi"
                                                                    color="warning"
                                                                    size="small"
                                                                    variant="outlined"
                                                                />
                                                            )}
                                                        </Stack>

                                                        <Typography
                                                            variant="caption"
                                                            color="text.secondary"
                                                        >
                                                            {member.email}
                                                        </Typography>
                                                    </Box>
                                                </Stack>
                                            </TableCell>

                                            <TableCell>
                                                <Chip
                                                    label={member.systemRole}
                                                    size="small"
                                                    variant="outlined"
                                                />
                                            </TableCell>

                                            <TableCell>
                                                {member.isProjectOwner ? (
                                                    <Chip
                                                        label="Proje sahibi"
                                                        color="warning"
                                                        size="small"
                                                    />
                                                ) : (
                                                    <Chip
                                                        label={getProjectMemberRoleLabel(
                                                            member.projectRole,
                                                        )}
                                                        color={getProjectMemberRoleColor(
                                                            member.projectRole,
                                                        )}
                                                        size="small"
                                                        variant="outlined"
                                                    />
                                                )}
                                            </TableCell>

                                            <TableCell>
                                                {formatProjectMemberDate(
                                                    member.joinedAt,
                                                )}
                                            </TableCell>

                                            <TableCell>
                                                <Chip
                                                    label={
                                                        member.isActive
                                                            ? 'Aktif'
                                                            : 'Pasif'
                                                    }
                                                    color={
                                                        member.isActive
                                                            ? 'success'
                                                            : 'default'
                                                    }
                                                    size="small"
                                                />
                                            </TableCell>

                                            {canManageMembers && (
                                                <TableCell align="right">
                                                    {!member.isProjectOwner && (
                                                        <Tooltip title="Üye işlemleri">
                                                            <IconButton
                                                                size="small"
                                                                onClick={(event) =>
                                                                    handleMenuOpen(
                                                                        event,
                                                                        member,
                                                                    )
                                                                }
                                                            >
                                                                <MoreVertRoundedIcon />
                                                            </IconButton>
                                                        </Tooltip>
                                                    )}
                                                </TableCell>
                                            )}
                                        </TableRow>
                                    );
                                })
                            )}
                        </TableBody>
                    )}
                </Table>
            </TableContainer>

            <Menu
                anchorEl={
                    menuState?.anchorElement
                }
                open={Boolean(menuState)}
                onClose={handleMenuClose}
            >
                <MenuItem onClick={handleEditRole}>
                    <EditRoundedIcon
                        fontSize="small"
                        sx={{
                            mr: 1.5,
                        }}
                    />

                    Proje rolünü değiştir
                </MenuItem>

                <MenuItem
                    onClick={handleRemove}
                    sx={{
                        color: 'error.main',
                    }}
                >
                    <PersonRemoveRoundedIcon
                        fontSize="small"
                        sx={{
                            mr: 1.5,
                        }}
                    />

                    Projeden çıkar
                </MenuItem>
            </Menu>
        </Paper>
    );
}