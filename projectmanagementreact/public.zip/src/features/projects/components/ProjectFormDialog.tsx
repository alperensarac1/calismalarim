import { useEffect } from 'react';

import {
    Alert,
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControl,
    FormHelperText,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    TextField,
} from '@mui/material';

import {
    Controller,
    useForm,
} from 'react-hook-form';

import { zodResolver } from '@hookform/resolvers/zod';

import { normalizeApiError } from '../../../services/apiClient';

import { useAuthStore } from '../../auth/store/authStore';

import { UserAutocomplete } from '../../users/components/UserAutocomplete';

import type {
    SystemUser,
} from '../../users/types/user.types';

import { useCreateProject } from '../hooks/useCreateProject';
import { useUpdateProject } from '../hooks/useUpdateProject';

import {
    projectSchema,
    type ProjectFormValues,
} from '../schemas/projectSchema';

import type {
    CreateProjectRequest,
    Project,
    UpdateProjectRequest,
} from '../types/project.types';

import {
    dateInputToIso,
    toDateInputValue,
} from '../utils/projectFormatters';

interface ProjectFormDialogProps {
    open: boolean;
    project?: Project | null;
    onClose: () => void;
}

/*
 * Hem proje oluşturma hem de düzenleme işlemlerinde kullanılan
 * ortak dialog bileşeni.
 */
export function ProjectFormDialog({
                                      open,
                                      project = null,
                                      onClose,
                                  }: ProjectFormDialogProps) {
    const user = useAuthStore(
        (state) => state.user,
    );

    const createProjectMutation =
        useCreateProject();

    const updateProjectMutation =
        useUpdateProject();

    const isEditMode =
        project !== null;

    const isAdmin =
        user?.role === 'Admin';

    const {
        control,
        handleSubmit,
        reset,

        formState: {
            errors,
            isSubmitting,
        },
    } = useForm<ProjectFormValues>({
        resolver: zodResolver(projectSchema),

        defaultValues: {
            name: '',
            description: '',
            startDate: '',
            endDate: '',
            status: 'Planning',
            ownerId: user?.id ?? 0,
        },
    });

    /*
     * Dialog her açıldığında oluşturma veya düzenleme değerleriyle
     * formu sıfırlıyoruz.
     */
    useEffect(() => {
        if (!open) {
            return;
        }

        if (project) {
            reset({
                name: project.name,

                description:
                    project.description ?? '',

                startDate:
                    toDateInputValue(
                        project.startDate,
                    ),

                endDate:
                    toDateInputValue(
                        project.endDate,
                    ),

                status: project.status,

                ownerId: project.ownerId,
            });

            return;
        }

        reset({
            name: '',
            description: '',
            startDate: '',
            endDate: '',
            status: 'Planning',
            ownerId: user?.id ?? 0,
        });
    }, [
        open,
        project,
        reset,
        user?.id,
    ]);

    const mutationError =
        createProjectMutation.error ??
        updateProjectMutation.error;

    const normalizedError =
        mutationError
            ? normalizeApiError(
                mutationError,
            )
            : null;

    const isMutationPending =
        createProjectMutation.isPending ||
        updateProjectMutation.isPending ||
        isSubmitting;

    /*
     * Düzenleme modunda proje sahibi kullanıcının temel bilgilerini
     * mevcut proje response'undan oluşturuyoruz.
     *
     * Kullanıcı arama listesinin ilk sayfasında bulunmasa bile
     * Autocomplete seçili kullanıcıyı gösterebilir.
     */
    const initialOwnerUser:
        | SystemUser
        | null = project
        ? {
            id: project.ownerId,

            firstName:
                project.ownerFullName
                    .split(' ')[0] ?? '',

            lastName:
                project.ownerFullName
                    .split(' ')
                    .slice(1)
                    .join(' '),

            fullName:
            project.ownerFullName,

            email:
            project.ownerEmail,

            /*
             * Project response sahibi rolünü döndürmediği için
             * yalnızca gösterim amacıyla geçici değer kullanıyoruz.
             *
             * Kullanıcı arama sonucu geldiğinde gerçek modelle eşleşir.
             */
            role: 'ProjectManager',

            department: null,

            isActive: true,

            createdAt:
            project.createdAt,
        }
        : null;

    const handleDialogClose =
        (): void => {
            if (isMutationPending) {
                return;
            }

            createProjectMutation.reset();
            updateProjectMutation.reset();

            onClose();
        };

    const handleSave = async (
        values: ProjectFormValues,
    ): Promise<void> => {
        /*
         * Admin formdan seçilen ownerId değerini kullanır.
         *
         * ProjectManager için ownerId aktif kullanıcının id değeri olur.
         */
        const resolvedOwnerId = isAdmin
            ? values.ownerId
            : user?.id ?? 0;

        const request:
            | CreateProjectRequest
            | UpdateProjectRequest = {
            name: values.name.trim(),

            description:
                values.description.trim(),

            startDate:
                dateInputToIso(
                    values.startDate,
                ),

            endDate:
                dateInputToIso(
                    values.endDate,
                ),

            status: values.status,

            ownerId:
            resolvedOwnerId,
        };

        try {
            if (project) {
                await updateProjectMutation.mutateAsync({
                    projectId: project.id,
                    request,
                });
            } else {
                await createProjectMutation.mutateAsync(
                    request,
                );
            }

            handleDialogClose();
        } catch {
            /*
             * Mutation hatası yukarıdaki Alert bileşeninde gösterilir.
             */
        }
    };

    return (
        <Dialog
            open={open}
            onClose={handleDialogClose}
            fullWidth
            maxWidth="sm"
        >
            <DialogTitle>
                {isEditMode
                    ? 'Projeyi düzenle'
                    : 'Yeni proje oluştur'}
            </DialogTitle>

            <DialogContent dividers>
                <Stack spacing={2.5}>
                    {normalizedError && (
                        <Alert severity="error">
                            {normalizedError.errors
                                .length > 0
                                ? normalizedError.errors.join(
                                    ' ',
                                )
                                : normalizedError.message}
                        </Alert>
                    )}

                    <Controller
                        name="name"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Proje adı"
                                disabled={
                                    isMutationPending
                                }
                                error={Boolean(
                                    errors.name,
                                )}
                                helperText={
                                    errors.name?.message
                                }
                                autoFocus
                            />
                        )}
                    />

                    <Controller
                        name="description"
                        control={control}
                        render={({ field }) => (
                            <TextField
                                {...field}
                                label="Açıklama"
                                multiline
                                minRows={4}
                                disabled={
                                    isMutationPending
                                }
                                error={Boolean(
                                    errors.description,
                                )}
                                helperText={
                                    errors.description
                                        ?.message
                                }
                            />
                        )}
                    />

                    <Stack
                        direction={{
                            xs: 'column',
                            sm: 'row',
                        }}
                        spacing={2}
                    >
                        <Controller
                            name="startDate"
                            control={control}
                            render={({ field }) => (
                                <TextField
                                    {...field}
                                    label="Başlangıç tarihi"
                                    type="date"
                                    disabled={
                                        isMutationPending
                                    }
                                    error={Boolean(
                                        errors.startDate,
                                    )}
                                    helperText={
                                        errors.startDate
                                            ?.message
                                    }
                                    slotProps={{
                                        inputLabel: {
                                            shrink: true,
                                        },
                                    }}
                                />
                            )}
                        />

                        <Controller
                            name="endDate"
                            control={control}
                            render={({ field }) => (
                                <TextField
                                    {...field}
                                    label="Bitiş tarihi"
                                    type="date"
                                    disabled={
                                        isMutationPending
                                    }
                                    error={Boolean(
                                        errors.endDate,
                                    )}
                                    helperText={
                                        errors.endDate
                                            ?.message
                                    }
                                    slotProps={{
                                        inputLabel: {
                                            shrink: true,
                                        },
                                    }}
                                />
                            )}
                        />
                    </Stack>

                    <Controller
                        name="status"
                        control={control}
                        render={({ field }) => (
                            <FormControl
                                fullWidth
                                size="small"
                                error={Boolean(
                                    errors.status,
                                )}
                            >
                                <InputLabel id="project-form-status-label">
                                    Durum
                                </InputLabel>

                                <Select
                                    {...field}
                                    labelId="project-form-status-label"
                                    label="Durum"
                                    disabled={
                                        isMutationPending
                                    }
                                >
                                    <MenuItem value="Planning">
                                        Planlama
                                    </MenuItem>

                                    <MenuItem value="Active">
                                        Aktif
                                    </MenuItem>

                                    <MenuItem value="OnHold">
                                        Beklemede
                                    </MenuItem>

                                    <MenuItem value="Completed">
                                        Tamamlandı
                                    </MenuItem>

                                    <MenuItem value="Cancelled">
                                        İptal edildi
                                    </MenuItem>
                                </Select>

                                {errors.status
                                    ?.message && (
                                    <FormHelperText>
                                        {
                                            errors.status
                                                .message
                                        }
                                    </FormHelperText>
                                )}
                            </FormControl>
                        )}
                    />

                    {/*
           * Admin kullanıcı proje sahibini sistem kullanıcıları
           * arasından seçebilir.
           */}
                    {isAdmin ? (
                        <Controller
                            name="ownerId"
                            control={control}
                            render={({ field }) => (
                                <UserAutocomplete
                                    value={field.value}
                                    onChange={
                                        field.onChange
                                    }
                                    disabled={
                                        isMutationPending
                                    }
                                    error={Boolean(
                                        errors.ownerId,
                                    )}
                                    helperText={
                                        errors.ownerId
                                            ?.message
                                    }
                                    initialUser={
                                        initialOwnerUser
                                    }
                                />
                            )}
                        />
                    ) : (
                        <TextField
                            label="Proje sahibi"
                            value={
                                user?.fullName ??
                                'Aktif kullanıcı'
                            }
                            disabled
                            helperText="ProjectManager yeni projenin otomatik olarak sahibi olur."
                        />
                    )}
                </Stack>
            </DialogContent>

            <DialogActions
                sx={{
                    px: 3,
                    py: 2,
                }}
            >
                <Button
                    onClick={
                        handleDialogClose
                    }
                    disabled={
                        isMutationPending
                    }
                >
                    İptal
                </Button>

                <Button
                    variant="contained"
                    disabled={
                        isMutationPending
                    }
                    onClick={handleSubmit(
                        handleSave,
                    )}
                    startIcon={
                        isMutationPending ? (
                            <CircularProgress
                                size={18}
                                color="inherit"
                            />
                        ) : undefined
                    }
                >
                    {isEditMode
                        ? 'Değişiklikleri kaydet'
                        : 'Projeyi oluştur'}
                </Button>
            </DialogActions>
        </Dialog>
    );
}