import ArchiveRoundedIcon from '@mui/icons-material/ArchiveRounded';
import EditRoundedIcon from '@mui/icons-material/EditRounded';
import FolderOffOutlinedIcon from '@mui/icons-material/FolderOffOutlined';
import GroupsRoundedIcon from '@mui/icons-material/GroupsRounded';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import OpenInNewRoundedIcon from '@mui/icons-material/OpenInNewRounded';
import TaskAltRoundedIcon from '@mui/icons-material/TaskAltRounded';

import {
    Box,
    Chip,
    IconButton,
    Link,
    Menu,
    MenuItem,
    Paper,
    Skeleton,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Tooltip,
    Typography,
} from '@mui/material';

import {
    useState,
    type MouseEvent,
} from 'react';

import {
    useNavigate,
} from 'react-router-dom';

import { useAuthStore } from '../../auth/store/authStore';

import type {
    ProjectTask,
} from '../../tasks/types/task.types';

import type {
    Project,
} from '../types/project.types';

import {
    formatProjectDate,
} from '../utils/projectFormatters';

import {
    getProjectPermissions,
} from '../utils/projectPermissions';

import { ProjectStatusChip } from './ProjectStatusChip';

interface ProjectsTableProps {
    projects: Project[];

    isLoading: boolean;

    /*
     * Giriş yapan kullanıcının görevleri,
     * proje ID değerine göre gruplandırılmış olarak gelir.
     *
     * Örnek:
     *
     * {
     *     1: [task1, task2],
     *     5: [task3]
     * }
     */
    myTasksByProjectId: Record<
        number,
        ProjectTask[]
    >;

    /*
     * Kullanıcının kişisel görevleri yüklenirken
     * ilgili sütunda skeleton gösterilir.
     */
    isMyTasksLoading: boolean;

    onEditProject: (
        project: Project,
    ) => void;
}

interface ProjectMenuState {
    anchorElement: HTMLElement;

    project: Project;
}

/*
 * Her proje satırında en fazla gösterilecek
 * kişisel görev sayısı.
 *
 * Geri kalan görevler sayı olarak gösterilir.
 */
const MAX_VISIBLE_MY_TASKS = 2;

/*
 * Proje tablosu yüklenirken gösterilen iskelet.
 */
function ProjectsTableSkeleton() {
    return (
        <TableBody>
            {Array.from({
                length: 6,
            }).map((_, index) => (
                <TableRow key={index}>
                    <TableCell>
                        <Skeleton width="75%" />
                        <Skeleton width="45%" />
                    </TableCell>

                    <TableCell>
                        <Skeleton width={100} />
                        <Skeleton width={130} />
                    </TableCell>

                    <TableCell>
                        <Skeleton
                            variant="rounded"
                            width={90}
                            height={26}
                        />
                    </TableCell>

                    <TableCell>
                        <Skeleton width={110} />
                        <Skeleton width={90} />
                    </TableCell>

                    <TableCell>
                        <Skeleton width={70} />
                    </TableCell>

                    <TableCell>
                        <Skeleton width={70} />
                    </TableCell>

                    <TableCell>
                        <Stack spacing={0.75}>
                            <Skeleton width={170} />
                            <Skeleton width={140} />
                        </Stack>
                    </TableCell>

                    <TableCell align="right">
                        <Skeleton
                            variant="circular"
                            width={32}
                            height={32}
                            sx={{
                                ml: 'auto',
                            }}
                        />
                    </TableCell>
                </TableRow>
            ))}
        </TableBody>
    );
}

export function ProjectsTable({
                                  projects,
                                  isLoading,
                                  myTasksByProjectId,
                                  isMyTasksLoading,
                                  onEditProject,
                              }: ProjectsTableProps) {
    const navigate =
        useNavigate();

    const user =
        useAuthStore(
            (state) => state.user,
        );

    /*
     * İşlem menüsünün açık olduğu projeyi tutar.
     */
    const [
        menuState,
        setMenuState,
    ] = useState<ProjectMenuState | null>(
        null,
    );

    /*
     * Proje işlem menüsünü açar.
     */
    const handleMenuOpen = (
        event: MouseEvent<HTMLElement>,
        project: Project,
    ): void => {
        /*
         * Satırın proje detayına gitmesini engeller.
         */
        event.stopPropagation();

        setMenuState({
            anchorElement:
            event.currentTarget,

            project,
        });
    };

    /*
     * Açık işlem menüsünü kapatır.
     */
    const handleMenuClose =
        (): void => {
            setMenuState(null);
        };

    /*
     * Proje detay sayfasına yönlendirir.
     */
    const handleOpenDetails = (
        projectId: number,
    ): void => {
        handleMenuClose();

        navigate(
            `/projects/${projectId}`,
        );
    };

    /*
     * Proje düzenleme dialogunu açar.
     */
    const handleEdit =
        (): void => {
            if (!menuState) {
                return;
            }

            const selectedProject =
                menuState.project;

            handleMenuClose();

            onEditProject(
                selectedProject,
            );
        };

    /*
     * Menüde seçili proje için giriş yapan kullanıcının
     * düzenleme yetkisini hesaplar.
     */
    const selectedPermissions =
        menuState
            ? getProjectPermissions(
                user,
                menuState.project,
            )
            : null;

    return (
        <Paper
            elevation={0}
            sx={{
                overflow: 'hidden',

                border: '1px solid',
                borderColor: 'divider',
            }}
        >
            <TableContainer>
                <Table
                    sx={{
                        minWidth: 1250,
                    }}
                    aria-label="Projeler tablosu"
                >
                    <TableHead>
                        <TableRow>
                            <TableCell>
                                Proje
                            </TableCell>

                            <TableCell>
                                Sahibi
                            </TableCell>

                            <TableCell>
                                Durum
                            </TableCell>

                            <TableCell>
                                Tarih aralığı
                            </TableCell>

                            <TableCell>
                                Üyeler
                            </TableCell>

                            <TableCell>
                                Toplam görev
                            </TableCell>

                            <TableCell>
                                Benim görevlerim
                            </TableCell>

                            <TableCell align="right">
                                İşlem
                            </TableCell>
                        </TableRow>
                    </TableHead>

                    {isLoading ? (
                        <ProjectsTableSkeleton />
                    ) : (
                        <TableBody>
                            {projects.length === 0 ? (
                                <TableRow>
                                    <TableCell
                                        colSpan={8}
                                        sx={{
                                            py: 8,
                                        }}
                                    >
                                        <Stack
                                            spacing={2}
                                            sx={{
                                                alignItems:
                                                    'center',

                                                textAlign:
                                                    'center',
                                            }}
                                        >
                                            <FolderOffOutlinedIcon
                                                sx={{
                                                    fontSize: 56,

                                                    color:
                                                        'text.secondary',
                                                }}
                                            />

                                            <Box>
                                                <Typography variant="h6">
                                                    Proje bulunamadı
                                                </Typography>

                                                <Typography
                                                    color="text.secondary"
                                                    sx={{
                                                        mt: 0.5,
                                                    }}
                                                >
                                                    Seçilen filtrelere uygun
                                                    proje bulunmuyor.
                                                </Typography>
                                            </Box>
                                        </Stack>
                                    </TableCell>
                                </TableRow>
                            ) : (
                                projects.map(
                                    (project) => {
                                        /*
                                         * Giriş yapan kullanıcının yalnızca
                                         * bu projedeki görevleri.
                                         */
                                        const myProjectTasks =
                                            myTasksByProjectId[
                                                project.id
                                                ] ?? [];

                                        /*
                                         * Satırda ilk iki görevi gösteriyoruz.
                                         */
                                        const visibleMyTasks =
                                            myProjectTasks.slice(
                                                0,
                                                MAX_VISIBLE_MY_TASKS,
                                            );

                                        const remainingTaskCount =
                                            Math.max(
                                                myProjectTasks.length -
                                                visibleMyTasks.length,
                                                0,
                                            );

                                        return (
                                            <TableRow
                                                key={
                                                    project.id
                                                }
                                                hover
                                                onClick={() => {
                                                    handleOpenDetails(
                                                        project.id,
                                                    );
                                                }}
                                                sx={{
                                                    cursor:
                                                        'pointer',
                                                }}
                                            >
                                                {/* Proje adı */}
                                                <TableCell>
                                                    <Stack spacing={0.5}>
                                                        <Typography
                                                            variant="body2"
                                                            sx={{
                                                                maxWidth: 260,

                                                                overflow:
                                                                    'hidden',

                                                                textOverflow:
                                                                    'ellipsis',

                                                                whiteSpace:
                                                                    'nowrap',

                                                                fontWeight: 600,
                                                            }}
                                                        >
                                                            {
                                                                project.name
                                                            }
                                                        </Typography>

                                                        <Stack
                                                            direction="row"
                                                            spacing={1}
                                                            useFlexGap
                                                            sx={{
                                                                alignItems:
                                                                    'center',

                                                                flexWrap:
                                                                    'wrap',
                                                            }}
                                                        >
                                                            <Typography
                                                                variant="caption"
                                                                color="text.secondary"
                                                            >
                                                                Proje #
                                                                {
                                                                    project.id
                                                                }
                                                            </Typography>

                                                            {project.isArchived && (
                                                                <Chip
                                                                    icon={
                                                                        <ArchiveRoundedIcon />
                                                                    }
                                                                    label="Arşivlendi"
                                                                    size="small"
                                                                    variant="outlined"
                                                                />
                                                            )}
                                                        </Stack>
                                                    </Stack>
                                                </TableCell>

                                                {/* Proje sahibi */}
                                                <TableCell>
                                                    <Typography variant="body2">
                                                        {
                                                            project.ownerFullName
                                                        }
                                                    </Typography>

                                                    <Typography
                                                        variant="caption"
                                                        color="text.secondary"
                                                        sx={{
                                                            display:
                                                                'block',

                                                            maxWidth: 200,

                                                            overflow:
                                                                'hidden',

                                                            textOverflow:
                                                                'ellipsis',

                                                            whiteSpace:
                                                                'nowrap',
                                                        }}
                                                    >
                                                        {
                                                            project.ownerEmail
                                                        }
                                                    </Typography>
                                                </TableCell>

                                                {/* Proje durumu */}
                                                <TableCell>
                                                    <ProjectStatusChip
                                                        status={
                                                            project.status
                                                        }
                                                    />
                                                </TableCell>

                                                {/* Tarih aralığı */}
                                                <TableCell>
                                                    <Typography variant="body2">
                                                        {formatProjectDate(
                                                            project.startDate,
                                                        )}
                                                    </Typography>

                                                    <Typography
                                                        variant="caption"
                                                        color="text.secondary"
                                                    >
                                                        {formatProjectDate(
                                                            project.endDate,
                                                        )}
                                                    </Typography>
                                                </TableCell>

                                                {/* Üye sayısı */}
                                                <TableCell>
                                                    <Stack
                                                        direction="row"
                                                        spacing={0.75}
                                                        sx={{
                                                            alignItems:
                                                                'center',
                                                        }}
                                                    >
                                                        <GroupsRoundedIcon
                                                            fontSize="small"
                                                            color="action"
                                                        />

                                                        <Typography variant="body2">
                                                            {
                                                                project.memberCount
                                                            }
                                                        </Typography>
                                                    </Stack>
                                                </TableCell>

                                                {/* Toplam görev sayısı */}
                                                <TableCell>
                                                    <Stack
                                                        direction="row"
                                                        spacing={0.75}
                                                        sx={{
                                                            alignItems:
                                                                'center',
                                                        }}
                                                    >
                                                        <TaskAltRoundedIcon
                                                            fontSize="small"
                                                            color="action"
                                                        />

                                                        <Typography variant="body2">
                                                            {
                                                                project.taskCount
                                                            }
                                                        </Typography>
                                                    </Stack>
                                                </TableCell>

                                                {/* Giriş yapan kullanıcının görevleri */}
                                                <TableCell>
                                                    {isMyTasksLoading ? (
                                                        <Stack spacing={0.75}>
                                                            <Skeleton
                                                                width={180}
                                                            />

                                                            <Skeleton
                                                                width={140}
                                                            />
                                                        </Stack>
                                                    ) : myProjectTasks.length ===
                                                    0 ? (
                                                        <Typography
                                                            variant="body2"
                                                            color="text.secondary"
                                                        >
                                                            Görev atanmamış
                                                        </Typography>
                                                    ) : (
                                                        <Stack spacing={0.75}>
                                                            <Stack
                                                                direction="row"
                                                                spacing={0.75}
                                                                sx={{
                                                                    alignItems:
                                                                        'center',
                                                                }}
                                                            >
                                                                <TaskAltRoundedIcon
                                                                    fontSize="small"
                                                                    color="primary"
                                                                />

                                                                <Typography
                                                                    variant="caption"
                                                                    color="primary"
                                                                    sx={{
                                                                        fontWeight: 700,
                                                                    }}
                                                                >
                                                                    {
                                                                        myProjectTasks.length
                                                                    }{' '}
                                                                    görev
                                                                </Typography>
                                                            </Stack>

                                                            {visibleMyTasks.map(
                                                                (
                                                                    task,
                                                                ) => (
                                                                    <Tooltip
                                                                        key={
                                                                            task.id
                                                                        }
                                                                        title={
                                                                            task.title
                                                                        }
                                                                        placement="top-start"
                                                                    >
                                                                        <Link
                                                                            component="button"
                                                                            type="button"
                                                                            underline="hover"
                                                                            onClick={(
                                                                                event,
                                                                            ) => {
                                                                                /*
                                                                                 * Proje satırına ait tıklama
                                                                                 * olayını engeller.
                                                                                 */
                                                                                event.stopPropagation();

                                                                                navigate(
                                                                                    `/tasks/${task.id}`,
                                                                                );
                                                                            }}
                                                                            sx={{
                                                                                display:
                                                                                    'block',

                                                                                maxWidth: 240,

                                                                                overflow:
                                                                                    'hidden',

                                                                                textOverflow:
                                                                                    'ellipsis',

                                                                                whiteSpace:
                                                                                    'nowrap',

                                                                                textAlign:
                                                                                    'left',

                                                                                fontSize:
                                                                                    '0.8125rem',
                                                                            }}
                                                                        >
                                                                            •{' '}
                                                                            {
                                                                                task.title
                                                                            }
                                                                        </Link>
                                                                    </Tooltip>
                                                                ),
                                                            )}

                                                            {remainingTaskCount >
                                                                0 && (
                                                                    <Typography
                                                                        variant="caption"
                                                                        color="text.secondary"
                                                                    >
                                                                        +
                                                                        {
                                                                            remainingTaskCount
                                                                        }{' '}
                                                                        görev
                                                                        daha
                                                                    </Typography>
                                                                )}
                                                        </Stack>
                                                    )}
                                                </TableCell>

                                                {/* İşlem menüsü */}
                                                <TableCell align="right">
                                                    <Tooltip title="İşlemler">
                                                        <IconButton
                                                            size="small"
                                                            onClick={(
                                                                event,
                                                            ) => {
                                                                handleMenuOpen(
                                                                    event,
                                                                    project,
                                                                );
                                                            }}
                                                        >
                                                            <MoreVertRoundedIcon />
                                                        </IconButton>
                                                    </Tooltip>
                                                </TableCell>
                                            </TableRow>
                                        );
                                    },
                                )
                            )}
                        </TableBody>
                    )}
                </Table>
            </TableContainer>

            {/* Proje işlem menüsü */}
            <Menu
                anchorEl={
                    menuState?.anchorElement
                }
                open={Boolean(
                    menuState,
                )}
                onClose={
                    handleMenuClose
                }
            >
                <MenuItem
                    onClick={() => {
                        if (menuState) {
                            handleOpenDetails(
                                menuState.project.id,
                            );
                        }
                    }}
                >
                    <OpenInNewRoundedIcon
                        fontSize="small"
                        sx={{
                            mr: 1.5,
                        }}
                    />

                    Detayı görüntüle
                </MenuItem>

                {selectedPermissions?.canEdit && (
                    <MenuItem
                        onClick={
                            handleEdit
                        }
                    >
                        <EditRoundedIcon
                            fontSize="small"
                            sx={{
                                mr: 1.5,
                            }}
                        />

                        Düzenle
                    </MenuItem>
                )}
            </Menu>
        </Paper>
    );
}