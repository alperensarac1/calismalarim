import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import GroupOffOutlinedIcon from '@mui/icons-material/GroupOffOutlined';
import LockResetRoundedIcon from '@mui/icons-material/LockResetRounded';
import MoreVertRoundedIcon from '@mui/icons-material/MoreVertRounded';
import PersonSearchRoundedIcon from '@mui/icons-material/PersonSearchRounded';
import ToggleOffRoundedIcon from '@mui/icons-material/ToggleOffRounded';
import ToggleOnRoundedIcon from '@mui/icons-material/ToggleOnRounded';

import {
    Avatar,
    Box,
    Chip,
    IconButton,
    Menu,
    MenuItem,
    Paper,
    Skeleton,
    Stack,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Tooltip,
    Typography,
} from '@mui/material';

import {
    useState,
    type MouseEvent,
} from 'react';

import { useNavigate } from 'react-router-dom';

import { useAuthStore } from '../../auth/store/authStore';

import type {
    SystemUser,
} from '../types/user.types';

import {
    formatUserDate,
    getUserRoleColor,
    getUserRoleLabel,
} from '../utils/userFormatters';

interface UsersTableProps {
    users: SystemUser[];

    isLoading: boolean;

    /*
     * Kullanıcı düzenleme dialogunu açar.
     */
    onEditUser: (
        user: SystemUser,
    ) => void;

    /*
     * Kullanıcı aktiflik durumunu değiştirme dialogunu açar.
     */
    onChangeStatus: (
        user: SystemUser,
    ) => void;

    /*
     * Kullanıcı parola sıfırlama dialogunu açar.
     */
    onResetPassword: (
        user: SystemUser,
    ) => void;

    /*
     * Kullanıcı silme dialogunu açar.
     */
    onDeleteUser: (
        user: SystemUser,
    ) => void;
}

interface UserMenuState {
    anchorElement: HTMLElement;

    user: SystemUser;
}

/*
 * Kullanıcı listesi yüklenirken gösterilen tablo iskeleti.
 */
function UsersTableSkeleton() {
    return (
        <TableBody>
            {Array.from({
                length: 7,
            }).map((_, index) => (
                <TableRow key={index}>
                    <TableCell>
                        <Stack
                            direction="row"
                            spacing={1.5}
                            sx={{
                                alignItems:
                                    'center',
                            }}
                        >
                            <Skeleton
                                variant="circular"
                                width={40}
                                height={40}
                            />

                            <Box>
                                <Skeleton
                                    width={140}
                                />

                                <Skeleton
                                    width={190}
                                />
                            </Box>
                        </Stack>
                    </TableCell>

                    <TableCell>
                        <Skeleton
                            variant="rounded"
                            width={110}
                            height={26}
                        />
                    </TableCell>

                    <TableCell>
                        <Skeleton
                            width={120}
                        />
                    </TableCell>

                    <TableCell>
                        <Skeleton
                            variant="rounded"
                            width={70}
                            height={26}
                        />
                    </TableCell>

                    <TableCell>
                        <Skeleton
                            width={90}
                        />
                    </TableCell>

                    <TableCell align="right">
                        <Skeleton
                            variant="circular"
                            width={32}
                            height={32}
                            sx={{
                                ml: 'auto',
                            }}
                        />
                    </TableCell>
                </TableRow>
            ))}
        </TableBody>
    );
}

export function UsersTable({
                               users,
                               isLoading,
                               onEditUser,
                               onChangeStatus,
                               onResetPassword,
                               onDeleteUser,
                           }: UsersTableProps) {
    const navigate =
        useNavigate();

    /*
     * Sisteme giriş yapmış kullanıcı.
     */
    const currentUser =
        useAuthStore(
            (state) => state.user,
        );

    /*
     * İşlem menüsünün açık olduğu kullanıcıyı tutar.
     */
    const [
        menuState,
        setMenuState,
    ] = useState<UserMenuState | null>(
        null,
    );

    /*
     * Menüde seçili kullanıcı, oturum açmış kullanıcı mı?
     */
    const isSelectedUserCurrentUser =
        menuState !== null &&
        currentUser !== null &&
        menuState.user.id ===
        currentUser.id;

    /*
     * Satıra ait işlem menüsünü açar.
     */
    const handleMenuOpen = (
        event: MouseEvent<HTMLElement>,
        user: SystemUser,
    ): void => {
        event.stopPropagation();

        setMenuState({
            anchorElement:
            event.currentTarget,

            user,
        });
    };

    /*
     * Açık işlem menüsünü kapatır.
     */
    const handleMenuClose =
        (): void => {
            setMenuState(null);
        };

    /*
     * Kullanıcı detay sayfasına yönlendirir.
     */
    const handleViewUser =
        (): void => {
            if (!menuState) {
                return;
            }

            const selectedUser =
                menuState.user;

            handleMenuClose();

            navigate(
                `/users/${selectedUser.id}`,
            );
        };

    /*
     * Kullanıcı düzenleme dialogunu açar.
     */
    const handleEditUser =
        (): void => {
            if (!menuState) {
                return;
            }

            const selectedUser =
                menuState.user;

            handleMenuClose();

            onEditUser(
                selectedUser,
            );
        };

    /*
     * Kullanıcı aktiflik durumu dialogunu açar.
     *
     * Oturum açmış kullanıcı kendi hesabını
     * pasif hâle getiremez.
     */
    const handleChangeStatus =
        (): void => {
            if (
                !menuState ||
                isSelectedUserCurrentUser
            ) {
                return;
            }

            const selectedUser =
                menuState.user;

            handleMenuClose();

            onChangeStatus(
                selectedUser,
            );
        };

    /*
     * Kullanıcı parola sıfırlama dialogunu açar.
     *
     * Admin ister başka bir kullanıcının ister kendi
     * hesabının parolasını sıfırlayabilir.
     *
     * Backend farklı bir güvenlik kuralı uyguluyorsa
     * bu davranış daha sonra sınırlandırılabilir.
     */
    const handleResetPassword =
        (): void => {
            if (!menuState) {
                return;
            }

            const selectedUser =
                menuState.user;

            handleMenuClose();

            onResetPassword(
                selectedUser,
            );
        };

    /*
     * Kullanıcı silme dialogunu açar.
     *
     * Oturum açmış kullanıcı kendi hesabını silemez.
     */
    const handleDeleteUser =
        (): void => {
            if (
                !menuState ||
                isSelectedUserCurrentUser
            ) {
                return;
            }

            const selectedUser =
                menuState.user;

            handleMenuClose();

            onDeleteUser(
                selectedUser,
            );
        };

    return (
        <Paper
            elevation={0}
            sx={{
                overflow: 'hidden',

                border: '1px solid',
                borderColor: 'divider',
            }}
        >
            <TableContainer>
                <Table
                    sx={{
                        minWidth: 900,
                    }}
                    aria-label="Kullanıcılar tablosu"
                >
                    <TableHead>
                        <TableRow>
                            <TableCell>
                                Kullanıcı
                            </TableCell>

                            <TableCell>
                                Rol
                            </TableCell>

                            <TableCell>
                                Departman
                            </TableCell>

                            <TableCell>
                                Durum
                            </TableCell>

                            <TableCell>
                                Kayıt tarihi
                            </TableCell>

                            <TableCell align="right">
                                İşlem
                            </TableCell>
                        </TableRow>
                    </TableHead>

                    {isLoading ? (
                        <UsersTableSkeleton />
                    ) : (
                        <TableBody>
                            {users.length === 0 ? (
                                <TableRow>
                                    <TableCell
                                        colSpan={6}
                                        sx={{
                                            py: 8,
                                        }}
                                    >
                                        <Stack
                                            spacing={2}
                                            sx={{
                                                alignItems:
                                                    'center',

                                                textAlign:
                                                    'center',
                                            }}
                                        >
                                            <GroupOffOutlinedIcon
                                                sx={{
                                                    fontSize: 56,

                                                    color:
                                                        'text.secondary',
                                                }}
                                            />

                                            <Box>
                                                <Typography variant="h6">
                                                    Kullanıcı bulunamadı
                                                </Typography>

                                                <Typography
                                                    color="text.secondary"
                                                    sx={{
                                                        mt: 0.5,
                                                    }}
                                                >
                                                    Seçilen filtrelere uygun
                                                    kullanıcı bulunmuyor.
                                                </Typography>
                                            </Box>
                                        </Stack>
                                    </TableCell>
                                </TableRow>
                            ) : (
                                users.map(
                                    (user) => {
                                        /*
                                         * Avatar üzerinde gösterilecek
                                         * ad ve soyad baş harfleri.
                                         */
                                        const initials =
                                            `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`
                                                .toUpperCase();

                                        /*
                                         * Satırdaki kullanıcı oturum açmış
                                         * kullanıcıyla aynı mı?
                                         */
                                        const isCurrentUser =
                                            currentUser !== null &&
                                            user.id ===
                                            currentUser.id;

                                        return (
                                            <TableRow
                                                key={
                                                    user.id
                                                }
                                                hover
                                                onClick={() => {
                                                    navigate(
                                                        `/users/${user.id}`,
                                                    );
                                                }}
                                                sx={{
                                                    cursor:
                                                        'pointer',
                                                }}
                                            >
                                                <TableCell>
                                                    <Stack
                                                        direction="row"
                                                        spacing={1.5}
                                                        sx={{
                                                            alignItems:
                                                                'center',
                                                        }}
                                                    >
                                                        <Avatar
                                                            sx={{
                                                                width: 40,
                                                                height: 40,

                                                                bgcolor:
                                                                    user.isActive
                                                                        ? 'primary.main'
                                                                        : 'grey.500',

                                                                fontSize: 14,
                                                                fontWeight: 700,
                                                            }}
                                                        >
                                                            {initials}
                                                        </Avatar>

                                                        <Box
                                                            sx={{
                                                                minWidth: 0,
                                                            }}
                                                        >
                                                            <Stack
                                                                direction="row"
                                                                spacing={1}
                                                                useFlexGap
                                                                sx={{
                                                                    alignItems:
                                                                        'center',

                                                                    flexWrap:
                                                                        'wrap',
                                                                }}
                                                            >
                                                                <Typography
                                                                    variant="body2"
                                                                    sx={{
                                                                        fontWeight: 600,
                                                                    }}
                                                                >
                                                                    {user.fullName}
                                                                </Typography>

                                                                {isCurrentUser && (
                                                                    <Chip
                                                                        label="Siz"
                                                                        size="small"
                                                                        color="primary"
                                                                        variant="outlined"
                                                                    />
                                                                )}
                                                            </Stack>

                                                            <Typography
                                                                variant="caption"
                                                                color="text.secondary"
                                                                sx={{
                                                                    display:
                                                                        'block',

                                                                    maxWidth: 280,

                                                                    overflow:
                                                                        'hidden',

                                                                    textOverflow:
                                                                        'ellipsis',

                                                                    whiteSpace:
                                                                        'nowrap',
                                                                }}
                                                            >
                                                                {user.email}
                                                            </Typography>

                                                            <Typography
                                                                variant="caption"
                                                                color="text.secondary"
                                                            >
                                                                Kullanıcı #
                                                                {user.id}
                                                            </Typography>
                                                        </Box>
                                                    </Stack>
                                                </TableCell>

                                                <TableCell>
                                                    <Chip
                                                        label={getUserRoleLabel(
                                                            user.role,
                                                        )}
                                                        color={getUserRoleColor(
                                                            user.role,
                                                        )}
                                                        size="small"
                                                        variant="outlined"
                                                    />
                                                </TableCell>

                                                <TableCell>
                                                    <Typography variant="body2">
                                                        {user.department ??
                                                            '-'}
                                                    </Typography>
                                                </TableCell>

                                                <TableCell>
                                                    <Chip
                                                        label={
                                                            user.isActive
                                                                ? 'Aktif'
                                                                : 'Pasif'
                                                        }
                                                        color={
                                                            user.isActive
                                                                ? 'success'
                                                                : 'default'
                                                        }
                                                        size="small"
                                                    />
                                                </TableCell>

                                                <TableCell>
                                                    <Typography variant="body2">
                                                        {formatUserDate(
                                                            user.createdAt,
                                                        )}
                                                    </Typography>
                                                </TableCell>

                                                <TableCell align="right">
                                                    <Tooltip title="İşlemler">
                                                        <IconButton
                                                            size="small"
                                                            onClick={(
                                                                event,
                                                            ) => {
                                                                event.stopPropagation();

                                                                handleMenuOpen(
                                                                    event,
                                                                    user,
                                                                );
                                                            }}
                                                        >
                                                            <MoreVertRoundedIcon />
                                                        </IconButton>
                                                    </Tooltip>
                                                </TableCell>
                                            </TableRow>
                                        );
                                    },
                                )
                            )}
                        </TableBody>
                    )}
                </Table>
            </TableContainer>

            {/*
             * Seçili kullanıcıya ait işlem menüsü.
             */}
            <Menu
                anchorEl={
                    menuState?.anchorElement
                }
                open={Boolean(
                    menuState,
                )}
                onClose={
                    handleMenuClose
                }
            >
                <MenuItem
                    onClick={
                        handleViewUser
                    }
                >
                    <PersonSearchRoundedIcon
                        fontSize="small"
                        sx={{
                            mr: 1.5,
                        }}
                    />

                    Kullanıcı detayını görüntüle
                </MenuItem>

                <MenuItem
                    onClick={
                        handleEditUser
                    }
                >
                    <EditOutlinedIcon
                        fontSize="small"
                        sx={{
                            mr: 1.5,
                        }}
                    />

                    Kullanıcıyı düzenle
                </MenuItem>

                <MenuItem
                    onClick={
                        handleResetPassword
                    }
                >
                    <LockResetRoundedIcon
                        fontSize="small"
                        sx={{
                            mr: 1.5,
                        }}
                    />

                    Parolayı sıfırla
                </MenuItem>

                <Tooltip
                    title={
                        isSelectedUserCurrentUser
                            ? 'Kendi hesabınızı pasif hâle getiremezsiniz.'
                            : ''
                    }
                    placement="left"
                >
                    <span>
                        <MenuItem
                            disabled={
                                isSelectedUserCurrentUser
                            }
                            onClick={
                                handleChangeStatus
                            }
                        >
                            {menuState?.user
                                .isActive ? (
                                <ToggleOffRoundedIcon
                                    fontSize="small"
                                    sx={{
                                        mr: 1.5,
                                    }}
                                />
                            ) : (
                                <ToggleOnRoundedIcon
                                    fontSize="small"
                                    sx={{
                                        mr: 1.5,
                                    }}
                                />
                            )}

                            {menuState?.user
                                .isActive
                                ? 'Kullanıcıyı pasif yap'
                                : 'Kullanıcıyı aktif yap'}
                        </MenuItem>
                    </span>
                </Tooltip>

                <Tooltip
                    title={
                        isSelectedUserCurrentUser
                            ? 'Kendi kullanıcı hesabınızı silemezsiniz.'
                            : ''
                    }
                    placement="left"
                >
                    <span>
                        <MenuItem
                            disabled={
                                isSelectedUserCurrentUser
                            }
                            onClick={
                                handleDeleteUser
                            }
                            sx={{
                                color:
                                    isSelectedUserCurrentUser
                                        ? undefined
                                        : 'error.main',
                            }}
                        >
                            <DeleteOutlineRoundedIcon
                                fontSize="small"
                                sx={{
                                    mr: 1.5,
                                }}
                            />

                            Kullanıcıyı sil
                        </MenuItem>
                    </span>
                </Tooltip>
            </Menu>
        </Paper>
    );
}