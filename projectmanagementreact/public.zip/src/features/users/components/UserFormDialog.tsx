import { useEffect } from 'react';

import {
    Alert,
    Button,
    CircularProgress,
    Dialog,
    DialogActions,
    DialogContent,
    DialogTitle,
    FormControl,
    FormControlLabel,
    FormHelperText,
    InputLabel,
    MenuItem,
    Select,
    Stack,
    Switch,
    TextField,
} from '@mui/material';

import {
    Controller,
    useForm,
} from 'react-hook-form';

import { zodResolver } from '@hookform/resolvers/zod';

import { normalizeApiError } from '../../../services/apiClient';

import { useAuthStore } from '../../auth/store/authStore';

import { useCreateUser } from '../hooks/useCreateUser';
import { useUpdateUser } from '../hooks/useUpdateUser';

import {
    userFormSchema,
    type UserFormValues,
} from '../schemas/userSchema';

import type {
    CreateUserRequest,
    SystemUser,
    UpdateUserRequest,
} from '../types/user.types';

interface UserFormDialogProps {
    open: boolean;

    /*
     * user verilirse düzenleme,
     * verilmezse oluşturma modunda çalışır.
     */
    user?: SystemUser | null;

    onClose: () => void;
}

export function UserFormDialog({
                                   open,
                                   user = null,
                                   onClose,
                               }: UserFormDialogProps) {
    /*
     * Sisteme giriş yapmış kullanıcı.
     *
     * Düzenlenen hesabın mevcut kullanıcıya ait olup
     * olmadığını kontrol etmek için kullanılır.
     */
    const currentUser =
        useAuthStore(
            (state) => state.user,
        );

    const createMutation =
        useCreateUser();

    const updateMutation =
        useUpdateUser();

    const isEditMode =
        user !== null;

    /*
     * Düzenlenen kullanıcı, oturum açmış kullanıcı mı?
     */
    const isCurrentUser =
        user !== null &&
        currentUser !== null &&
        user.id === currentUser.id;

    const {
        control,
        handleSubmit,
        reset,
        setError,

        formState: {
            errors,
            isSubmitting,
        },
    } = useForm<UserFormValues>({
        resolver: zodResolver(
            userFormSchema,
        ),

        defaultValues: {
            firstName: '',
            lastName: '',
            email: '',
            password: '',
            role: 'TeamMember',
            department: '',
            isActive: true,
        },
    });

    /*
     * Dialog açıldığında oluşturma veya düzenleme
     * verileri forma aktarılır.
     */
    useEffect(() => {
        if (!open) {
            return;
        }

        reset({
            firstName:
                user?.firstName ?? '',

            lastName:
                user?.lastName ?? '',

            email:
                user?.email ?? '',

            password: '',

            role:
                user?.role ??
                'TeamMember',

            department:
                user?.department ?? '',

            isActive:
                user?.isActive ?? true,
        });
    }, [
        open,
        user,
        reset,
    ]);

    const mutationError =
        createMutation.error ??
        updateMutation.error;

    const normalizedError =
        mutationError
            ? normalizeApiError(
                mutationError,
            )
            : null;

    const isPending =
        createMutation.isPending ||
        updateMutation.isPending ||
        isSubmitting;

    /*
     * İşlem devam ederken dialogun kapanmasını engeller.
     */
    const handleClose = (): void => {
        if (isPending) {
            return;
        }

        createMutation.reset();
        updateMutation.reset();

        onClose();
    };

    const handleSave = async (
        values: UserFormValues,
    ): Promise<void> => {
        /*
         * Yeni kullanıcı oluştururken parola zorunludur.
         */
        if (
            !isEditMode &&
            values.password.length === 0
        ) {
            setError('password', {
                type: 'manual',
                message:
                    'Yeni kullanıcı için parola zorunludur.',
            });

            return;
        }

        /*
         * Mevcut kullanıcı kendi hesabını düzenliyorsa
         * rolü değiştirilemez.
         *
         * Select devre dışı olsa da bu kontrol request
         * gönderilmeden önce ek güvenlik sağlar.
         */
        if (
            isCurrentUser &&
            user &&
            values.role !== user.role
        ) {
            setError('role', {
                type: 'manual',
                message:
                    'Kendi kullanıcı rolünüzü değiştiremezsiniz.',
            });

            return;
        }

        try {
            if (user) {
                const request:
                    UpdateUserRequest = {
                    firstName:
                        values.firstName.trim(),

                    lastName:
                        values.lastName.trim(),

                    email:
                        values.email.trim(),

                    /*
                     * Kendi hesabında mevcut rol korunur.
                     */
                    role:
                        isCurrentUser
                            ? user.role
                            : values.role,

                    department:
                        values.department.trim(),
                };

                await updateMutation.mutateAsync({
                    userId: user.id,
                    request,
                });
            } else {
                const request:
                    CreateUserRequest = {
                    firstName:
                        values.firstName.trim(),

                    lastName:
                        values.lastName.trim(),

                    email:
                        values.email.trim(),

                    password:
                    values.password,

                    role:
                    values.role,

                    department:
                        values.department.trim(),

                    isActive:
                    values.isActive,
                };

                await createMutation.mutateAsync(
                    request,
                );
            }

            handleClose();
        } catch {
            /*
             * API hatası dialog içindeki Alert
             * bileşeninde gösterilir.
             */
        }
    };

    return (
        <Dialog
            open={open}
            onClose={handleClose}
            fullWidth
            maxWidth="sm"
        >
            <DialogTitle>
                {isEditMode
                    ? 'Kullanıcıyı düzenle'
                    : 'Yeni kullanıcı oluştur'}
            </DialogTitle>

            <DialogContent dividers>
                <Stack spacing={2.5}>
                    {normalizedError && (
                        <Alert severity="error">
                            {
                                normalizedError.message
                            }
                        </Alert>
                    )}

                    {isCurrentUser && (
                        <Alert severity="info">
                            Kendi hesabınızı
                            düzenliyorsunuz. Güvenlik
                            nedeniyle kullanıcı rolünüz
                            değiştirilemez.
                        </Alert>
                    )}

                    <Stack
                        direction={{
                            xs: 'column',
                            sm: 'row',
                        }}
                        spacing={2}
                    >
                        <Controller
                            name="firstName"
                            control={control}
                            render={({
                                         field,
                                     }) => (
                                <TextField
                                    {...field}
                                    fullWidth
                                    label="Ad"
                                    autoFocus
                                    disabled={
                                        isPending
                                    }
                                    error={Boolean(
                                        errors.firstName,
                                    )}
                                    helperText={
                                        errors.firstName
                                            ?.message
                                    }
                                />
                            )}
                        />

                        <Controller
                            name="lastName"
                            control={control}
                            render={({
                                         field,
                                     }) => (
                                <TextField
                                    {...field}
                                    fullWidth
                                    label="Soyad"
                                    disabled={
                                        isPending
                                    }
                                    error={Boolean(
                                        errors.lastName,
                                    )}
                                    helperText={
                                        errors.lastName
                                            ?.message
                                    }
                                />
                            )}
                        />
                    </Stack>

                    <Controller
                        name="email"
                        control={control}
                        render={({
                                     field,
                                 }) => (
                            <TextField
                                {...field}
                                fullWidth
                                label="E-posta"
                                type="email"
                                disabled={
                                    isPending
                                }
                                error={Boolean(
                                    errors.email,
                                )}
                                helperText={
                                    errors.email
                                        ?.message
                                }
                            />
                        )}
                    />

                    {!isEditMode && (
                        <Controller
                            name="password"
                            control={control}
                            render={({
                                         field,
                                     }) => (
                                <TextField
                                    {...field}
                                    fullWidth
                                    label="Parola"
                                    type="password"
                                    disabled={
                                        isPending
                                    }
                                    error={Boolean(
                                        errors.password,
                                    )}
                                    helperText={
                                        errors.password
                                            ?.message ??
                                        'En az 8 karakter giriniz.'
                                    }
                                />
                            )}
                        />
                    )}

                    <Controller
                        name="role"
                        control={control}
                        render={({
                                     field,
                                 }) => (
                            <FormControl
                                fullWidth
                                error={Boolean(
                                    errors.role,
                                )}
                                disabled={
                                    isPending ||
                                    isCurrentUser
                                }
                            >
                                <InputLabel id="user-role-label">
                                    Rol
                                </InputLabel>

                                <Select
                                    {...field}
                                    labelId="user-role-label"
                                    label="Rol"
                                >
                                    <MenuItem value="Admin">
                                        Admin
                                    </MenuItem>

                                    <MenuItem value="ProjectManager">
                                        Proje yöneticisi
                                    </MenuItem>

                                    <MenuItem value="TeamMember">
                                        Ekip üyesi
                                    </MenuItem>
                                </Select>

                                <FormHelperText>
                                    {errors.role
                                            ?.message ??
                                        (isCurrentUser
                                            ? 'Kendi kullanıcı rolünüz değiştirilemez.'
                                            : 'Kullanıcının sistem rolünü seçiniz.')}
                                </FormHelperText>
                            </FormControl>
                        )}
                    />

                    <Controller
                        name="department"
                        control={control}
                        render={({
                                     field,
                                 }) => (
                            <TextField
                                {...field}
                                fullWidth
                                label="Departman"
                                disabled={
                                    isPending
                                }
                                error={Boolean(
                                    errors.department,
                                )}
                                helperText={
                                    errors.department
                                        ?.message ??
                                    'Departman bilgisi isteğe bağlıdır.'
                                }
                            />
                        )}
                    />

                    {!isEditMode && (
                        <Controller
                            name="isActive"
                            control={control}
                            render={({
                                         field,
                                     }) => (
                                <FormControlLabel
                                    control={
                                        <Switch
                                            checked={
                                                field.value
                                            }
                                            onChange={(
                                                _event,
                                                checked,
                                            ) => {
                                                field.onChange(
                                                    checked,
                                                );
                                            }}
                                            disabled={
                                                isPending
                                            }
                                        />
                                    }
                                    label={
                                        field.value
                                            ? 'Kullanıcı aktif oluşturulacak'
                                            : 'Kullanıcı pasif oluşturulacak'
                                    }
                                />
                            )}
                        />
                    )}
                </Stack>
            </DialogContent>

            <DialogActions
                sx={{
                    px: 3,
                    py: 2,
                }}
            >
                <Button
                    onClick={handleClose}
                    disabled={isPending}
                >
                    İptal
                </Button>

                <Button
                    variant="contained"
                    disabled={isPending}
                    onClick={handleSubmit(
                        handleSave,
                    )}
                    startIcon={
                        isPending ? (
                            <CircularProgress
                                size={18}
                                color="inherit"
                            />
                        ) : undefined
                    }
                >
                    {isEditMode
                        ? 'Değişiklikleri kaydet'
                        : 'Kullanıcı oluştur'}
                </Button>
            </DialogActions>
        </Dialog>
    );
}