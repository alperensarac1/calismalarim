import AddRoundedIcon from '@mui/icons-material/AddRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';

import {
    Alert,
    Box,
    Button,
    CircularProgress,
    Pagination,
    Paper,
    Stack,
    Typography,
} from '@mui/material';

import {
    useDeferredValue,
    useMemo,
    useState,
} from 'react';

import { useAuthStore } from '../features/auth/store/authStore';

import { ProjectFilters } from '../features/projects/components/ProjectFilters';
import { ProjectFormDialog } from '../features/projects/components/ProjectFormDialog';
import { ProjectsTable } from '../features/projects/components/ProjectsTable';

import { useProjects } from '../features/projects/hooks/useProjects';

import type {
    Project,
    ProjectFiltersState,
    ProjectStatus,
} from '../features/projects/types/project.types';

import {
    canCreateProject,
} from '../features/projects/utils/projectPermissions';

import { useTasks } from '../features/tasks/hooks/useTasks';

import type {
    ProjectTask,
} from '../features/tasks/types/task.types';

const DEFAULT_PAGE_SIZE = 20;

/*
 * Proje listesindeki "Benim görevlerim" bilgisi için
 * tek seferde alınacak en yüksek görev sayısı.
 *
 * Backend PageSize için daha düşük bir üst sınır uyguluyorsa
 * bu değeri backend doğrulamasına göre güncellemeliyiz.
 */
const MY_TASKS_PAGE_SIZE = 100;

export function ProjectsPage() {
    /*
     * Sisteme giriş yapmış kullanıcı.
     *
     * Kullanıcının kendi görevlerini sorgulamak için
     * user.id değerini kullanıyoruz.
     */
    const user =
        useAuthStore(
            (state) => state.user,
        );

    const [
        page,
        setPage,
    ] = useState(1);

    /*
     * Proje filtrelerinin UI state'i.
     */
    const [
        filters,
        setFilters,
    ] = useState<ProjectFiltersState>({
        search: '',
        status: '',
        archiveFilter: 'active',
    });

    /*
     * useEffect içinde setState kullanmadan arama değerini
     * düşük öncelikli olarak işlemek için useDeferredValue
     * kullanıyoruz.
     */
    const deferredSearch =
        useDeferredValue(
            filters.search.trim(),
        );

    /*
     * Yeni proje oluşturma veya mevcut projeyi
     * düzenleme dialog durumu.
     */
    const [
        projectDialogState,
        setProjectDialogState,
    ] = useState<
        'create' | Project | null
    >(null);

    /*
     * UI'daki arşiv filtresini backend'in beklediği
     * boolean modele dönüştürür.
     *
     * all      -> undefined
     * active   -> false
     * archived -> true
     */
    const isArchived =
        filters.archiveFilter === 'all'
            ? undefined
            : filters.archiveFilter ===
            'archived';

    /*
     * Kullanıcının yetkili olduğu proje listesini getirir.
     */
    const {
        data,
        isLoading,
        isFetching,
        isError,
        error,
        refetch,
    } = useProjects({
        page,
        pageSize:
        DEFAULT_PAGE_SIZE,

        search:
            deferredSearch ||
            undefined,

        status:
            filters.status ||
            undefined,

        isArchived,
    });

    /*
     * Giriş yapan kullanıcıya atanmış görevleri getirir.
     *
     * Bu görevler biraz aşağıda projectId değerine göre
     * gruplandırılarak ProjectsTable bileşenine aktarılır.
     */
    const {
        data: myTasksData,
        isLoading: isMyTasksLoading,
        isFetching: isMyTasksFetching,
        isError: isMyTasksError,
        error: myTasksError,
        refetch: refetchMyTasks,
    } = useTasks({
        page: 1,

        pageSize:
        MY_TASKS_PAGE_SIZE,

        /*
         * Kullanıcı bilgisi henüz yüklenmediyse undefined
         * gönderilir.
         *
         * Backend yine de erişim kurallarını kendi tarafında
         * uygulamalıdır.
         */
        assignedToUserId:
        user?.id,
    });

    /*
     * Kullanıcının görevlerini proje ID değerine göre
     * gruplandırıyoruz.
     *
     * Örnek:
     *
     * {
     *     1: [task1, task2],
     *     4: [task3]
     * }
     */
    const myTasksByProjectId =
        useMemo(() => {
            const groupedTasks:
                Record<
                    number,
                    ProjectTask[]
                > = {};

            for (
                const task of
            myTasksData?.items ?? []
                ) {
                if (
                    !groupedTasks[
                        task.projectId
                        ]
                ) {
                    groupedTasks[
                        task.projectId
                        ] = [];
                }

                groupedTasks[
                    task.projectId
                    ].push(task);
            }

            return groupedTasks;
        }, [
            myTasksData?.items,
        ]);

    const projectErrorMessage =
        error instanceof Error
            ? error.message
            : 'Projeler alınamadı.';

    const myTasksErrorMessage =
        myTasksError instanceof Error
            ? myTasksError.message
            : 'Size atanmış görevler alınamadı.';

    /*
     * Arama değeri değiştiğinde birinci sayfaya döner.
     */
    const handleSearchChange = (
        value: string,
    ): void => {
        setFilters((current) => ({
            ...current,
            search: value,
        }));

        setPage(1);
    };

    /*
     * Proje durumu filtresi değiştiğinde
     * birinci sayfaya döner.
     */
    const handleStatusChange = (
        value: ProjectStatus | '',
    ): void => {
        setFilters((current) => ({
            ...current,
            status: value,
        }));

        setPage(1);
    };

    /*
     * Arşiv filtresi değiştiğinde
     * birinci sayfaya döner.
     */
    const handleArchiveFilterChange = (
        value:
        ProjectFiltersState['archiveFilter'],
    ): void => {
        setFilters((current) => ({
            ...current,
            archiveFilter: value,
        }));

        setPage(1);
    };

    /*
     * Giriş yapan kullanıcının yeni proje oluşturma
     * yetkisini hesaplar.
     */
    const userCanCreate =
        canCreateProject(
            user?.role,
        );

    /*
     * create değeri seçildiyse düzenlenecek proje yoktur.
     */
    const selectedProject =
        projectDialogState === 'create'
            ? null
            : projectDialogState;

    /*
     * Yenile butonu hem proje listesini hem de
     * kullanıcının görevlerini günceller.
     */
    const handleRefresh =
        async (): Promise<void> => {
            await Promise.all([
                refetch(),
                refetchMyTasks(),
            ]);
        };

    const isRefreshing =
        isFetching ||
        isMyTasksFetching;

    return (
        <>
            <Stack spacing={3}>
                {/* Sayfa başlığı */}
                <Stack
                    direction={{
                        xs: 'column',
                        sm: 'row',
                    }}
                    spacing={2}
                    sx={{
                        alignItems: {
                            xs: 'stretch',
                            sm: 'center',
                        },

                        justifyContent:
                            'space-between',
                    }}
                >
                    <Box>
                        <Typography
                            component="h1"
                            variant="h4"
                        >
                            Projeler
                        </Typography>

                        <Typography
                            color="text.secondary"
                            sx={{
                                mt: 1,
                            }}
                        >
                            Yetkiniz bulunan projeleri ve
                            bu projelerde size atanmış
                            görevleri görüntüleyin.
                        </Typography>
                    </Box>

                    <Stack
                        direction="row"
                        spacing={1}
                        useFlexGap
                        sx={{
                            flexWrap: 'wrap',
                        }}
                    >
                        <Button
                            variant="outlined"
                            startIcon={
                                isRefreshing ? (
                                    <CircularProgress
                                        size={18}
                                        color="inherit"
                                    />
                                ) : (
                                    <RefreshRoundedIcon />
                                )
                            }
                            disabled={
                                isRefreshing
                            }
                            onClick={() => {
                                void handleRefresh();
                            }}
                        >
                            Yenile
                        </Button>

                        {userCanCreate && (
                            <Button
                                variant="contained"
                                startIcon={
                                    <AddRoundedIcon />
                                }
                                onClick={() => {
                                    setProjectDialogState(
                                        'create',
                                    );
                                }}
                            >
                                Yeni proje
                            </Button>
                        )}
                    </Stack>
                </Stack>

                {/* Proje filtreleri */}
                <Paper
                    elevation={0}
                    sx={{
                        p: {
                            xs: 2,
                            md: 3,
                        },

                        border: '1px solid',
                        borderColor: 'divider',
                    }}
                >
                    <ProjectFilters
                        filters={filters}
                        onSearchChange={
                            handleSearchChange
                        }
                        onStatusChange={
                            handleStatusChange
                        }
                        onArchiveFilterChange={
                            handleArchiveFilterChange
                        }
                    />
                </Paper>

                {/* Proje listesi API hatası */}
                {isError && (
                    <Alert
                        severity="error"
                        action={
                            <Button
                                color="inherit"
                                size="small"
                                onClick={() => {
                                    void refetch();
                                }}
                            >
                                Tekrar dene
                            </Button>
                        }
                    >
                        {projectErrorMessage}
                    </Alert>
                )}

                {/*
                 * Kişisel görev listesi alınamazsa projeleri yine
                 * gösteriyoruz; yalnızca görev bilgisi için uyarı veriyoruz.
                 */}
                {isMyTasksError && (
                    <Alert
                        severity="warning"
                        action={
                            <Button
                                color="inherit"
                                size="small"
                                onClick={() => {
                                    void refetchMyTasks();
                                }}
                            >
                                Tekrar dene
                            </Button>
                        }
                    >
                        {myTasksErrorMessage}
                    </Alert>
                )}

                {/* Proje tablosu */}
                <ProjectsTable
                    projects={
                        data?.items ?? []
                    }
                    isLoading={
                        isLoading
                    }

                    /*
                     * Giriş yapan kullanıcının görevleri
                     * proje ID değerine göre tabloya aktarılır.
                     */
                    myTasksByProjectId={
                        myTasksByProjectId
                    }
                    isMyTasksLoading={
                        isMyTasksLoading
                    }
                    onEditProject={(
                        project,
                    ) => {
                        setProjectDialogState(
                            project,
                        );
                    }}
                />

                {/* Sayfalama */}
                {!isLoading &&
                    (data?.totalPages ??
                        0) > 1 && (
                        <Stack
                            spacing={1}
                            sx={{
                                alignItems:
                                    'center',
                            }}
                        >
                            <Pagination
                                page={page}
                                count={
                                    data?.totalPages ??
                                    1
                                }
                                color="primary"
                                disabled={
                                    isFetching
                                }
                                onChange={(
                                    _event,
                                    nextPage,
                                ) => {
                                    setPage(
                                        nextPage,
                                    );
                                }}
                            />

                            <Typography
                                variant="caption"
                                color="text.secondary"
                            >
                                Toplam{' '}
                                {data?.totalCount ??
                                    0}{' '}
                                proje
                            </Typography>
                        </Stack>
                    )}
            </Stack>

            {/* Proje oluşturma/düzenleme dialogu */}
            <ProjectFormDialog
                open={
                    projectDialogState !==
                    null
                }
                project={
                    selectedProject
                }
                onClose={() => {
                    setProjectDialogState(
                        null,
                    );
                }}
            />
        </>
    );
}