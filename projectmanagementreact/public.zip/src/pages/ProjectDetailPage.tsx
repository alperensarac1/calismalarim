import AddTaskRoundedIcon from '@mui/icons-material/AddTaskRounded';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import EditRoundedIcon from '@mui/icons-material/EditRounded';
import GroupsRoundedIcon from '@mui/icons-material/GroupsRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import TaskAltRoundedIcon from '@mui/icons-material/TaskAltRounded';

import {
    Alert,
    Box,
    Button,
    Chip,
    CircularProgress,
    Paper,
    Skeleton,
    Stack,
    Typography,
} from '@mui/material';

import {
    useState,
    type ReactNode,
} from 'react';

import {
    useNavigate,
    useParams,
} from 'react-router-dom';

import { useAuthStore } from '../features/auth/store/authStore';

import { AddProjectMemberDialog } from '../features/projects/components/AddProjectMemberDialog';
import { EditProjectMemberRoleDialog } from '../features/projects/components/EditProjectMemberRoleDialog';
import { ProjectFormDialog } from '../features/projects/components/ProjectFormDialog';
import { ProjectMembersTable } from '../features/projects/components/ProjectMembersTable';
import { ProjectStatusChip } from '../features/projects/components/ProjectStatusChip';
import { RemoveProjectMemberDialog } from '../features/projects/components/RemoveProjectMemberDialog';

import { useProjectDetail } from '../features/projects/hooks/useProjectDetail';
import { useProjectMembers } from '../features/projects/hooks/useProjectMembers';

import type {
    ProjectMember,
} from '../features/projects/types/project.types';

import {
    formatProjectDate,
} from '../features/projects/utils/projectFormatters';

import {
    getProjectPermissions,
} from '../features/projects/utils/projectPermissions';

import { TaskFormDialog } from '../features/tasks/components/TaskFormDialog';

interface ProjectDetailRowProps {
    label: string;
    value: ReactNode;
}

/*
 * Proje detay kartlarında tekrar kullanılan bilgi satırı.
 */
function ProjectDetailRow({
                              label,
                              value,
                          }: ProjectDetailRowProps) {
    const isPrimitiveValue =
        typeof value === 'string' ||
        typeof value === 'number';

    return (
        <Box
            sx={{
                display: 'grid',

                gridTemplateColumns: {
                    xs: '1fr',
                    sm: '180px minmax(0, 1fr)',
                },

                gap: {
                    xs: 0.5,
                    sm: 2,
                },

                py: 1.5,

                borderBottom: '1px solid',
                borderColor: 'divider',

                '&:last-of-type': {
                    borderBottom: 0,
                },
            }}
        >
            <Typography
                variant="body2"
                color="text.secondary"
            >
                {label}
            </Typography>

            {isPrimitiveValue ? (
                <Typography
                    variant="body2"
                    sx={{
                        fontWeight: 600,
                        wordBreak: 'break-word',
                    }}
                >
                    {value}
                </Typography>
            ) : (
                value
            )}
        </Box>
    );
}

/*
 * Proje bilgileri ilk kez yüklenirken gösterilen iskelet ekran.
 */
function ProjectDetailSkeleton() {
    return (
        <Stack spacing={3}>
            <Skeleton
                width={180}
                height={40}
            />

            <Paper
                elevation={0}
                sx={{
                    p: 3,
                    border: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Stack spacing={2}>
                    <Skeleton
                        width="45%"
                        height={48}
                    />

                    <Skeleton width="70%" />
                    <Skeleton width="100%" />
                    <Skeleton width="90%" />
                    <Skeleton width="80%" />
                </Stack>
            </Paper>
        </Stack>
    );
}

export function ProjectDetailPage() {
    const navigate = useNavigate();

    /*
     * Router tanımı:
     *
     * /projects/:projectId
     */
    const { projectId } = useParams<{
        projectId: string;
    }>();

    const user = useAuthStore(
        (state) => state.user,
    );

    const parsedProjectId =
        Number(projectId);

    const isValidProjectId =
        Number.isInteger(parsedProjectId) &&
        parsedProjectId > 0;

    /*
     * Proje düzenleme dialog durumu.
     */
    const [
        isEditDialogOpen,
        setIsEditDialogOpen,
    ] = useState(false);

    /*
     * Bu proje için yeni görev oluşturma dialog durumu.
     */
    const [
        isCreateTaskDialogOpen,
        setIsCreateTaskDialogOpen,
    ] = useState(false);

    /*
     * Projeye yeni üye ekleme dialog durumu.
     */
    const [
        isAddMemberDialogOpen,
        setIsAddMemberDialogOpen,
    ] = useState(false);

    /*
     * Rolü düzenlenecek proje üyesi.
     *
     * null olduğunda dialog kapalıdır.
     */
    const [
        selectedMemberForRole,
        setSelectedMemberForRole,
    ] = useState<ProjectMember | null>(
        null,
    );

    /*
     * Projeden çıkarılacak üye.
     *
     * null olduğunda dialog kapalıdır.
     */
    const [
        selectedMemberForRemove,
        setSelectedMemberForRemove,
    ] = useState<ProjectMember | null>(
        null,
    );

    /*
     * Proje detayını getirir.
     */
    const {
        data: project,
        isLoading: isProjectLoading,
        isFetching: isProjectFetching,
        isError: isProjectError,
        error: projectError,
        refetch: refetchProject,
    } = useProjectDetail(
        parsedProjectId,
    );

    /*
     * Proje üyelerini getirir.
     */
    const {
        data: members = [],
        isLoading: isMembersLoading,
        isFetching: isMembersFetching,
        isError: isMembersError,
        error: membersError,
        refetch: refetchMembers,
    } = useProjectMembers(
        parsedProjectId,
    );

    /*
     * URL'deki proje ID geçerli değilse hata gösterilir.
     */
    if (!isValidProjectId) {
        return (
            <Alert severity="error">
                Geçersiz proje kimliği.
            </Alert>
        );
    }

    /*
     * Proje ilk kez yüklenirken skeleton gösterilir.
     */
    if (isProjectLoading) {
        return <ProjectDetailSkeleton />;
    }

    /*
     * Proje alınamadıysa hata ekranı gösterilir.
     */
    if (
        isProjectError ||
        !project
    ) {
        return (
            <Stack spacing={2}>
                <Alert severity="error">
                    {projectError instanceof Error
                        ? projectError.message
                        : 'Proje bilgileri alınamadı.'}
                </Alert>

                <Button
                    variant="outlined"
                    onClick={() => {
                        void refetchProject();
                    }}
                    sx={{
                        alignSelf: 'flex-start',
                    }}
                >
                    Tekrar dene
                </Button>
            </Stack>
        );
    }

    /*
     * Kullanıcının bu proje üzerindeki frontend izinleri.
     *
     * Asıl güvenlik kontrolü backend tarafından yapılmalıdır.
     */
    const permissions =
        getProjectPermissions(
            user,
            project,
        );

    const isRefreshing =
        isProjectFetching ||
        isMembersFetching;

    /*
     * Şimdilik proje üyesi yönetebilen kullanıcının
     * görev oluşturabildiğini kabul ediyoruz.
     *
     * Daha sonra ProjectPermissions modeline ayrı
     * canCreateTask izni ekleyebiliriz.
     */
    const canCreateTask =
        permissions.canManageMembers;

    /*
     * Proje ve proje üyelerini birlikte yeniler.
     */
    const handleRefresh = (): void => {
        void refetchProject();
        void refetchMembers();
    };

    return (
        <>
            <Stack spacing={3}>
                {/* Üst işlem alanı */}
                <Stack
                    direction={{
                        xs: 'column',
                        sm: 'row',
                    }}
                    spacing={2}
                    sx={{
                        alignItems: {
                            xs: 'stretch',
                            sm: 'center',
                        },

                        justifyContent:
                            'space-between',
                    }}
                >
                    <Button
                        startIcon={
                            <ArrowBackRoundedIcon />
                        }
                        onClick={() => {
                            navigate('/projects');
                        }}
                        sx={{
                            alignSelf: {
                                xs: 'flex-start',
                                sm: 'center',
                            },
                        }}
                    >
                        Projelere dön
                    </Button>

                    <Stack
                        direction="row"
                        spacing={1}
                        useFlexGap
                        sx={{
                            flexWrap: 'wrap',
                        }}
                    >
                        <Button
                            variant="outlined"
                            startIcon={
                                isRefreshing ? (
                                    <CircularProgress
                                        size={18}
                                        color="inherit"
                                    />
                                ) : (
                                    <RefreshRoundedIcon />
                                )
                            }
                            disabled={isRefreshing}
                            onClick={handleRefresh}
                        >
                            Yenile
                        </Button>

                        {canCreateTask && (
                            <Button
                                variant="outlined"
                                startIcon={
                                    <AddTaskRoundedIcon />
                                }
                                onClick={() => {
                                    setIsCreateTaskDialogOpen(
                                        true,
                                    );
                                }}
                            >
                                Görev ekle
                            </Button>
                        )}

                        {permissions.canEdit && (
                            <Button
                                variant="contained"
                                startIcon={
                                    <EditRoundedIcon />
                                }
                                onClick={() => {
                                    setIsEditDialogOpen(
                                        true,
                                    );
                                }}
                            >
                                Düzenle
                            </Button>
                        )}
                    </Stack>
                </Stack>

                {/* Proje başlık kartı */}
                <Paper
                    elevation={0}
                    sx={{
                        p: {
                            xs: 3,
                            md: 4,
                        },

                        border: '1px solid',
                        borderColor: 'divider',
                    }}
                >
                    <Stack spacing={3}>
                        <Stack
                            direction={{
                                xs: 'column',
                                sm: 'row',
                            }}
                            spacing={2}
                            sx={{
                                alignItems: {
                                    xs: 'flex-start',
                                    sm: 'center',
                                },

                                justifyContent:
                                    'space-between',
                            }}
                        >
                            <Box>
                                <Stack
                                    direction="row"
                                    spacing={1}
                                    useFlexGap
                                    sx={{
                                        alignItems: 'center',
                                        flexWrap: 'wrap',
                                    }}
                                >
                                    <Typography
                                        component="h1"
                                        variant="h4"
                                    >
                                        {project.name}
                                    </Typography>

                                    <ProjectStatusChip
                                        status={project.status}
                                    />

                                    {project.isArchived && (
                                        <Chip
                                            label="Arşivlendi"
                                            variant="outlined"
                                            size="small"
                                        />
                                    )}
                                </Stack>

                                <Typography
                                    color="text.secondary"
                                    sx={{
                                        mt: 1,
                                    }}
                                >
                                    Proje #{project.id}
                                </Typography>
                            </Box>

                            <Stack
                                direction="row"
                                spacing={1}
                                useFlexGap
                                sx={{
                                    flexWrap: 'wrap',
                                }}
                            >
                                <Chip
                                    icon={
                                        <GroupsRoundedIcon />
                                    }
                                    label={`${project.memberCount} üye`}
                                    variant="outlined"
                                />

                                <Chip
                                    icon={
                                        <TaskAltRoundedIcon />
                                    }
                                    label={`${project.taskCount} görev`}
                                    variant="outlined"
                                />
                            </Stack>
                        </Stack>

                        <Typography
                            color={
                                project.description
                                    ? 'text.primary'
                                    : 'text.secondary'
                            }
                            sx={{
                                whiteSpace: 'pre-wrap',
                            }}
                        >
                            {project.description ||
                                'Proje açıklaması bulunmuyor.'}
                        </Typography>
                    </Stack>
                </Paper>

                {/* Proje detay kartları */}
                <Box
                    sx={{
                        display: 'grid',

                        gridTemplateColumns: {
                            xs: '1fr',
                            lg: 'repeat(2, minmax(0, 1fr))',
                        },

                        gap: 2,
                    }}
                >
                    {/* Genel bilgiler */}
                    <Paper
                        elevation={0}
                        sx={{
                            p: 3,
                            border: '1px solid',
                            borderColor: 'divider',
                        }}
                    >
                        <Typography
                            variant="h6"
                            sx={{
                                mb: 2,
                            }}
                        >
                            Genel bilgiler
                        </Typography>

                        <ProjectDetailRow
                            label="Durum"
                            value={
                                <ProjectStatusChip
                                    status={project.status}
                                />
                            }
                        />

                        <ProjectDetailRow
                            label="Başlangıç tarihi"
                            value={formatProjectDate(
                                project.startDate,
                            )}
                        />

                        <ProjectDetailRow
                            label="Bitiş tarihi"
                            value={formatProjectDate(
                                project.endDate,
                            )}
                        />

                        <ProjectDetailRow
                            label="Oluşturulma tarihi"
                            value={formatProjectDate(
                                project.createdAt,
                            )}
                        />

                        <ProjectDetailRow
                            label="Son güncelleme"
                            value={formatProjectDate(
                                project.updatedAt,
                            )}
                        />
                    </Paper>

                    {/* Proje sahibi */}
                    <Paper
                        elevation={0}
                        sx={{
                            p: 3,
                            border: '1px solid',
                            borderColor: 'divider',
                        }}
                    >
                        <Typography
                            variant="h6"
                            sx={{
                                mb: 2,
                            }}
                        >
                            Proje sahibi
                        </Typography>

                        <ProjectDetailRow
                            label="Ad soyad"
                            value={project.ownerFullName}
                        />

                        <ProjectDetailRow
                            label="E-posta"
                            value={project.ownerEmail}
                        />

                        <ProjectDetailRow
                            label="Kullanıcı ID"
                            value={project.ownerId}
                        />

                        <ProjectDetailRow
                            label="Üye sayısı"
                            value={project.memberCount}
                        />

                        <ProjectDetailRow
                            label="Görev sayısı"
                            value={project.taskCount}
                        />
                    </Paper>
                </Box>

                {/* Proje üyeleri API hata mesajı */}
                {isMembersError && (
                    <Alert
                        severity="error"
                        action={
                            <Button
                                color="inherit"
                                size="small"
                                onClick={() => {
                                    void refetchMembers();
                                }}
                            >
                                Tekrar dene
                            </Button>
                        }
                    >
                        {membersError instanceof Error
                            ? membersError.message
                            : 'Proje üyeleri alınamadı.'}
                    </Alert>
                )}

                {/* Proje üyeleri tablosu */}
                <ProjectMembersTable
                    members={members}
                    isLoading={isMembersLoading}
                    canManageMembers={
                        permissions.canManageMembers
                    }
                    onAddMember={() => {
                        setIsAddMemberDialogOpen(
                            true,
                        );
                    }}
                    onEditMemberRole={(member) => {
                        setSelectedMemberForRole(
                            member,
                        );
                    }}
                    onRemoveMember={(member) => {
                        setSelectedMemberForRemove(
                            member,
                        );
                    }}
                />
            </Stack>

            {/* Proje düzenleme dialogu */}
            <ProjectFormDialog
                open={isEditDialogOpen}
                project={project}
                onClose={() => {
                    setIsEditDialogOpen(false);
                }}
            />

            {/* Bu proje için yeni görev oluşturma dialogu */}
            <TaskFormDialog
                open={isCreateTaskDialogOpen}
                defaultProjectId={project.id}
                defaultProject={project}
                onClose={() => {
                    setIsCreateTaskDialogOpen(
                        false,
                    );
                }}
            />

            {/* Projeye üye ekleme dialogu */}
            <AddProjectMemberDialog
                open={isAddMemberDialogOpen}
                projectId={project.id}
                onClose={() => {
                    setIsAddMemberDialogOpen(
                        false,
                    );
                }}
            />

            {/* Proje üyesinin rolünü değiştirme dialogu */}
            <EditProjectMemberRoleDialog
                open={
                    selectedMemberForRole !== null
                }
                projectId={project.id}
                member={selectedMemberForRole}
                onClose={() => {
                    setSelectedMemberForRole(
                        null,
                    );
                }}
            />

            {/* Proje üyesini projeden çıkarma dialogu */}
            <RemoveProjectMemberDialog
                open={
                    selectedMemberForRemove !== null
                }
                projectId={project.id}
                member={selectedMemberForRemove}
                onClose={() => {
                    setSelectedMemberForRemove(
                        null,
                    );
                }}
            />
        </>
    );
}