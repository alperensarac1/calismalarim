import AddTaskRoundedIcon from '@mui/icons-material/AddTaskRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';

import {
    Alert,
    Box,
    Button,
    CircularProgress,
    Pagination,
    Stack,
    Typography,
} from '@mui/material';

import {
    useState,
    type ChangeEvent,
} from 'react';

import {
    useSearchParams,
} from 'react-router-dom';

import { useAuthStore } from '../features/auth/store/authStore';

import {
    TaskFilters,
    type TaskFilterValues,
} from '../features/tasks/components/TaskFilters';

import { TaskFormDialog } from '../features/tasks/components/TaskFormDialog';
import { TasksTable } from '../features/tasks/components/TasksTable';

import { useTasks } from '../features/tasks/hooks/useTasks';

import type {
    TaskPriority,
    TaskStatus,
} from '../features/tasks/types/task.types';

import {
    getTaskPermissions,
} from '../features/tasks/utils/taskPermissions';

const DEFAULT_PAGE_SIZE = 20;

const TASK_STATUSES: TaskStatus[] = [
    'Todo',
    'InProgress',
    'InReview',
    'Done',
];

const TASK_PRIORITIES: TaskPriority[] = [
    'Low',
    'Medium',
    'High',
    'Critical',
];

/*
 * Query parametresini pozitif tam sayıya dönüştürür.
 */
function parsePositiveInteger(
    value: string | null,
    fallback: number,
): number {
    if (!value) {
        return fallback;
    }

    const parsedValue =
        Number(value);

    if (
        !Number.isInteger(parsedValue) ||
        parsedValue <= 0
    ) {
        return fallback;
    }

    return parsedValue;
}

/*
 * URL'deki görev durumunu doğrular.
 */
function parseTaskStatus(
    value: string | null,
): TaskStatus | '' {
    if (
        value &&
        TASK_STATUSES.includes(
            value as TaskStatus,
        )
    ) {
        return value as TaskStatus;
    }

    return '';
}

/*
 * URL'deki görev önceliğini doğrular.
 */
function parseTaskPriority(
    value: string | null,
): TaskPriority | '' {
    if (
        value &&
        TASK_PRIORITIES.includes(
            value as TaskPriority,
        )
    ) {
        return value as TaskPriority;
    }

    return '';
}

export function TasksPage() {
    /*
     * Sisteme giriş yapmış kullanıcı.
     *
     * TeamMember rolünde kullanıcının yalnızca
     * kendi görevlerini listelemek için kullanılır.
     */
    const user =
        useAuthStore(
            (state) => state.user,
        );

    const [
        searchParams,
        setSearchParams,
    ] = useSearchParams();

    const [
        isCreateDialogOpen,
        setIsCreateDialogOpen,
    ] = useState(false);

    /*
     * Kullanıcının yalnızca kendi görevlerini görmesi
     * gereken rol olup olmadığını belirler.
     */
    const isTeamMember =
        user?.role === 'TeamMember';

    /*
     * Sayfa ve filtre değerlerini doğrudan URL üzerinden okuyoruz.
     */
    const page =
        parsePositiveInteger(
            searchParams.get('page'),
            1,
        );

    /*
     * URL içerisindeki kullanıcı filtresi.
     *
     * TeamMember kullanıcı için bu değer API isteğinde
     * kullanılmayacak; onun yerine oturumdaki kullanıcı ID'si
     * zorunlu olarak gönderilecek.
     */
    const requestedAssignedToUserId =
        parsePositiveInteger(
            searchParams.get(
                'assignedToUserId',
            ),
            0,
        );

    const filterValues:
        TaskFilterValues = {
        search:
            searchParams.get('search') ??
            '',

        projectId:
            parsePositiveInteger(
                searchParams.get(
                    'projectId',
                ),
                0,
            ),

        /*
         * TeamMember için filtre alanında da kendi kullanıcı
         * kimliği tutulur.
         *
         * Böylece URL'ye başka bir kullanıcı ID'si yazılsa bile
         * arayüz ve API isteği oturumdaki kullanıcıya bağlı kalır.
         */
        assignedToUserId:
            isTeamMember
                ? user?.id ?? 0
                : requestedAssignedToUserId,

        status:
            parseTaskStatus(
                searchParams.get(
                    'status',
                ),
            ),

        priority:
            parseTaskPriority(
                searchParams.get(
                    'priority',
                ),
            ),

        overdue:
            searchParams.get(
                'isOverdue',
            ) === 'true'
                ? 'overdue'
                : searchParams.get(
                    'isOverdue',
                ) === 'false'
                    ? 'notOverdue'
                    : 'all',
    };

    /*
     * URL query parametrelerini merkezi olarak günceller.
     */
    const updateSearchParams = (
        values: TaskFilterValues,
        nextPage = 1,
    ): void => {
        const nextParams =
            new URLSearchParams();

        if (nextPage > 1) {
            nextParams.set(
                'page',
                String(nextPage),
            );
        }

        if (values.search.trim()) {
            nextParams.set(
                'search',
                values.search.trim(),
            );
        }

        if (values.projectId > 0) {
            nextParams.set(
                'projectId',
                String(values.projectId),
            );
        }

        /*
         * TeamMember kullanıcının assignedToUserId değerini
         * URL üzerinden değiştirmesine izin vermiyoruz.
         *
         * Admin ve ProjectManager için seçilen kullanıcı
         * filtresi URL'ye eklenebilir.
         */
        if (
            !isTeamMember &&
            values.assignedToUserId > 0
        ) {
            nextParams.set(
                'assignedToUserId',
                String(
                    values.assignedToUserId,
                ),
            );
        }

        if (values.status) {
            nextParams.set(
                'status',
                values.status,
            );
        }

        if (values.priority) {
            nextParams.set(
                'priority',
                values.priority,
            );
        }

        if (
            values.overdue ===
            'overdue'
        ) {
            nextParams.set(
                'isOverdue',
                'true',
            );
        }

        if (
            values.overdue ===
            'notOverdue'
        ) {
            nextParams.set(
                'isOverdue',
                'false',
            );
        }

        setSearchParams(nextParams);
    };

    /*
     * UI filtresi, API query modeline dönüştürülür.
     */
    const isOverdue =
        filterValues.overdue ===
        'overdue'
            ? true
            : filterValues.overdue ===
            'notOverdue'
                ? false
                : undefined;

    /*
     * API'ye gönderilecek kullanıcı filtresi.
     *
     * TeamMember:
     * Oturumdaki kullanıcının ID'si zorunlu gönderilir.
     *
     * Admin / ProjectManager:
     * Kullanıcının seçtiği filtre gönderilir.
     */
    const assignedToUserId =
        isTeamMember
            ? user?.id
            : filterValues
                .assignedToUserId > 0
                ? filterValues
                    .assignedToUserId
                : undefined;

    const {
        data,
        isLoading,
        isFetching,
        isError,
        error,
        refetch,
    } = useTasks({
        page,

        pageSize:
        DEFAULT_PAGE_SIZE,

        search:
            filterValues.search.trim() ||
            undefined,

        projectId:
            filterValues.projectId > 0
                ? filterValues.projectId
                : undefined,

        assignedToUserId,

        status:
            filterValues.status ||
            undefined,

        priority:
            filterValues.priority ||
            undefined,

        isOverdue,
    });

    const permissions =
        getTaskPermissions(user);

    const errorMessage =
        error instanceof Error
            ? error.message
            : 'Görevler alınamadı.';

    const totalPages =
        Math.max(
            data?.totalPages ?? 1,
            1,
        );

    const totalCount =
        data?.totalCount ?? 0;

    const handlePageChange = (
        _event: ChangeEvent<unknown>,
        nextPage: number,
    ): void => {
        updateSearchParams(
            filterValues,
            nextPage,
        );
    };

    const handleFiltersChange = (
        nextFilters: TaskFilterValues,
    ): void => {
        /*
         * TeamMember kullanıcı başka bir kullanıcı seçmeye
         * çalışsa bile kendi ID değeri korunur.
         */
        const securedFilters:
            TaskFilterValues =
            isTeamMember
                ? {
                    ...nextFilters,

                    assignedToUserId:
                        user?.id ?? 0,
                }
                : nextFilters;

        /*
         * Her filtre değişiminde birinci sayfaya dönülür.
         */
        updateSearchParams(
            securedFilters,
            1,
        );
    };

    const handleClearFilters =
        (): void => {
            updateSearchParams({
                search: '',
                projectId: 0,

                /*
                 * TeamMember için kullanıcı filtresi
                 * temizlenmez; kendi ID değeri korunur.
                 */
                assignedToUserId:
                    isTeamMember
                        ? user?.id ?? 0
                        : 0,

                status: '',
                priority: '',
                overdue: 'all',
            });
        };

    return (
        <>
            <Stack spacing={3}>
                {/* Sayfa başlığı */}
                <Stack
                    direction={{
                        xs: 'column',
                        sm: 'row',
                    }}
                    spacing={2}
                    sx={{
                        alignItems: {
                            xs: 'stretch',
                            sm: 'center',
                        },

                        justifyContent:
                            'space-between',
                    }}
                >
                    <Box>
                        <Typography
                            component="h1"
                            variant="h4"
                        >
                            Görevler
                        </Typography>

                        <Typography
                            color="text.secondary"
                            sx={{
                                mt: 1,
                            }}
                        >
                            {isTeamMember
                                ? 'Size atanmış görevleri görüntüleyin ve yönetin.'
                                : 'Yetkiniz bulunan görevleri görüntüleyin ve yönetin.'}
                        </Typography>
                    </Box>

                    <Stack
                        direction="row"
                        spacing={1}
                        useFlexGap
                        sx={{
                            flexWrap: 'wrap',
                        }}
                    >
                        <Button
                            variant="outlined"
                            startIcon={
                                isFetching ? (
                                    <CircularProgress
                                        size={18}
                                        color="inherit"
                                    />
                                ) : (
                                    <RefreshRoundedIcon />
                                )
                            }
                            disabled={
                                isFetching
                            }
                            onClick={() => {
                                void refetch();
                            }}
                        >
                            Yenile
                        </Button>

                        {permissions.canCreate && (
                            <Button
                                variant="contained"
                                startIcon={
                                    <AddTaskRoundedIcon />
                                }
                                onClick={() => {
                                    setIsCreateDialogOpen(
                                        true,
                                    );
                                }}
                            >
                                Yeni görev
                            </Button>
                        )}
                    </Stack>
                </Stack>

                {/*
                 * TeamMember için bilgi mesajı.
                 */}
                {isTeamMember && (
                    <Alert severity="info">
                        Bu ekranda yalnızca size atanmış
                        görevler gösterilmektedir.
                    </Alert>
                )}

                {/* Görev filtreleri */}
                <TaskFilters
                    value={filterValues}
                    onChange={
                        handleFiltersChange
                    }
                    onClear={
                        handleClearFilters
                    }
                />

                {/* API hata mesajı */}
                {isError && (
                    <Alert
                        severity="error"
                        action={
                            <Button
                                color="inherit"
                                size="small"
                                onClick={() => {
                                    void refetch();
                                }}
                            >
                                Tekrar dene
                            </Button>
                        }
                    >
                        {errorMessage}
                    </Alert>
                )}

                {/* Görev tablosu */}
                <TasksTable
                    tasks={
                        data?.items ?? []
                    }
                    isLoading={
                        isLoading
                    }
                />

                {/* Sayfalama */}
                {!isLoading &&
                    totalPages > 1 && (
                        <Stack
                            spacing={1}
                            sx={{
                                alignItems:
                                    'center',
                            }}
                        >
                            <Pagination
                                page={page}
                                count={
                                    totalPages
                                }
                                color="primary"
                                disabled={
                                    isFetching
                                }
                                onChange={
                                    handlePageChange
                                }
                            />

                            <Typography
                                variant="caption"
                                color="text.secondary"
                            >
                                Toplam{' '}
                                {totalCount}{' '}
                                görev
                            </Typography>
                        </Stack>
                    )}
            </Stack>

            {/* Yeni görev oluşturma dialogu */}
            <TaskFormDialog
                open={
                    isCreateDialogOpen
                }
                onClose={() => {
                    setIsCreateDialogOpen(
                        false,
                    );
                }}
            />
        </>
    );
}