import EventAvailableRoundedIcon from '@mui/icons-material/EventAvailableRounded';
import FolderRoundedIcon from '@mui/icons-material/FolderRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import TaskAltRoundedIcon from '@mui/icons-material/TaskAltRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';

import {
    Alert,
    Box,
    Button,
    Card,
    CardContent,
    Chip,
    CircularProgress,
    LinearProgress,
    Paper,
    Skeleton,
    Stack,
    Typography,
} from '@mui/material';

import {
    useMemo,
    type ReactNode,
} from 'react';

import { useAuthStore } from '../features/auth/store/authStore';

import { RecentTasksTable } from '../features/dashboard/components/RecentTasksTable';

import { useDashboardSummary } from '../features/dashboard/hooks/useDashboardSummary';
import { useRecentTasks } from '../features/dashboard/hooks/useRecentTasks';
import type {
    Project,
} from '../features/projects/types/project.types';
import type {
    DashboardRecentTask,
} from '../features/dashboard/types/dashboard.types';

import {
    formatDateTime,
    formatPercentage,
    normalizePercentage,
} from '../features/dashboard/utils/dashboardFormatters';

import { useProjects } from '../features/projects/hooks/useProjects';

import { useTasks } from '../features/tasks/hooks/useTasks';

import type {
    ProjectTask,
} from '../features/tasks/types/task.types';

const DASHBOARD_PAGE_SIZE = 100;

interface SummaryCardProps {
    title: string;
    value: string;
    icon: ReactNode;
    subtitle?: string;
    isLoading?: boolean;
}

function SummaryCard({
                         title,
                         value,
                         icon,
                         subtitle,
                         isLoading = false,
                     }: SummaryCardProps) {
    return (
        <Card
            elevation={0}
            sx={{
                height: '100%',
                border: '1px solid',
                borderColor: 'divider',
            }}
        >
            <CardContent
                sx={{
                    height: '100%',
                }}
            >
                <Stack
                    direction="row"
                    spacing={2}
                    sx={{
                        height: '100%',
                        alignItems: 'center',
                    }}
                >
                    <Box
                        sx={{
                            width: 48,
                            height: 48,
                            flexShrink: 0,

                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',

                            borderRadius: 2,

                            bgcolor: 'primary.main',
                            color: 'primary.contrastText',
                        }}
                    >
                        {icon}
                    </Box>

                    <Box
                        sx={{
                            minWidth: 0,
                        }}
                    >
                        <Typography
                            variant="body2"
                            color="text.secondary"
                        >
                            {title}
                        </Typography>

                        {isLoading ? (
                            <Skeleton
                                width={90}
                                height={38}
                            />
                        ) : (
                            <Typography
                                variant="h5"
                                sx={{
                                    mt: 0.5,
                                }}
                            >
                                {value}
                            </Typography>
                        )}

                        {subtitle &&
                            !isLoading && (
                                <Typography
                                    variant="caption"
                                    color="text.secondary"
                                    sx={{
                                        display: 'block',

                                        maxWidth: 240,

                                        overflow: 'hidden',
                                        textOverflow:
                                            'ellipsis',
                                        whiteSpace: 'nowrap',
                                    }}
                                >
                                    {subtitle}
                                </Typography>
                            )}
                    </Box>
                </Stack>
            </CardContent>
        </Card>
    );
}

interface ProgressCardProps {
    title: string;
    description: string;
    value: number;
    isLoading?: boolean;
}

function ProgressCard({
                          title,
                          description,
                          value,
                          isLoading = false,
                      }: ProgressCardProps) {
    const normalizedValue =
        normalizePercentage(value);

    return (
        <Paper
            elevation={0}
            sx={{
                p: 3,
                border: '1px solid',
                borderColor: 'divider',
            }}
        >
            <Stack spacing={2}>
                <Box>
                    <Typography variant="h6">
                        {title}
                    </Typography>

                    <Typography
                        variant="body2"
                        color="text.secondary"
                        sx={{
                            mt: 0.5,
                        }}
                    >
                        {description}
                    </Typography>
                </Box>

                {isLoading ? (
                    <>
                        <Skeleton
                            width={90}
                            height={40}
                        />

                        <Skeleton
                            variant="rounded"
                            height={8}
                        />
                    </>
                ) : (
                    <>
                        <Typography variant="h4">
                            {formatPercentage(
                                normalizedValue,
                            )}
                        </Typography>

                        <LinearProgress
                            variant="determinate"
                            value={normalizedValue}
                            sx={{
                                height: 8,
                                borderRadius: 999,
                            }}
                        />
                    </>
                )}
            </Stack>
        </Paper>
    );
}

interface DashboardDetailRowProps {
    label: string;
    value: ReactNode;
}

function DashboardDetailRow({
                                label,
                                value,
                            }: DashboardDetailRowProps) {
    return (
        <Box
            sx={{
                display: 'flex',
                gap: 2,

                alignItems: 'center',
                justifyContent: 'space-between',

                py: 1,

                borderBottom: '1px solid',
                borderColor: 'divider',

                '&:last-of-type': {
                    borderBottom: 0,
                },
            }}
        >
            <Typography
                variant="body2"
                color="text.secondary"
            >
                {label}
            </Typography>

            {typeof value === 'string' ||
            typeof value === 'number' ? (
                <Typography
                    sx={{
                        fontWeight: 600,
                        textAlign: 'right',
                    }}
                >
                    {value}
                </Typography>
            ) : (
                value
            )}
        </Box>
    );
}

/*
 * ProjectTask modelini dashboard tablosunun
 * beklediği modele dönüştürür.
 */
function mapTaskToDashboardTask(
    task: ProjectTask,
): DashboardRecentTask {
    return {
        id: task.id,
        title: task.title,

        projectId: task.projectId,
        projectName: task.projectName,

        status: task.status,
        priority: task.priority,

        assignedToUserId:
        task.assignedToUserId,

        assignedToUserFullName:
        task.assignedToUserFullName,

        dueDate: task.dueDate,
        isOverdue: task.isOverdue,

        createdAt: task.createdAt,

        updatedAt:
            task.updatedAt ??
            task.createdAt,
    };
}

/*
 * Bitiş tarihine kalan tam gün sayısını hesaplar.
 *
 * Tarih geçmişse negatif değer döner.
 */
function calculateRemainingDays(
    endDate: string,
): number {
    const targetDate =
        new Date(endDate);

    if (
        Number.isNaN(
            targetDate.getTime(),
        )
    ) {
        return 0;
    }

    const now =
        new Date();

    const todayStart =
        new Date(
            now.getFullYear(),
            now.getMonth(),
            now.getDate(),
        );

    const targetStart =
        new Date(
            targetDate.getFullYear(),
            targetDate.getMonth(),
            targetDate.getDate(),
        );

    const difference =
        targetStart.getTime() -
        todayStart.getTime();

    return Math.ceil(
        difference /
        (1000 * 60 * 60 * 24),
    );
}

function formatRemainingDays(
    remainingDays: number,
): string {
    if (remainingDays < 0) {
        return `${Math.abs(
            remainingDays,
        )} gün gecikti`;
    }

    if (remainingDays === 0) {
        return 'Bugün';
    }

    return `${remainingDays} gün`;
}

export function DashboardPage() {
    const user =
        useAuthStore(
            (state) => state.user,
        );

    const isAdmin =
        user?.role === 'Admin';

    const isTeamMember =
        user?.role === 'TeamMember';

    /*
     * Sistem geneli özet yalnızca Admin ekranında kullanılır.
     */
    const {
        data: summary,
        isLoading: isSummaryLoading,
        isError: isSummaryError,
        error: summaryError,
        isFetching: isSummaryFetching,
        refetch: refetchSummary,
    } = useDashboardSummary();

    /*
     * Admin için sistemdeki son görevler.
     */
    const {
        data: adminRecentTasks = [],
        isLoading:
            isAdminRecentTasksLoading,
        isError:
            isAdminRecentTasksError,
        error:
            adminRecentTasksError,
        isFetching:
            isAdminRecentTasksFetching,
        refetch:
            refetchAdminRecentTasks,
    } = useRecentTasks({
        count: 10,
    });

    /*
     * Erişilebilen projeleri getirir.
     *
     * Admin için tüm projeler, diğer roller için backend'in
     * yetki verdiği projeler dönmelidir.
     */
    const {
        data: projectsData,
        isLoading:
            isProjectsLoading,
        isError:
            isProjectsError,
        error:
            projectsError,
        isFetching:
            isProjectsFetching,
        refetch:
            refetchProjects,
    } = useProjects({
        page: 1,
        pageSize:
        DASHBOARD_PAGE_SIZE,

        isArchived: false,
    });

    /*
     * Admin dışındaki kullanıcıların erişebildiği görevler.
     *
     * TeamMember için yalnızca kendi görevleri istenir.
     */
    const {
        data: personalTasksData,
        isLoading:
            isPersonalTasksLoading,
        isError:
            isPersonalTasksError,
        error:
            personalTasksError,
        isFetching:
            isPersonalTasksFetching,
        refetch:
            refetchPersonalTasks,
    } = useTasks({
        page: 1,

        pageSize:
        DASHBOARD_PAGE_SIZE,

        assignedToUserId:
            isTeamMember
                ? user?.id
                : undefined,
    });

    const projects =
        projectsData?.items ??
        [];

    const personalTasks =
        personalTasksData?.items ??
        [];

    /*
     * Arşivlenmemiş ve henüz tamamlanmamış projeler.
     */
    const ongoingProjects =
        useMemo(
            () =>
                projects.filter(
                    (project) =>
                        !project.isArchived &&
                        project.status !==
                        'Completed',
                ),
            [projects],
        );


    type ProjectWithEndDate =
        Project & {
        endDate: string;
    };

    /*
     * Projenin geçerli bir bitiş tarihi olup olmadığını
     * kontrol eden type guard.
     */
    function hasProjectEndDate(
        project: Project,
    ): project is ProjectWithEndDate {
        if (!project.endDate) {
            return false;
        }

        const parsedDate =
            new Date(project.endDate);

        return !Number.isNaN(
            parsedDate.getTime(),
        );
    }

    /*
     * Bitiş tarihi bulunan devam eden projeler arasından
     * teslim tarihi en yakın olan projeyi bulur.
     */
    const nearestProject =
        useMemo<ProjectWithEndDate | null>(
            () => {
                const projectsWithEndDate =
                    ongoingProjects.filter(
                        hasProjectEndDate,
                    );

                return (
                    [...projectsWithEndDate].sort(
                        (
                            firstProject,
                            secondProject,
                        ) =>
                            new Date(
                                firstProject.endDate,
                            ).getTime() -
                            new Date(
                                secondProject.endDate,
                            ).getTime(),
                    )[0] ?? null
                );
            },
            [ongoingProjects],
        );

    /*
     * nearestProject artık ProjectWithEndDate tipinde olduğu için
     * endDate kesin olarak string değerindedir.
     */
    const nearestProjectRemainingDays =
        nearestProject
            ? calculateRemainingDays(
                nearestProject.endDate,
            )
            : null;

    const remainingTasks =
        useMemo(
            () =>
                personalTasks.filter(
                    (task) =>
                        task.status !==
                        'Done',
                ),
            [personalTasks],
        );

    const overdueTasks =
        useMemo(
            () =>
                personalTasks.filter(
                    (task) =>
                        task.isOverdue &&
                        task.status !==
                        'Done',
                ),
            [personalTasks],
        );

    const doneTasks =
        useMemo(
            () =>
                personalTasks.filter(
                    (task) =>
                        task.status ===
                        'Done',
                ),
            [personalTasks],
        );

    const activeProjects =
        useMemo(
            () =>
                projects.filter(
                    (project) =>
                        project.status ===
                        'Active' &&
                        !project.isArchived,
                ),
            [projects],
        );

    const todoCount =
        personalTasks.filter(
            (task) =>
                task.status === 'Todo',
        ).length;

    const inProgressCount =
        personalTasks.filter(
            (task) =>
                task.status ===
                'InProgress',
        ).length;

    const inReviewCount =
        personalTasks.filter(
            (task) =>
                task.status ===
                'InReview',
        ).length;

    const doneCount =
        doneTasks.length;

    const personalCompletionPercentage =
        personalTasks.length === 0
            ? 0
            : (doneCount /
                personalTasks.length) *
            100;

    /*
     * Admin dışındaki kullanıcıların son görevleri.
     */
    const personalRecentTasks =
        useMemo<
            DashboardRecentTask[]
        >(() => {
            return [
                ...personalTasks,
            ]
                .sort(
                    (
                        firstTask,
                        secondTask,
                    ) => {
                        const firstDate =
                            new Date(
                                firstTask.updatedAt ??
                                firstTask.createdAt,
                            ).getTime();

                        const secondDate =
                            new Date(
                                secondTask.updatedAt ??
                                secondTask.createdAt,
                            ).getTime();

                        return (
                            secondDate -
                            firstDate
                        );
                    },
                )
                .slice(0, 10)
                .map(
                    mapTaskToDashboardTask,
                );
        }, [personalTasks]);

    const recentTasks =
        isAdmin
            ? adminRecentTasks
            : personalRecentTasks;

    const recentTasksLoading =
        isAdmin
            ? isAdminRecentTasksLoading
            : isPersonalTasksLoading;

    const recentTasksFetching =
        isAdmin
            ? isAdminRecentTasksFetching
            : isPersonalTasksFetching;

    const recentTasksIsError =
        isAdmin
            ? isAdminRecentTasksError
            : isPersonalTasksError;

    const recentTasksError =
        isAdmin
            ? adminRecentTasksError
            : personalTasksError;

    const summaryErrorMessage =
        summaryError instanceof Error
            ? summaryError.message
            : 'Dashboard bilgileri alınamadı.';

    const projectsErrorMessage =
        projectsError instanceof Error
            ? projectsError.message
            : 'Projeler alınamadı.';

    const personalTasksErrorMessage =
        personalTasksError instanceof Error
            ? personalTasksError.message
            : 'Görevler alınamadı.';

    const recentTasksErrorMessage =
        recentTasksError instanceof Error
            ? recentTasksError.message
            : 'Son görevler alınamadı.';

    const handleRefresh =
        async (): Promise<void> => {
            if (isAdmin) {
                await Promise.all([
                    refetchSummary(),
                    refetchAdminRecentTasks(),
                    refetchProjects(),
                ]);

                return;
            }

            await Promise.all([
                refetchProjects(),
                refetchPersonalTasks(),
            ]);
        };

    const isRefreshing =
        isAdmin
            ? isSummaryFetching ||
            isAdminRecentTasksFetching ||
            isProjectsFetching
            : isProjectsFetching ||
            isPersonalTasksFetching;

    const handleRefreshTasks =
        (): void => {
            if (isAdmin) {
                void refetchAdminRecentTasks();

                return;
            }

            void refetchPersonalTasks();
        };

    return (
        <Stack spacing={3}>
            {/* Sayfa başlığı */}
            <Stack
                direction={{
                    xs: 'column',
                    sm: 'row',
                }}
                spacing={2}
                sx={{
                    alignItems: {
                        xs: 'stretch',
                        sm: 'center',
                    },

                    justifyContent:
                        'space-between',
                }}
            >
                <Box>
                    <Typography
                        component="h1"
                        variant="h4"
                    >
                        Hoş geldiniz,{' '}
                        {user?.firstName}
                    </Typography>

                    <Typography
                        color="text.secondary"
                        sx={{
                            mt: 1,
                        }}
                    >
                        {isAdmin
                            ? 'Sistemdeki projelerin ve görevlerin genel durumunu takip edebilirsiniz.'
                            : isTeamMember
                                ? 'Üyesi olduğunuz projeleri ve size atanmış görevleri takip edebilirsiniz.'
                                : 'Yönettiğiniz veya üyesi olduğunuz projeleri ve görevleri takip edebilirsiniz.'}
                    </Typography>
                </Box>

                <Button
                    variant="outlined"
                    startIcon={
                        isRefreshing ? (
                            <CircularProgress
                                size={18}
                                color="inherit"
                            />
                        ) : (
                            <RefreshRoundedIcon />
                        )
                    }
                    disabled={
                        isRefreshing
                    }
                    onClick={() => {
                        void handleRefresh();
                    }}
                >
                    Özeti yenile
                </Button>
            </Stack>

            {isAdmin &&
                isSummaryError && (
                    <Alert severity="error">
                        {
                            summaryErrorMessage
                        }
                    </Alert>
                )}

            {isProjectsError && (
                <Alert severity="error">
                    {projectsErrorMessage}
                </Alert>
            )}

            {!isAdmin &&
                isPersonalTasksError && (
                    <Alert severity="error">
                        {
                            personalTasksErrorMessage
                        }
                    </Alert>
                )}

            {/* Ana özet kartları */}
            <Box
                sx={{
                    display: 'grid',

                    gridTemplateColumns: {
                        xs: '1fr',
                        sm:
                            'repeat(2, minmax(0, 1fr))',
                        lg:
                            'repeat(4, minmax(0, 1fr))',
                    },

                    gap: 2,
                }}
            >
                <SummaryCard
                    title={
                        isAdmin
                            ? 'Aktif projeler'
                            : 'Aktif projelerim'
                    }
                    value={String(
                        isAdmin
                            ? summary
                                ?.activeProjectCount ??
                            0
                            : activeProjects.length,
                    )}
                    subtitle={
                        isAdmin
                            ? `Toplam ${
                                summary
                                    ?.totalProjectCount ??
                                0
                            } proje`
                            : `Toplam ${projects.length} erişilebilir proje`
                    }
                    icon={
                        <FolderRoundedIcon />
                    }
                    isLoading={
                        isAdmin
                            ? isSummaryLoading
                            : isProjectsLoading
                    }
                />

                <SummaryCard
                    title={
                        isAdmin
                            ? 'Toplam görev'
                            : 'Kalan görevler'
                    }
                    value={String(
                        isAdmin
                            ? summary
                                ?.totalTaskCount ??
                            0
                            : remainingTasks.length,
                    )}
                    subtitle={
                        isAdmin
                            ? `${
                                summary
                                    ?.doneTaskCount ??
                                0
                            } görev tamamlandı`
                            : `${doneCount} görev tamamlandı`
                    }
                    icon={
                        <TaskAltRoundedIcon />
                    }
                    isLoading={
                        isAdmin
                            ? isSummaryLoading
                            : isPersonalTasksLoading
                    }
                />

                <SummaryCard
                    title="Geciken görevler"
                    value={String(
                        isAdmin
                            ? summary
                                ?.overdueTaskCount ??
                            0
                            : overdueTasks.length,
                    )}
                    subtitle={
                        isAdmin
                            ? `Bana ait: ${
                                summary
                                    ?.myOverdueTaskCount ??
                                0
                            }`
                            : 'Tamamlanmamış geciken görevler'
                    }
                    icon={
                        <WarningAmberRoundedIcon />
                    }
                    isLoading={
                        isAdmin
                            ? isSummaryLoading
                            : isPersonalTasksLoading
                    }
                />

                <SummaryCard
                    title="En yakın proje teslimi"
                    value={
                        nearestProjectRemainingDays ===
                        null
                            ? '-'
                            : formatRemainingDays(
                                nearestProjectRemainingDays,
                            )
                    }
                    subtitle={
                        nearestProject
                            ? nearestProject.name
                            : 'Devam eden proje bulunmuyor'
                    }
                    icon={
                        <EventAvailableRoundedIcon />
                    }
                    isLoading={
                        isProjectsLoading
                    }
                />
            </Box>

            {/* Görev durum dağılımı */}
            <Paper
                elevation={0}
                sx={{
                    p: {
                        xs: 2.5,
                        md: 3,
                    },

                    border: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Stack spacing={2}>
                    <Box>
                        <Typography variant="h6">
                            {isAdmin
                                ? 'Görev durumları'
                                : 'Görevlerimin durumları'}
                        </Typography>

                        <Typography
                            variant="body2"
                            color="text.secondary"
                        >
                            Görevlerin mevcut durumlara
                            göre dağılımı.
                        </Typography>
                    </Box>

                    {(isAdmin
                        ? isSummaryLoading
                        : isPersonalTasksLoading) ? (
                        <Stack
                            direction="row"
                            spacing={1}
                        >
                            {Array.from({
                                length: 4,
                            }).map(
                                (
                                    _,
                                    index,
                                ) => (
                                    <Skeleton
                                        key={
                                            index
                                        }
                                        variant="rounded"
                                        width={
                                            120
                                        }
                                        height={
                                            32
                                        }
                                    />
                                ),
                            )}
                        </Stack>
                    ) : (
                        <Stack
                            direction="row"
                            spacing={1}
                            useFlexGap
                            sx={{
                                flexWrap: 'wrap',
                            }}
                        >
                            <Chip
                                label={`Yapılacak: ${
                                    isAdmin
                                        ? summary
                                            ?.todoTaskCount ??
                                        0
                                        : todoCount
                                }`}
                                variant="outlined"
                            />

                            <Chip
                                label={`Devam eden: ${
                                    isAdmin
                                        ? summary
                                            ?.inProgressTaskCount ??
                                        0
                                        : inProgressCount
                                }`}
                                color="info"
                                variant="outlined"
                            />

                            <Chip
                                label={`İncelemede: ${
                                    isAdmin
                                        ? summary
                                            ?.inReviewTaskCount ??
                                        0
                                        : inReviewCount
                                }`}
                                color="warning"
                                variant="outlined"
                            />

                            <Chip
                                label={`Tamamlanan: ${
                                    isAdmin
                                        ? summary
                                            ?.doneTaskCount ??
                                        0
                                        : doneCount
                                }`}
                                color="success"
                                variant="outlined"
                            />
                        </Stack>
                    )}
                </Stack>
            </Paper>

            {/* Yalnızca görev tamamlanma oranı gösterilir */}
            <ProgressCard
                title={
                    isAdmin
                        ? 'Görev tamamlanma oranı'
                        : 'Görevlerimin tamamlanma oranı'
                }
                description="Tamamlanan görevlerin toplam görevlere oranı."
                value={
                    isAdmin
                        ? summary
                            ?.taskCompletionPercentage ??
                        0
                        : personalCompletionPercentage
                }
                isLoading={
                    isAdmin
                        ? isSummaryLoading
                        : isPersonalTasksLoading
                }
            />

            {/* Son görevler */}
            <RecentTasksTable
                tasks={recentTasks}
                isLoading={
                    recentTasksLoading
                }
                isFetching={
                    recentTasksFetching
                }
                isError={
                    recentTasksIsError
                }
                errorMessage={
                    recentTasksErrorMessage
                }
                onRefresh={
                    handleRefreshTasks
                }
            />

            {/* Proje teslim bilgileri */}
            <Paper
                elevation={0}
                sx={{
                    p: 3,

                    border: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Stack spacing={2}>
                    <Typography variant="h6">
                        Yaklaşan proje teslimi
                    </Typography>

                    {isProjectsLoading ? (
                        <>
                            <Skeleton height={28} />
                            <Skeleton height={28} />
                            <Skeleton height={28} />
                        </>
                    ) : nearestProject ? (
                        <>
                            <DashboardDetailRow
                                label="Proje"
                                value={
                                    nearestProject.name
                                }
                            />

                            <DashboardDetailRow
                                label="Bitiş tarihi"
                                value={new Intl.DateTimeFormat(
                                    'tr-TR',
                                    {
                                        day: '2-digit',
                                        month: '2-digit',
                                        year: 'numeric',
                                    },
                                ).format(
                                    new Date(
                                        nearestProject.endDate,
                                    ),
                                )}
                            />

                            <DashboardDetailRow
                                label="Kalan süre"
                                value={
                                    nearestProjectRemainingDays ===
                                    null
                                        ? '-'
                                        : formatRemainingDays(
                                            nearestProjectRemainingDays,
                                        )
                                }
                            />
                        </>
                    ) : (
                        <Alert severity="info">
                            Bitiş tarihi bulunan devam eden
                            bir proje bulunmuyor.
                        </Alert>
                    )}
                </Stack>
            </Paper>

            {/* Oturum bilgileri */}
            <Paper
                elevation={0}
                sx={{
                    p: {
                        xs: 3,
                        md: 4,
                    },

                    border: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Stack spacing={2}>
                    <Typography variant="h6">
                        Oturum bilgileri
                    </Typography>

                    <DashboardDetailRow
                        label="Ad soyad"
                        value={
                            user?.fullName ??
                            '-'
                        }
                    />

                    <DashboardDetailRow
                        label="E-posta"
                        value={
                            user?.email ??
                            '-'
                        }
                    />

                    <DashboardDetailRow
                        label="Rol"
                        value={
                            <Chip
                                label={
                                    user?.role ??
                                    '-'
                                }
                                color="primary"
                                size="small"
                            />
                        }
                    />

                    <DashboardDetailRow
                        label={
                            isAdmin
                                ? 'Bana atanan görev'
                                : 'Kalan görevlerim'
                        }
                        value={
                            isAdmin
                                ? summary
                                    ?.myAssignedTaskCount ??
                                0
                                : remainingTasks.length
                        }
                    />

                    <DashboardDetailRow
                        label="Son güncellenme"
                        value={
                            isAdmin &&
                            summary
                                ? formatDateTime(
                                    summary.generatedAtUtc,
                                )
                                : new Intl.DateTimeFormat(
                                    'tr-TR',
                                    {
                                        day: '2-digit',
                                        month: '2-digit',
                                        year: 'numeric',
                                        hour: '2-digit',
                                        minute: '2-digit',
                                    },
                                ).format(
                                    new Date(),
                                )
                        }
                    />
                </Stack>
            </Paper>
        </Stack>
    );
}