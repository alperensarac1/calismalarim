import PersonAddRoundedIcon from '@mui/icons-material/PersonAddRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';

import {
    Alert,
    Box,
    Button,
    CircularProgress,
    Pagination,
    Paper,
    Stack,
    Typography,
} from '@mui/material';

import {
    useDeferredValue,
    useState,
    type ChangeEvent,
} from 'react';

import { DeleteUserDialog } from '../features/users/components/DeleteUserDialog';
import { ResetUserPasswordDialog } from '../features/users/components/ResetUserPasswordDialog';
import { UpdateUserStatusDialog } from '../features/users/components/UpdateUserStatusDialog';
import { UserFilters } from '../features/users/components/UserFilters';
import { UserFormDialog } from '../features/users/components/UserFormDialog';
import { UsersTable } from '../features/users/components/UsersTable';

import { useUsers } from '../features/users/hooks/useUsers';

import type {
    SystemUser,
    UserFiltersState,
    UserRole,
} from '../features/users/types/user.types';

const DEFAULT_PAGE_SIZE = 20;

export function UsersPage() {
    /*
     * Backend sayfalama sistemi 1'den başladığı için
     * başlangıç sayfasını 1 olarak belirliyoruz.
     */
    const [
        page,
        setPage,
    ] = useState(1);

    /*
     * Kullanıcı listesi filtrelerinin UI state'i.
     */
    const [
        filters,
        setFilters,
    ] = useState<UserFiltersState>({
        search: '',
        role: '',
        activeFilter: 'all',
    });

    /*
     * Arama metnini React tarafından düşük öncelikli
     * olarak işlemek için useDeferredValue kullanıyoruz.
     */
    const deferredSearch =
        useDeferredValue(
            filters.search.trim(),
        );

    /*
     * Yeni kullanıcı oluşturma dialog durumu.
     */
    const [
        isCreateDialogOpen,
        setIsCreateDialogOpen,
    ] = useState(false);

    /*
     * Düzenlenecek kullanıcı.
     */
    const [
        selectedUserForEdit,
        setSelectedUserForEdit,
    ] = useState<SystemUser | null>(
        null,
    );

    /*
     * Aktiflik durumu değiştirilecek kullanıcı.
     */
    const [
        selectedUserForStatus,
        setSelectedUserForStatus,
    ] = useState<SystemUser | null>(
        null,
    );

    /*
     * Parolası sıfırlanacak kullanıcı.
     */
    const [
        selectedUserForPasswordReset,
        setSelectedUserForPasswordReset,
    ] = useState<SystemUser | null>(
        null,
    );

    /*
     * Silinecek kullanıcı.
     */
    const [
        selectedUserForDelete,
        setSelectedUserForDelete,
    ] = useState<SystemUser | null>(
        null,
    );

    /*
     * UI'daki aktiflik filtresini backend'in beklediği
     * boolean değerine dönüştürür.
     *
     * all      -> undefined
     * active   -> true
     * inactive -> false
     */
    const isActive =
        filters.activeFilter === 'all'
            ? undefined
            : filters.activeFilter ===
            'active';

    /*
     * Kullanıcı listesini backend'den getirir.
     */
    const {
        data,
        isLoading,
        isFetching,
        isError,
        error,
        refetch,
    } = useUsers({
        page,

        pageSize:
        DEFAULT_PAGE_SIZE,

        search:
            deferredSearch ||
            undefined,

        role:
            filters.role ||
            undefined,

        isActive,
    });

    /*
     * API hatasını kullanıcıya gösterilecek mesaja dönüştürür.
     */
    const errorMessage =
        error instanceof Error
            ? error.message
            : 'Kullanıcılar alınamadı.';

    /*
     * Backend totalPages değerini 0 döndürürse
     * MUI Pagination için en az 1 değeri kullanılır.
     */
    const totalPages =
        Math.max(
            data?.totalPages ?? 1,
            1,
        );

    const totalCount =
        data?.totalCount ?? 0;

    /*
     * Arama filtresi değiştiğinde liste birinci sayfaya döner.
     */
    const handleSearchChange = (
        value: string,
    ): void => {
        setFilters((current) => ({
            ...current,
            search: value,
        }));

        setPage(1);
    };

    /*
     * Rol filtresi değiştiğinde liste birinci sayfaya döner.
     */
    const handleRoleChange = (
        value: UserRole | '',
    ): void => {
        setFilters((current) => ({
            ...current,
            role: value,
        }));

        setPage(1);
    };

    /*
     * Aktiflik filtresi değiştiğinde liste birinci sayfaya döner.
     */
    const handleActiveFilterChange = (
        value:
        UserFiltersState['activeFilter'],
    ): void => {
        setFilters((current) => ({
            ...current,
            activeFilter: value,
        }));

        setPage(1);
    };

    /*
     * MUI Pagination sayfa değişim işlemi.
     */
    const handlePageChange = (
        _event: ChangeEvent<unknown>,
        nextPage: number,
    ): void => {
        setPage(nextPage);
    };

    return (
        <>
            <Stack spacing={3}>
                {/* Sayfa başlığı ve üst işlem butonları */}
                <Stack
                    direction={{
                        xs: 'column',
                        sm: 'row',
                    }}
                    spacing={2}
                    sx={{
                        alignItems: {
                            xs: 'stretch',
                            sm: 'center',
                        },

                        justifyContent:
                            'space-between',
                    }}
                >
                    <Box>
                        <Typography
                            component="h1"
                            variant="h4"
                        >
                            Kullanıcılar
                        </Typography>

                        <Typography
                            color="text.secondary"
                            sx={{
                                mt: 1,
                            }}
                        >
                            Sistem kullanıcılarını
                            görüntüleyin, düzenleyin ve
                            yönetin.
                        </Typography>
                    </Box>

                    <Stack
                        direction="row"
                        spacing={1}
                        useFlexGap
                        sx={{
                            flexWrap: 'wrap',
                        }}
                    >
                        <Button
                            variant="outlined"
                            startIcon={
                                isFetching ? (
                                    <CircularProgress
                                        size={18}
                                        color="inherit"
                                    />
                                ) : (
                                    <RefreshRoundedIcon />
                                )
                            }
                            disabled={isFetching}
                            onClick={() => {
                                void refetch();
                            }}
                        >
                            Yenile
                        </Button>

                        <Button
                            variant="contained"
                            startIcon={
                                <PersonAddRoundedIcon />
                            }
                            onClick={() => {
                                setIsCreateDialogOpen(
                                    true,
                                );
                            }}
                        >
                            Yeni kullanıcı
                        </Button>
                    </Stack>
                </Stack>

                {/* Kullanıcı filtreleri */}
                <Paper
                    elevation={0}
                    sx={{
                        p: {
                            xs: 2,
                            md: 3,
                        },

                        border: '1px solid',
                        borderColor: 'divider',
                    }}
                >
                    <UserFilters
                        filters={filters}
                        onSearchChange={
                            handleSearchChange
                        }
                        onRoleChange={
                            handleRoleChange
                        }
                        onActiveFilterChange={
                            handleActiveFilterChange
                        }
                    />
                </Paper>

                {/* API hata mesajı */}
                {isError && (
                    <Alert
                        severity="error"
                        action={
                            <Button
                                color="inherit"
                                size="small"
                                onClick={() => {
                                    void refetch();
                                }}
                            >
                                Tekrar dene
                            </Button>
                        }
                    >
                        {errorMessage}
                    </Alert>
                )}

                {/* Kullanıcı tablosu */}
                <UsersTable
                    users={
                        data?.items ??
                        []
                    }
                    isLoading={
                        isLoading
                    }
                    onEditUser={(user) => {
                        setSelectedUserForEdit(
                            user,
                        );
                    }}
                    onChangeStatus={(user) => {
                        setSelectedUserForStatus(
                            user,
                        );
                    }}

                    /*
                     * Tablodaki "Parolayı sıfırla" seçeneği
                     * tıklandığında seçilen kullanıcı dialoga aktarılır.
                     */
                    onResetPassword={(user) => {
                        setSelectedUserForPasswordReset(
                            user,
                        );
                    }}
                    onDeleteUser={(user) => {
                        setSelectedUserForDelete(
                            user,
                        );
                    }}
                />

                {/* Sayfalama */}
                {!isLoading &&
                    totalPages > 1 && (
                        <Stack
                            spacing={1}
                            sx={{
                                alignItems:
                                    'center',
                            }}
                        >
                            <Pagination
                                page={page}
                                count={
                                    totalPages
                                }
                                color="primary"
                                disabled={
                                    isFetching
                                }
                                onChange={
                                    handlePageChange
                                }
                            />

                            <Typography
                                variant="caption"
                                color="text.secondary"
                            >
                                Toplam{' '}
                                {totalCount}{' '}
                                kullanıcı
                            </Typography>
                        </Stack>
                    )}
            </Stack>

            {/* Yeni kullanıcı oluşturma dialogu */}
            <UserFormDialog
                open={
                    isCreateDialogOpen
                }
                onClose={() => {
                    setIsCreateDialogOpen(
                        false,
                    );
                }}
            />

            {/* Kullanıcı düzenleme dialogu */}
            <UserFormDialog
                open={
                    selectedUserForEdit !==
                    null
                }
                user={
                    selectedUserForEdit
                }
                onClose={() => {
                    setSelectedUserForEdit(
                        null,
                    );
                }}
            />

            {/* Kullanıcı aktif/pasif dialogu */}
            <UpdateUserStatusDialog
                open={
                    selectedUserForStatus !==
                    null
                }
                user={
                    selectedUserForStatus
                }
                onClose={() => {
                    setSelectedUserForStatus(
                        null,
                    );
                }}
            />

            {/* Kullanıcı parola sıfırlama dialogu */}
            <ResetUserPasswordDialog
                open={
                    selectedUserForPasswordReset !==
                    null
                }
                user={
                    selectedUserForPasswordReset
                }
                onClose={() => {
                    setSelectedUserForPasswordReset(
                        null,
                    );
                }}
            />

            {/* Kullanıcı silme dialogu */}
            <DeleteUserDialog
                open={
                    selectedUserForDelete !==
                    null
                }
                user={
                    selectedUserForDelete
                }
                onClose={() => {
                    setSelectedUserForDelete(
                        null,
                    );
                }}
            />
        </>
    );
}