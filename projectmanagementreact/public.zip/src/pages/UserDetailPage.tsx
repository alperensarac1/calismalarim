import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import EditOutlinedIcon from '@mui/icons-material/EditOutlined';
import LockResetRoundedIcon from '@mui/icons-material/LockResetRounded';
import PersonOutlineRoundedIcon from '@mui/icons-material/PersonOutlineRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import ToggleOffRoundedIcon from '@mui/icons-material/ToggleOffRounded';
import ToggleOnRoundedIcon from '@mui/icons-material/ToggleOnRounded';

import {
    Alert,
    Avatar,
    Box,
    Button,
    Chip,
    CircularProgress,
    Paper,
    Skeleton,
    Stack,
    Tooltip,
    Typography,
} from '@mui/material';

import {
    useState,
    type ReactNode,
} from 'react';

import {
    useNavigate,
    useParams,
} from 'react-router-dom';

import { useAuthStore } from '../features/auth/store/authStore';

import { DeleteUserDialog } from '../features/users/components/DeleteUserDialog';
import { ResetUserPasswordDialog } from '../features/users/components/ResetUserPasswordDialog';
import { UpdateUserStatusDialog } from '../features/users/components/UpdateUserStatusDialog';
import { UserFormDialog } from '../features/users/components/UserFormDialog';

import { useUserDetail } from '../features/users/hooks/useUserDetail';

import {
    formatUserDate,
    getUserRoleColor,
    getUserRoleLabel,
} from '../features/users/utils/userFormatters';

interface UserDetailRowProps {
    label: string;
    value: ReactNode;
}

/*
 * Kullanıcı detay kartlarında tekrar kullanılan
 * etiket-değer satırı.
 */
function UserDetailRow({
                           label,
                           value,
                       }: UserDetailRowProps) {
    const isPrimitiveValue =
        typeof value === 'string' ||
        typeof value === 'number';

    return (
        <Box
            sx={{
                display: 'grid',

                gridTemplateColumns: {
                    xs: '1fr',
                    sm: '180px minmax(0, 1fr)',
                },

                gap: {
                    xs: 0.5,
                    sm: 2,
                },

                py: 1.5,

                borderBottom: '1px solid',
                borderColor: 'divider',

                '&:last-of-type': {
                    borderBottom: 0,
                },
            }}
        >
            <Typography
                variant="body2"
                color="text.secondary"
            >
                {label}
            </Typography>

            {isPrimitiveValue ? (
                <Typography
                    variant="body2"
                    sx={{
                        fontWeight: 600,
                        overflowWrap: 'anywhere',
                    }}
                >
                    {value}
                </Typography>
            ) : (
                value
            )}
        </Box>
    );
}

/*
 * Kullanıcı bilgileri yüklenirken gösterilen
 * iskelet ekran.
 */
function UserDetailSkeleton() {
    return (
        <Stack spacing={3}>
            <Skeleton
                width={180}
                height={40}
            />

            <Paper
                elevation={0}
                sx={{
                    p: 3,
                    border: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Stack
                    direction={{
                        xs: 'column',
                        sm: 'row',
                    }}
                    spacing={3}
                >
                    <Skeleton
                        variant="circular"
                        width={96}
                        height={96}
                    />

                    <Box
                        sx={{
                            flexGrow: 1,
                        }}
                    >
                        <Skeleton
                            width="45%"
                            height={46}
                        />

                        <Skeleton
                            width="60%"
                        />

                        <Skeleton
                            width="35%"
                        />
                    </Box>
                </Stack>
            </Paper>

            <Paper
                elevation={0}
                sx={{
                    p: 3,
                    border: '1px solid',
                    borderColor: 'divider',
                }}
            >
                <Stack spacing={1}>
                    <Skeleton width="100%" />
                    <Skeleton width="90%" />
                    <Skeleton width="80%" />
                    <Skeleton width="75%" />
                </Stack>
            </Paper>
        </Stack>
    );
}

export function UserDetailPage() {
    const navigate =
        useNavigate();

    /*
     * Oturum açmış kullanıcı bilgisi.
     *
     * Görüntülenen hesabın mevcut kullanıcıya ait olup
     * olmadığını kontrol etmek için kullanılır.
     */
    const currentUser =
        useAuthStore(
            (state) => state.user,
        );

    /*
     * Router adresi:
     *
     * /users/:userId
     */
    const { userId } =
        useParams<{
            userId: string;
        }>();

    const parsedUserId =
        Number(userId);

    const isValidUserId =
        Number.isInteger(
            parsedUserId,
        ) &&
        parsedUserId > 0;

    /*
     * Kullanıcı düzenleme dialog durumu.
     */
    const [
        isEditDialogOpen,
        setIsEditDialogOpen,
    ] = useState(false);

    /*
     * Kullanıcı aktiflik durumu dialogu.
     */
    const [
        isStatusDialogOpen,
        setIsStatusDialogOpen,
    ] = useState(false);

    /*
     * Kullanıcı parola sıfırlama dialogu.
     */
    const [
        isResetPasswordDialogOpen,
        setIsResetPasswordDialogOpen,
    ] = useState(false);

    /*
     * Kullanıcı silme dialog durumu.
     */
    const [
        isDeleteDialogOpen,
        setIsDeleteDialogOpen,
    ] = useState(false);

    const {
        data: user,
        isLoading,
        isFetching,
        isError,
        error,
        refetch,
    } = useUserDetail(
        parsedUserId,
    );

    /*
     * URL içerisindeki kullanıcı kimliği geçersizse
     * API isteğinden bağımsız olarak hata gösterilir.
     */
    if (!isValidUserId) {
        return (
            <Stack spacing={2}>
                <Alert severity="error">
                    Geçersiz kullanıcı kimliği.
                </Alert>

                <Button
                    variant="outlined"
                    onClick={() => {
                        navigate('/users');
                    }}
                    sx={{
                        alignSelf: 'flex-start',
                    }}
                >
                    Kullanıcılara dön
                </Button>
            </Stack>
        );
    }

    if (isLoading) {
        return <UserDetailSkeleton />;
    }

    /*
     * Kullanıcı bulunamazsa veya API isteği hata verirse
     * hata alanı gösterilir.
     */
    if (
        isError ||
        !user
    ) {
        return (
            <Stack spacing={2}>
                <Alert severity="error">
                    {error instanceof Error
                        ? error.message
                        : 'Kullanıcı bilgileri alınamadı.'}
                </Alert>

                <Stack
                    direction="row"
                    spacing={1}
                    useFlexGap
                    sx={{
                        flexWrap: 'wrap',
                    }}
                >
                    <Button
                        variant="outlined"
                        onClick={() => {
                            navigate('/users');
                        }}
                    >
                        Kullanıcılara dön
                    </Button>

                    <Button
                        variant="contained"
                        onClick={() => {
                            void refetch();
                        }}
                    >
                        Tekrar dene
                    </Button>
                </Stack>
            </Stack>
        );
    }

    /*
     * Görüntülenen kullanıcı, sisteme giriş yapmış
     * kullanıcıyla aynı mı?
     */
    const isCurrentUser =
        currentUser !== null &&
        user.id === currentUser.id;

    /*
     * Avatar üzerinde gösterilecek ad ve soyad baş harfleri.
     */
    const initials =
        `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`
            .toUpperCase();

    return (
        <>
            <Stack spacing={3}>
                {/* Üst işlem alanı */}
                <Stack
                    direction={{
                        xs: 'column',
                        sm: 'row',
                    }}
                    spacing={2}
                    sx={{
                        alignItems: {
                            xs: 'stretch',
                            sm: 'center',
                        },

                        justifyContent:
                            'space-between',
                    }}
                >
                    <Button
                        startIcon={
                            <ArrowBackRoundedIcon />
                        }
                        onClick={() => {
                            navigate('/users');
                        }}
                        sx={{
                            alignSelf: {
                                xs: 'flex-start',
                                sm: 'center',
                            },
                        }}
                    >
                        Kullanıcılara dön
                    </Button>

                    <Stack
                        direction="row"
                        spacing={1}
                        useFlexGap
                        sx={{
                            flexWrap: 'wrap',
                        }}
                    >
                        <Button
                            variant="outlined"
                            startIcon={
                                isFetching ? (
                                    <CircularProgress
                                        size={18}
                                        color="inherit"
                                    />
                                ) : (
                                    <RefreshRoundedIcon />
                                )
                            }
                            disabled={isFetching}
                            onClick={() => {
                                void refetch();
                            }}
                        >
                            Yenile
                        </Button>

                        <Button
                            variant="outlined"
                            startIcon={
                                <LockResetRoundedIcon />
                            }
                            onClick={() => {
                                setIsResetPasswordDialogOpen(
                                    true,
                                );
                            }}
                        >
                            Parolayı sıfırla
                        </Button>

                        {/*
                         * Disabled Button doğrudan Tooltip olaylarını
                         * çalıştırmadığı için span ile sarıyoruz.
                         */}
                        <Tooltip
                            title={
                                isCurrentUser
                                    ? 'Kendi kullanıcı hesabınızı pasif hâle getiremezsiniz.'
                                    : ''
                            }
                        >
                            <span>
                                <Button
                                    variant="outlined"
                                    color={
                                        user.isActive
                                            ? 'warning'
                                            : 'success'
                                    }
                                    startIcon={
                                        user.isActive ? (
                                            <ToggleOffRoundedIcon />
                                        ) : (
                                            <ToggleOnRoundedIcon />
                                        )
                                    }
                                    disabled={
                                        isCurrentUser
                                    }
                                    onClick={() => {
                                        if (
                                            isCurrentUser
                                        ) {
                                            return;
                                        }

                                        setIsStatusDialogOpen(
                                            true,
                                        );
                                    }}
                                >
                                    {user.isActive
                                        ? 'Pasif yap'
                                        : 'Aktif yap'}
                                </Button>
                            </span>
                        </Tooltip>

                        <Button
                            variant="contained"
                            startIcon={
                                <EditOutlinedIcon />
                            }
                            onClick={() => {
                                setIsEditDialogOpen(
                                    true,
                                );
                            }}
                        >
                            Düzenle
                        </Button>

                        <Tooltip
                            title={
                                isCurrentUser
                                    ? 'Kendi kullanıcı hesabınızı silemezsiniz.'
                                    : ''
                            }
                        >
                            <span>
                                <Button
                                    variant="outlined"
                                    color="error"
                                    startIcon={
                                        <DeleteOutlineRoundedIcon />
                                    }
                                    disabled={
                                        isCurrentUser
                                    }
                                    onClick={() => {
                                        if (
                                            isCurrentUser
                                        ) {
                                            return;
                                        }

                                        setIsDeleteDialogOpen(
                                            true,
                                        );
                                    }}
                                >
                                    Sil
                                </Button>
                            </span>
                        </Tooltip>
                    </Stack>
                </Stack>

                {/* Kendi hesap bilgisi */}
                {isCurrentUser && (
                    <Alert severity="info">
                        Kendi kullanıcı hesabınızı
                        görüntülüyorsunuz. Hesap
                        bilgilerinizi ve parolanızı
                        değiştirebilirsiniz; ancak
                        hesabınızı pasif hâle getiremez,
                        silemez veya sistem rolünüzü
                        değiştiremezsiniz.
                    </Alert>
                )}

                {/* Kullanıcı başlık kartı */}
                <Paper
                    elevation={0}
                    sx={{
                        p: {
                            xs: 3,
                            md: 4,
                        },

                        border: '1px solid',
                        borderColor: 'divider',
                    }}
                >
                    <Stack
                        direction={{
                            xs: 'column',
                            sm: 'row',
                        }}
                        spacing={3}
                        sx={{
                            alignItems: {
                                xs: 'flex-start',
                                sm: 'center',
                            },
                        }}
                    >
                        <Avatar
                            sx={{
                                width: 96,
                                height: 96,

                                bgcolor:
                                    user.isActive
                                        ? 'primary.main'
                                        : 'grey.500',

                                fontSize: 30,
                                fontWeight: 700,
                            }}
                        >
                            {initials}
                        </Avatar>

                        <Box
                            sx={{
                                minWidth: 0,
                                flexGrow: 1,
                            }}
                        >
                            <Stack
                                direction="row"
                                spacing={1}
                                useFlexGap
                                sx={{
                                    alignItems:
                                        'center',

                                    flexWrap:
                                        'wrap',
                                }}
                            >
                                <Typography
                                    component="h1"
                                    variant="h4"
                                >
                                    {user.fullName}
                                </Typography>

                                {isCurrentUser && (
                                    <Chip
                                        label="Siz"
                                        color="primary"
                                        variant="outlined"
                                        size="small"
                                    />
                                )}

                                <Chip
                                    label={getUserRoleLabel(
                                        user.role,
                                    )}
                                    color={getUserRoleColor(
                                        user.role,
                                    )}
                                    variant="outlined"
                                    size="small"
                                />

                                <Chip
                                    label={
                                        user.isActive
                                            ? 'Aktif'
                                            : 'Pasif'
                                    }
                                    color={
                                        user.isActive
                                            ? 'success'
                                            : 'default'
                                    }
                                    size="small"
                                />
                            </Stack>

                            <Typography
                                color="text.secondary"
                                sx={{
                                    mt: 1,
                                    overflowWrap:
                                        'anywhere',
                                }}
                            >
                                {user.email}
                            </Typography>

                            <Typography
                                variant="body2"
                                color="text.secondary"
                                sx={{
                                    mt: 0.5,
                                }}
                            >
                                Kullanıcı #{user.id}
                            </Typography>
                        </Box>
                    </Stack>
                </Paper>

                {/* Kullanıcı detay kartları */}
                <Box
                    sx={{
                        display: 'grid',

                        gridTemplateColumns: {
                            xs: '1fr',

                            lg:
                                'repeat(2, minmax(0, 1fr))',
                        },

                        gap: 2,
                    }}
                >
                    <Paper
                        elevation={0}
                        sx={{
                            p: 3,

                            border: '1px solid',
                            borderColor: 'divider',
                        }}
                    >
                        <Typography
                            variant="h6"
                            sx={{
                                mb: 2,
                            }}
                        >
                            Kişisel bilgiler
                        </Typography>

                        <UserDetailRow
                            label="Ad"
                            value={user.firstName}
                        />

                        <UserDetailRow
                            label="Soyad"
                            value={user.lastName}
                        />

                        <UserDetailRow
                            label="Ad soyad"
                            value={user.fullName}
                        />

                        <UserDetailRow
                            label="E-posta"
                            value={user.email}
                        />
                    </Paper>

                    <Paper
                        elevation={0}
                        sx={{
                            p: 3,

                            border: '1px solid',
                            borderColor: 'divider',
                        }}
                    >
                        <Typography
                            variant="h6"
                            sx={{
                                mb: 2,
                            }}
                        >
                            Sistem bilgileri
                        </Typography>

                        <UserDetailRow
                            label="Rol"
                            value={
                                <Chip
                                    label={getUserRoleLabel(
                                        user.role,
                                    )}
                                    color={getUserRoleColor(
                                        user.role,
                                    )}
                                    variant="outlined"
                                    size="small"
                                />
                            }
                        />

                        <UserDetailRow
                            label="Departman"
                            value={
                                user.department ||
                                'Belirtilmemiş'
                            }
                        />

                        <UserDetailRow
                            label="Durum"
                            value={
                                <Chip
                                    label={
                                        user.isActive
                                            ? 'Aktif'
                                            : 'Pasif'
                                    }
                                    color={
                                        user.isActive
                                            ? 'success'
                                            : 'default'
                                    }
                                    size="small"
                                />
                            }
                        />

                        <UserDetailRow
                            label="Kayıt tarihi"
                            value={formatUserDate(
                                user.createdAt,
                            )}
                        />
                    </Paper>
                </Box>

                {/* Bilgilendirme kartı */}
                <Paper
                    elevation={0}
                    sx={{
                        p: 3,

                        border: '1px solid',
                        borderColor: 'divider',
                    }}
                >
                    <Stack
                        direction="row"
                        spacing={1.5}
                        sx={{
                            alignItems:
                                'flex-start',
                        }}
                    >
                        <PersonOutlineRoundedIcon
                            color="action"
                        />

                        <Box>
                            <Typography
                                variant="body2"
                                sx={{
                                    fontWeight: 700,
                                }}
                            >
                                Kullanıcı yönetimi
                            </Typography>

                            <Typography
                                variant="body2"
                                color="text.secondary"
                                sx={{
                                    mt: 0.5,
                                }}
                            >
                                Kullanıcının adı,
                                e-posta adresi, rolü ve
                                departmanı düzenlenebilir.
                                Aktiflik durumu ve parola
                                ayrı işlemler üzerinden
                                değiştirilir.
                            </Typography>
                        </Box>
                    </Stack>
                </Paper>
            </Stack>

            {/* Kullanıcı düzenleme dialogu */}
            <UserFormDialog
                open={isEditDialogOpen}
                user={user}
                onClose={() => {
                    setIsEditDialogOpen(
                        false,
                    );
                }}
            />

            {/* Kullanıcı aktif/pasif dialogu */}
            <UpdateUserStatusDialog
                open={isStatusDialogOpen}
                user={user}
                onClose={() => {
                    setIsStatusDialogOpen(
                        false,
                    );
                }}
            />

            {/* Kullanıcı parola sıfırlama dialogu */}
            <ResetUserPasswordDialog
                open={
                    isResetPasswordDialogOpen
                }
                user={user}
                onClose={() => {
                    setIsResetPasswordDialogOpen(
                        false,
                    );
                }}
            />

            {/* Kullanıcı silme dialogu */}
            <DeleteUserDialog
                open={isDeleteDialogOpen}
                user={user}
                onClose={() => {
                    setIsDeleteDialogOpen(
                        false,
                    );
                }}
                onDeleted={() => {
                    navigate(
                        '/users',
                        {
                            replace: true,
                        },
                    );
                }}
            />
        </>
    );
}